/* global React, FrameReimag, Icon, BROKER, BROKER_RECS, BROKER_BOOK */

/* ============================================================
 * 06. Recommendations — coverage-gap analysis, broker-driven
 *
 * Layout
 *   row 1 — title + KPIs
 *   row 2 — for each client with gaps: card with rationale + "Send to client" CTA
 * ============================================================ */

function ReimBrokerRecs({ isDark }) {
  const recs = BROKER_RECS;
  const byClient = recs.reduce((map, r) => {
    if (!map[r.entity]) map[r.entity] = [];
    map[r.entity].push(r);
    return map;
  }, {});
  const totalGaps = recs.length;
  const clientsTouched = Object.keys(byClient).length;
  const totalPotential = recs.reduce((s, r) => s + (r.range[0] + r.range[1]) / 2, 0);

  return (
    <FrameReimag menu="Recommendations" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Recommendations</div>
            <h2 className="display" style={{ marginTop: 6 }}>Coverage gaps across your book</h2>
            <div className="caption" style={{ marginTop: 6, maxWidth: 640 }}>
              Industry-by-coverage rule analysis. Each gap is a credible upsell opportunity — review the rationale, then send the prompt to the client when you're ready.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, auto)', gap: 28 }}>
            <KpiSnug label="Gaps identified" value={totalGaps} tone="spot" />
            <KpiSnug label="Clients touched" value={clientsTouched} />
            <KpiSnug label="Indicative new premium" value={`$${(totalPotential / 1_000_000).toFixed(2)}M`} tone="pos" />
          </div>
        </div>

        {/* info bar */}
        <div style={{
          padding: '12px 16px',
          background: 'var(--surface-sunken)',
          border: '1px solid var(--rule)',
          borderRadius: 10,
          display: 'flex', alignItems: 'center', gap: 12, fontSize: 12.5,
        }}>
          <Icon name="info" size={16} color="var(--ink-soft)" />
          <span className="caption">
            Rules: tech firms → cyber + PI + D&O; healthcare → +MedProf; manufacturers → +Product Liability + Casualty; pharma → +Clinical Trials. We flag where a client is missing one of these by-industry defaults.
          </span>
        </div>

        {/* per-client recommendation cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {Object.entries(byClient).map(([entity, items]) => {
            const sample = items[0];
            return (
              <div key={entity} className="card" style={{ padding: 0, overflow: 'hidden' }}>
                <div style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '14px 20px',
                  background: 'var(--surface-elev)',
                  borderBottom: '1px solid var(--rule)',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                      width: 32, height: 32, borderRadius: 8,
                      background: 'var(--surface)', border: '1px solid var(--rule)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <Icon name="briefcase" size={16} />
                    </div>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 700 }}>{entity}</div>
                      <div className="micro">{sample.vertical}</div>
                    </div>
                  </div>
                  <span className="chip chip-spot">
                    {items.length} gap{items.length === 1 ? '' : 's'}
                  </span>
                </div>
                {items.map((r, i) => (
                  <div key={r.line} style={{
                    display: 'grid',
                    gridTemplateColumns: '1.4fr 1.4fr 1fr auto',
                    gap: 18, alignItems: 'center',
                    padding: '16px 20px',
                    borderBottom: i < items.length - 1 ? '1px solid var(--rule)' : 0,
                  }}>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>{r.line}</div>
                      <div className="micro">Industry default for {r.vertical}</div>
                    </div>
                    <div className="caption" style={{ fontSize: 12.5, lineHeight: 1.4 }}>{r.rationale}</div>
                    <div style={{ textAlign: 'right' }}>
                      <div className="micro">Indicative range</div>
                      <div style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>
                        ${(r.range[0] / 1000).toFixed(0)}k – ${(r.range[1] / 1000).toFixed(0)}k
                      </div>
                    </div>
                    <button className="btn spot">
                      <Icon name="send" size={13} /> Send to client
                    </button>
                  </div>
                ))}
              </div>
            );
          })}
        </div>

      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimBrokerRecs });
