/* global React, FrameReimag, Icon, BROKER, BROKER_CARRIERS */

/* ============================================================
 * 05. Carrier Intelligence — universe of carriers + drill into one
 *
 * Layout
 *   row 1 — title + KPI strip
 *   row 2 — filter bar (ESG, pricing)
 *   row 3 — sortable carrier table
 * ============================================================ */

function ReimBrokerCarriers({ isDark }) {
  const carriers = BROKER_CARRIERS;
  const leaders = carriers.filter(c => c.esg === 'leader').length;
  const tight   = carriers.filter(c => c.pricing === 'tight').length;
  const avgCmsn = (carriers.reduce((s, c) => s + c.commission, 0) / carriers.length).toFixed(1);
  const avgWin  = Math.round(carriers.reduce((s, c) => s + c.winRate, 0) / carriers.length * 100);

  return (
    <FrameReimag menu="Carrier Intelligence" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Carrier intelligence</div>
            <h2 className="display" style={{ marginTop: 6 }}>The market universe you place into</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Appetite, capacity, pricing, ESG stance, and your hit rate per carrier.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, auto)', gap: 28 }}>
            <KpiSnug label="Carriers"     value={carriers.length} />
            <KpiSnug label="ESG leaders"  value={leaders}        tone="pos" />
            <KpiSnug label="Tight pricing" value={tight} />
            <KpiSnug label="Avg cmsn"     value={`${avgCmsn}%`} />
            <KpiSnug label="Avg win rate" value={`${avgWin}%`} />
          </div>
        </div>

        {/* filters */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="micro" style={{ marginRight: 4 }}>ESG:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
          <span className="chip">Leader</span>
          <span className="chip">Progressive</span>
          <span className="chip">Neutral</span>
          <span className="chip">Restrictive</span>
          <span style={{ width: 16 }} />
          <span className="micro" style={{ marginRight: 4 }}>Pricing:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
          <span className="chip">Tight</span>
          <span className="chip">Median</span>
          <span className="chip">Light</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: by win rate ↓</span>
        </div>

        {/* table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1.8fr 1fr 90px 90px 90px 110px 100px 1fr',
            background: 'var(--surface-elev)',
            padding: '10px 20px',
            borderBottom: '1px solid var(--rule)',
            fontSize: 11,
            color: 'var(--ink-mute)',
          }}>
            {['Carrier', 'Type', 'Cmsn', 'Pricing', 'Win rate', 'ESG', 'Capacity', 'Appetite'].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 11, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {[...carriers].sort((a, b) => b.winRate - a.winRate).map((c, i) => (
            <CarrierRow key={c.slug} c={c} last={i === carriers.length - 1} />
          ))}
        </div>

      </div>
    </FrameReimag>
  );
}

function CarrierRow({ c, last }) {
  const priceTone = c.pricing === 'tight' ? 'var(--pos)' : c.pricing === 'light' ? 'var(--neg)' : 'var(--ink-soft)';
  const esgTone   = c.esg === 'leader' ? 'var(--pos)' : c.esg === 'progressive' ? 'var(--info)' : c.esg === 'neutral' ? 'var(--ink-soft)' : 'var(--warn)';

  // Render appetite as a row of small colored squares — one per line in `specialties`
  const appetiteStances = ['leaning_in', 'neutral', 'leaning_in', 'selective', 'neutral'];
  const appetiteColors = ['var(--pos)', 'var(--info)', 'var(--pos)', 'var(--warn)', 'var(--info)'];

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '1.8fr 1fr 90px 90px 90px 110px 100px 1fr',
      gap: 0, alignItems: 'center',
      padding: '12px 20px',
      borderBottom: last ? 0 : '1px solid var(--rule)',
      fontSize: 13,
    }}>
      <div>
        <div style={{ fontWeight: 600 }}>{c.name}</div>
        <div className="micro" style={{ marginTop: 2 }}>{c.specialties.slice(0, 2).join(' · ')}</div>
      </div>
      <span className="caption">{c.type}</span>
      <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{c.commission.toFixed(1)}%</span>
      <span style={{ color: priceTone, fontWeight: 600, textTransform: 'capitalize' }}>{c.pricing}</span>
      <span>
        <span style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{Math.round(c.winRate * 100)}%</span>
      </span>
      <span style={{ color: esgTone, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5, textTransform: 'capitalize' }}>
        <Icon name="leaf" size={12} /> {c.esg}
      </span>
      <span className="caption">{c.capacity}</span>
      <div style={{ display: 'flex', gap: 3 }} title={`Appetite breadth across ${appetiteStances.length} lines`}>
        {appetiteStances.map((_, i) => (
          <span key={i} style={{
            width: 8, height: 14, borderRadius: 2,
            background: appetiteColors[i],
          }} />
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerCarriers });
