/* global React, FrameReimag, Icon */

/* ============================================================
 * Request Coverage — Lightweight intent form
 *
 * Two-column layout
 *   left  — the form itself
 *   right — context aside (what happens next, why a broker sees this first)
 * ============================================================ */

const ENT_R = 'Eastward Robotics';

function ReimRequest({ isDark }) {
  return (
    <FrameReimag menu="Request Coverage" entity={ENT_R} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 18, height: '100%', alignContent: 'start' }}>

        {/* title */}
        <div>
          <div className="eyebrow">Request coverage</div>
          <h2 className="display" style={{ marginTop: 6 }}>
            Tell your broker what you'd like to explore
          </h2>
          <div className="body" style={{ marginTop: 8, maxWidth: 640 }}>
            No commitment, no obligation. Submitting this notifies your broker — they'll review and reply in Communications, where you can refine the request together before any formal submission goes to market.
          </div>
        </div>

        {/* form + aside */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 20 }}>

          {/* FORM */}
          <div className="card" style={{ padding: 28 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

              <FormField label="Coverage line" required>
                <SelectMock value="Property" />
              </FormField>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <FormField label="Desired limit" optional>
                  <TextMock value="$25,000,000" prefix="$" />
                </FormField>
                <FormField label="Preferred effective date" optional>
                  <TextMock value="2026-09-01" />
                </FormField>
              </div>

              <FormField label="Why are you exploring this?" optional>
                <TextareaMock value="New manufacturing line going live in Q3 — anchor + adjacent warehouse not currently covered. Would like indicative pricing before formal submission." />
              </FormField>

              <FormField label="Attachments" optional>
                <div style={{
                  border: '1px dashed var(--rule-strong)',
                  borderRadius: 10, padding: 18,
                  display: 'flex', alignItems: 'center', gap: 12,
                  color: 'var(--ink-soft)',
                }}>
                  <Icon name="upload-cloud" size={20} />
                  <span style={{ fontSize: 13 }}>
                    Drop COPE summary, valuation reports, or anything else relevant here.
                  </span>
                </div>
              </FormField>

              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                paddingTop: 18, borderTop: '1px solid var(--rule)',
              }}>
                <span className="caption">Your broker (Marsh) will see this first.</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn ghost">Save draft</button>
                  <button className="btn spot">
                    <Icon name="send" size={14} /> Send to broker
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ASIDE */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="card-info" style={{ padding: 20 }}>
              <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>What happens next</div>
              <ol style={{
                margin: '12px 0 0', padding: 0, listStyle: 'none',
                display: 'flex', flexDirection: 'column', gap: 10,
              }}>
                {[
                  ['Your broker receives the request', 'Reviews fit + appetite, may ask clarifying questions in Communications.'],
                  ['DSI estimates the cost', 'Indicative range based on your cohort and current signals.'],
                  ['You decide whether to go to market', 'Nothing leaves the building until you say so.'],
                ].map(([t, body], i) => (
                  <li key={i} style={{ display: 'flex', gap: 12 }}>
                    <div style={{
                      width: 22, height: 22, borderRadius: '50%',
                      background: 'var(--info)', color: '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 12, fontWeight: 700, flexShrink: 0,
                    }}>{i + 1}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{t}</div>
                      <div className="caption" style={{ marginTop: 2, lineHeight: 1.4 }}>{body}</div>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <div className="card" style={{ padding: 20 }}>
              <div className="eyebrow">Indicative range — Property</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 8 }}>
                <span className="num" style={{ fontSize: 26 }}>$70k</span>
                <span className="caption">to</span>
                <span className="num" style={{ fontSize: 26 }}>$220k</span>
              </div>
              <div className="caption" style={{ marginTop: 4 }}>
                Based on Industrial Robotics, $50–250M revenue.
              </div>
              <div style={{
                marginTop: 12, padding: '10px 12px',
                background: 'var(--surface-sunken)', borderRadius: 8,
                display: 'flex', gap: 10, alignItems: 'flex-start',
              }}>
                <Icon name="info" size={14} color="var(--ink-soft)" style={{ marginTop: 1 }} />
                <span className="caption" style={{ fontSize: 11.5, lineHeight: 1.5 }}>
                  Final pricing depends on COPE detail, valuation, and broader signal context.
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function FormField({ label, required, optional, children }) {
  return (
    <div>
      <label style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 6 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>{label}</span>
        {required && <span className="micro spot" style={{ fontSize: 10 }}>required</span>}
        {optional && <span className="micro" style={{ fontSize: 10 }}>optional</span>}
      </label>
      {children}
    </div>
  );
}
function SelectMock({ value }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '10px 14px', fontSize: 14,
      background: 'var(--surface-elev)',
      border: '1px solid var(--rule-strong)',
      borderRadius: 8,
      color: 'var(--ink)',
    }}>
      <span>{value}</span>
      <Icon name="chevron-down" size={16} color="var(--ink-mute)" />
    </div>
  );
}
function TextMock({ value }) {
  return (
    <div style={{
      padding: '10px 14px', fontSize: 14,
      background: 'var(--surface-elev)',
      border: '1px solid var(--rule-strong)',
      borderRadius: 8,
      color: 'var(--ink)',
      fontVariantNumeric: 'tabular-nums',
    }}>
      {value}
    </div>
  );
}
function TextareaMock({ value }) {
  return (
    <div style={{
      padding: '12px 14px', fontSize: 13.5, lineHeight: 1.5,
      background: 'var(--surface-elev)',
      border: '1px solid var(--rule-strong)',
      borderRadius: 8,
      color: 'var(--ink)',
      minHeight: 96,
    }}>
      {value}
    </div>
  );
}

Object.assign(window, { ReimRequest });
