/* global React */

/* ============================================================
 * Primitives shared across faithful + reimagined variants.
 * Recreate the codebase's actual primitive components in one place.
 * ============================================================ */

// Icon — uses iconify-icon (lucide set). Already in <head>.
function Icon({ name, size = 18, color, className = '', style = {} }) {
  return (
    <iconify-icon
      icon={`lucide:${name}`}
      width={size}
      height={size}
      style={{ color, display: 'inline-flex', verticalAlign: '-2px', ...style }}
      class={className}
    />
  );
}

/* ──────────────────────────────────────────────────────────────
 * FAITHFUL chrome
 * ────────────────────────────────────────────────────────────── */

// Client portal nav icons (collapsed sidebar shows just the icons)
const CLIENT_NAV = [
  { name: 'Overview',            icon: 'gauge' },
  { name: 'Your Profile',        icon: 'user-circle' },
  { name: 'Coverages',           icon: 'shield-check' },
  { name: 'Risk Insights',       icon: 'list-checks' },
  { name: 'Industry Benchmarks', icon: 'trending-up-down' },
  { name: 'Scenarios',           icon: 'flask-conical' },
  { name: 'Action Plan',         icon: 'lightbulb' },
  { name: 'Request Coverage',    icon: 'plus-circle' },
  { name: 'Communications',      icon: 'messages-square' },
];

// Broker portal nav — mirrors PORTAL_BROKER_CHILDREN from navConfig.ts
const BROKER_NAV = [
  { name: 'Book of Clients',       icon: 'briefcase' },
  { name: 'Client Health',         icon: 'heart-pulse' },
  { name: 'Coverages',             icon: 'shield-check' },
  { name: 'Placement Strategy',    icon: 'target' },
  { name: 'Carrier Intelligence',  icon: 'building-2' },
  { name: 'Recommendations',       icon: 'lightbulb' },
  { name: 'Communications',        icon: 'messages-square' },
  { name: 'Market Pulse',          icon: 'trending-up-down' },
  { name: 'Risk Aggregation',      icon: 'network' },
  { name: 'Book Health',           icon: 'chart-pie' },
];

// Carrier portal nav — SUBMISSIONS_CHILDREN + drill-down placeholders
const CARRIER_NAV = [
  { name: 'Referral Pipeline',     icon: 'user-star' },
  { name: 'Full Pipeline',         icon: 'rows-4' },
  { name: 'Performance Metrics',   icon: 'bot' },
  { name: 'World Engine',          icon: 'orbit' },
];

// Admin nav — mirrors ADMIN_CHILDREN from navConfig.ts
const ADMIN_NAV = [
  { name: 'System Health',  icon: 'activity' },
  { name: 'Users & Roles',  icon: 'users' },
  { name: 'Configs',        icon: 'file-stack' },
  { name: 'Audit Log',      icon: 'history' },
  { name: 'Loss Register',  icon: 'file-x' },
  { name: 'Recalibration',  icon: 'trending-up-down' },
];

function SidebarFaithful({ active }) {
  return (
    <aside className="sidebar">
      <div className="sb-icon"><Icon name="panel-right-close" /></div>
      <div className="sb-icon" style={{ marginTop: 8, marginBottom: 16 }}>
        <Icon name="user" />
      </div>
      {CLIENT_NAV.map((n) => (
        <div key={n.name} className={`sb-icon ${active === n.name ? 'active' : ''}`} title={n.name}>
          <Icon name={n.icon} />
        </div>
      ))}
      <div className="sb-spacer" />
      <div className="sb-bottom">
        <Icon name="bug" />
        <Icon name="lightbulb" />
      </div>
    </aside>
  );
}

function TitleBarFaithful({ menu, right }) {
  return (
    <div className="titlebar">
      <h1>
        <span className="crumb-sep">/</span>
        <span>Client Portal</span>
        {menu && (<>
          <span className="crumb-sep">/</span>
          <span className="crumb-active">{menu}</span>
        </>)}
      </h1>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        {right}
      </div>
    </div>
  );
}

function FrameFaithful({ menu, isDark, children, titleRight }) {
  return (
    <div className={`ds-faithful ${isDark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <SidebarFaithful active={menu} />
        <div className="main">
          <TitleBarFaithful menu={menu} right={titleRight} />
          <div className="viewcanvas">{children}</div>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * FAITHFUL primitives — mirror frontend/src/components/base
 * ────────────────────────────────────────────────────────────── */

// Color from "decision" — drives header card accent.
function decisionAccent(decision) {
  // Lifted from keytermPalette logic — we use only what we need.
  if (decision === 'approve')  return 'var(--good)';
  if (decision === 'refer')    return 'var(--maybe)';
  if (decision === 'decline')  return 'var(--bad)';
  return 'var(--outline)';
}
function decisionIcon(decision) {
  if (decision === 'approve') return 'shield-check';
  if (decision === 'refer')   return 'circle-dot';
  if (decision === 'decline') return 'shield-x';
  return 'shield';
}

function SubmissionHeaderCard({
  title, subtitle, decision = 'approve', icon, children, headerRight,
}) {
  const accent = decisionAccent(decision);
  const I = icon || decisionIcon(decision);
  return (
    <div className="header-card" style={{ '--accent': accent }}>
      <div className="hc-inner">
        <div className="hc-top">
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <Icon name={I} size={32} color="var(--accent)" />
            <div>
              <div className="hc-title">{title}</div>
              {subtitle && <div className="hc-subtitle">{subtitle}</div>}
            </div>
          </div>
          {headerRight && <div style={{ color: 'var(--placeholder)' }}>{headerRight}</div>}
        </div>
        {children && <div style={{ paddingLeft: 16, paddingRight: 16, paddingTop: 8 }}>{children}</div>}
      </div>
    </div>
  );
}

function StandardCard({ title, icon, headerRight, children, style = {} }) {
  return (
    <div className="stdcard" style={style}>
      <div className="stdcard-header">
        {icon && <Icon name={icon} />}
        <span style={{ flex: 1 }}>{title}</span>
        {headerRight}
      </div>
      <div className="stdcard-body">{children}</div>
    </div>
  );
}

function StatsGrid({ columns }) {
  const cols = columns.map((c) => c.width || '1fr').join(' ');
  return (
    <div className="statsgrid" style={{ gridTemplateColumns: cols }}>
      {columns.map((c, i) => (
        <div key={`h-${i}`} className="sg-h">{c.label}</div>
      ))}
      {columns.map((c, i) => (
        <div key={`v-${i}`} className="sg-v">{c.value}</div>
      ))}
    </div>
  );
}

function KpiTile({ label, value, sub, icon, emphasis }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, marginBottom: 4 }}>
        {icon && <Icon name={icon} size={14} />}
        <span>{label}</span>
      </div>
      <div style={{
        fontSize: emphasis ? 22 : 18, fontWeight: 700,
        color: emphasis ? 'var(--text)' : 'var(--placeholder)',
      }}>{value}</div>
      {sub && <div style={{ fontSize: 11 }}>{sub}</div>}
    </div>
  );
}

function ScoreBar({ value, max = 100, thresholds = [] }) {
  const pct = Math.min(100, Math.max(2, (value / max) * 100));
  // Pick color from thresholds: first whose `at >= value`
  let color = thresholds[thresholds.length - 1]?.color || 'var(--good)';
  for (const t of thresholds) { if (value <= t.at) { color = t.color; break; } }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        flex: 1, height: 6,
        background: 'var(--bg-light)', borderRadius: 999, overflow: 'hidden',
      }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 999 }} />
      </div>
      <span style={{ fontSize: 10, fontWeight: 700, width: 32, textAlign: 'right' }}>
        {value}
      </span>
    </div>
  );
}

function CompareRow({ label, sublabel, original, scenario, changed }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 100px 24px 130px',
      padding: '6px 4px', borderBottom: '1px solid var(--outline)',
      background: changed ? 'var(--input-light)' : 'transparent',
    }}>
      <div>
        <div style={{ fontSize: 12 }}>{label}</div>
        {sublabel && <div style={{ fontSize: 10, color: 'var(--placeholder)' }}>{sublabel}</div>}
      </div>
      <span style={{ textAlign: 'right', fontSize: 12 }}>{original}</span>
      <span style={{ textAlign: 'center', fontSize: 12 }}>→</span>
      <span style={{
        textAlign: 'right', fontSize: 12, fontWeight: 700,
        color: changed ? 'var(--text)' : 'inherit',
      }}>{scenario}</span>
    </div>
  );
}

function LabelValueList({ rows }) {
  return (
    <div>
      {rows.map((r, i) => (
        <div key={i} style={{
          display: 'flex', justifyContent: 'space-between',
          fontSize: 13, padding: '3px 0',
        }}>
          <span>{r.label}</span>
          <span style={{ fontWeight: 700 }}>{r.value}</span>
        </div>
      ))}
    </div>
  );
}

function InfoPanel({ label, aside, children }) {
  return (
    <div className="infopanel">
      {(label || aside) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          {label && <span className="ip-h">{label}</span>}
          {aside && <span style={{ fontSize: 10, opacity: 0.4 }}>{aside}</span>}
        </div>
      )}
      {children}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * REIMAGINED chrome — modern but built FROM the same palette family
 * ────────────────────────────────────────────────────────────── */

function SidebarReimag({ active, nav = CLIENT_NAV }) {
  return (
    <aside className="sidebar">
      <div className="sb-logo" title="DSI">
        <div className="sb-wordmark" />
      </div>
      {nav.map((n) => (
        <div key={n.name} className={`sb-icon ${active === n.name ? 'active' : ''}`} title={n.name}>
          <Icon name={n.icon} size={20} />
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <div className="sb-icon"><Icon name="settings" size={18} /></div>
    </aside>
  );
}

function FrameReimag({ menu, children, titleRight, entity, isDark, persona = 'client' }) {
  const navMap = { client: CLIENT_NAV, broker: BROKER_NAV, carrier: CARRIER_NAV, admin: ADMIN_NAV };
  const labelMap = { client: 'Client Portal', broker: 'Broker Portal', carrier: 'Carrier Portal', admin: 'Admin Console' };
  const nav = navMap[persona] || CLIENT_NAV;
  const personaLabel = labelMap[persona] || 'Portal';
  // Avatar initials by persona.
  const avatarMap = { client: 'EK', broker: 'SA', carrier: 'JR', admin: 'MA' };
  const avatarInitials = avatarMap[persona] || 'EK';
  const badgeIcon = persona === 'broker' ? 'briefcase'
                   : persona === 'carrier' ? 'building-2'
                   : persona === 'admin' ? 'shield-check'
                   : 'building-2';
  return (
    <div className={`ds-reimag ${isDark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <SidebarReimag active={menu} nav={nav} />
        <div className="main">
          <div className="topbar">
            <div className="crumbs">
              <span>{personaLabel}</span>
              <span className="sep">/</span>
              <span className="active">{menu}</span>
            </div>
            <div className="actions">
              {titleRight}
              {entity && (
                <>
                  <div className="badge">
                    <Icon name={badgeIcon} size={13} /> {entity}
                  </div>
                  <div className="avatar">{avatarInitials}</div>
                </>
              )}
            </div>
          </div>
          <div className="work">{children}</div>
        </div>
      </div>
    </div>
  );
}

// Expose
Object.assign(window, {
  Icon, CLIENT_NAV, BROKER_NAV, CARRIER_NAV, ADMIN_NAV,
  SidebarFaithful, TitleBarFaithful, FrameFaithful,
  SubmissionHeaderCard, StandardCard, StatsGrid, KpiTile,
  ScoreBar, CompareRow, LabelValueList, InfoPanel,
  decisionAccent, decisionIcon,
  SidebarReimag, FrameReimag,
});
