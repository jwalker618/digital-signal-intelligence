/* global React, Icon, CARRIER_NAV */

/* ============================================================
 * Carrier · Submission Workbench — drill-down into a single
 * inbound submission. The carrier nav collapses; a workbench-
 * specific nav replaces it with the drill-down tab tree.
 *
 * Active submission storyline: SUB-26-0118 (Eastward Robotics ·
 * Cyber) — same insured as the Client + Broker portals so numbers
 * line up across personas.
 *
 * Tabs covered as representative artboards:
 *   • Summary
 *   • Pricing Anatomy           (Technical)
 *   • Risk Assessment           (Technical)
 *   • Loss Assessment           (Technical)
 *   • Exposure Assessment       (Technical)
 *   • Scenarios                 (Technical)
 *   • Referral Actions          (Technical)
 *   • Model Versions            (Technical)
 *   • Premium Assembly          (Commercial)
 *   • Distribution              (Commercial)
 *   • Coverage Terms            (Risk)
 *   • Deductible Structure      (Risk)
 *   • SIR & Waiting Periods     (Risk)
 *   • Aggregate & Reinstatement (Risk)
 *   • Commercial Terms          (Commercial)
 * ============================================================ */

const WB = {
  code:     'SUB-26-0118',
  entity:   'Eastward Robotics, Inc.',
  broker:   'Marsh — Northeast Specialty',
  line:     'Cyber',
  score:    724,
  tier:     2,
  tierLabel:'Standard',
  decision: 'refer',
  premium:  185200,
  limit:    10_000_000,
  deductible: 50_000,
  received: 'Apr 24, 2026',
};

/* Drill-down nav structure */
const DRILL_NAV = [
  { kind: 'leaf',  name: 'Summary',                 icon: 'gauge' },
  { kind: 'group', name: 'Commercial Terms',         icon: 'building-2',
    children: [
      { name: 'Terms Overview',   icon: 'file-text'   },
      { name: 'Premium Assembly', icon: 'calculator'  },
      { name: 'Distribution',     icon: 'network'     },
    ] },
  { kind: 'group', name: 'Risk Terms',               icon: 'scale',
    children: [
      { name: 'Deductible Structure',      icon: 'layers'     },
      { name: 'Coverage Terms',            icon: 'file-check' },
      { name: 'SIR & Waiting Periods',     icon: 'clock'      },
      { name: 'Aggregate & Reinstatement', icon: 'refresh-cw' },
    ] },
  { kind: 'group', name: 'Technical Assessment',     icon: 'chart-no-axes-gantt',
    children: [
      { name: 'Pricing Anatomy',     icon: 'calculator'  },
      { name: 'Risk Assessment',     icon: 'glasses'     },
      { name: 'Loss Assessment',     icon: 'shield-alert'},
      { name: 'Exposure Assessment', icon: 'globe'       },
      { name: 'Scenarios',           icon: 'flask-conical' },
      { name: 'Referral Actions',    icon: 'user-star'   },
      { name: 'Model Versions',      icon: 'file-stack'  },
    ] },
];

/* ============================================================
 * Workbench frame — replaces the standard FrameReimag chrome
 * with a workbench-specific sidebar + submission context strip
 * ============================================================ */
function WorkbenchFrame({ active, children, isDark }) {
  return (
    <div className={`ds-reimag ${isDark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <WorkbenchSidebar active={active} />
        <div className="main">
          <div className="topbar" style={{ height: 'auto', minHeight: 64, padding: '0 24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 0', flex: 1, minWidth: 0 }}>
              <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--ink-soft)' }}>
                <Icon name="arrow-left" size={12} /> Pipeline
              </a>
              <span style={{ color: 'var(--ink-mute)' }}>/</span>
              <code style={{ fontSize: 12, color: 'var(--ink-mute)' }}>{WB.code}</code>
              <span style={{ color: 'var(--ink-mute)' }}>·</span>
              <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>{WB.entity}</span>
              <span className="chip" style={{ fontSize: 11 }}>{WB.line}</span>
              <span className="chip chip-spot" style={{ fontSize: 11 }}>{WB.decision.toUpperCase()}</span>
              <span style={{ flex: 1 }} />
              <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
                <CtxStat label="Score" value={WB.score} tone="info" />
                <CtxStat label="Tier"  value={`T${WB.tier}`} />
                <CtxStat label="Premium" value={`$${(WB.premium / 1000).toFixed(0)}k`} />
                <span className="caption">Broker: {WB.broker}</span>
              </div>
            </div>
          </div>
          <div className="work">{children}</div>
        </div>
      </div>
    </div>
  );
}

function CtxStat({ label, value, tone }) {
  const color = tone === 'info' ? 'var(--info)' : 'var(--ink)';
  return (
    <div style={{ textAlign: 'right' }}>
      <div className="micro" style={{ fontSize: 10 }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 700, color, fontVariantNumeric: 'tabular-nums', lineHeight: 1.1 }}>{value}</div>
    </div>
  );
}

function WorkbenchSidebar({ active }) {
  // Active group is whichever group contains the active leaf
  const activeGroup = DRILL_NAV.find(n => n.kind === 'group' && n.children?.some(c => c.name === active))?.name;

  return (
    <aside className="sidebar" style={{ width: 220, alignItems: 'stretch', padding: 14 }}>
      <div className="sb-logo" style={{ alignSelf: 'center', marginBottom: 16 }} title="DSI">
        <div className="sb-wordmark" />
      </div>

      {DRILL_NAV.map((n) => (
        <div key={n.name} style={{ marginBottom: 6 }}>
          {n.kind === 'leaf' ? (
            <WbNavLeaf icon={n.icon} name={n.name} active={n.name === active} />
          ) : (
            <>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 10px',
                fontSize: 11, fontWeight: 700,
                color: 'rgba(255,255,255,0.5)',
                letterSpacing: '0.05em',
                textTransform: 'uppercase',
              }}>
                <Icon name={n.icon} size={13} />
                {n.name}
              </div>
              {(activeGroup === n.name || n.children?.some(c => c.name === active)) && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 1, paddingLeft: 6 }}>
                  {n.children.map((c) => (
                    <WbNavLeaf key={c.name} icon={c.icon} name={c.name} active={c.name === active} indent />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      ))}
    </aside>
  );
}

function WbNavLeaf({ icon, name, active, indent }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 9,
      padding: '7px 10px',
      paddingLeft: indent ? 22 : 10,
      fontSize: 12.5,
      borderRadius: 6,
      background: active ? 'rgba(255,255,255,0.08)' : 'transparent',
      color: active ? '#fff' : 'rgba(255,255,255,0.65)',
      position: 'relative',
      cursor: 'pointer',
    }}>
      {active && (
        <span style={{
          position: 'absolute', left: -14, top: 8, bottom: 8,
          width: 3, background: 'var(--spot)', borderRadius: 2,
        }} />
      )}
      <Icon name={icon} size={14} />
      <span>{name}</span>
    </div>
  );
}

/* ============================================================
 * Shared atoms for workbench tabs
 * ============================================================ */
function WbCard({ title, icon, headerRight, children, padding = 22, style }) {
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden', ...style }}>
      {title && (
        <div style={{
          padding: '12px 18px', borderBottom: '1px solid var(--rule)',
          background: 'var(--surface-elev)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {icon && <Icon name={icon} size={15} color="var(--ink-soft)" />}
            <h3 style={{ font: '600 14px/1 IBM Plex Sans', margin: 0 }}>{title}</h3>
          </div>
          {headerRight}
        </div>
      )}
      <div style={{ padding }}>{children}</div>
    </div>
  );
}
function WbKpi({ label, value, sub, tone }) {
  const color = tone === 'info' ? 'var(--info)' : tone === 'pos' ? 'var(--pos)' : tone === 'spot' ? 'var(--spot)' : tone === 'warn' ? 'var(--warn)' : 'var(--ink)';
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num" style={{ fontSize: 22, color, marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
      {sub && <div className="micro" style={{ marginTop: 2 }}>{sub}</div>}
    </div>
  );
}
function WbRow({ k, v, tone, mono, bold }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '6px 0', borderBottom: '1px solid var(--rule)' }}>
      <span className="micro">{k}</span>
      <span style={{
        fontSize: 13,
        fontWeight: bold ? 700 : 500,
        color: tone === 'info' ? 'var(--info)' : tone === 'pos' ? 'var(--pos)' : tone === 'neg' ? 'var(--neg)' : 'var(--ink)',
        fontFamily: mono ? 'ui-monospace, monospace' : 'inherit',
        fontVariantNumeric: 'tabular-nums',
      }}>{v}</span>
    </div>
  );
}

Object.assign(window, { WorkbenchFrame, WbCard, WbKpi, WbRow, WB });
