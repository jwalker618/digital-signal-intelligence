/* global React, FrameReimag, Icon, AdminTable, AdminKpi */

/* ============================================================
 * Admin Console — continued (Configs / Audit / Losses /
 *                              Recalibration list + detail)
 * ============================================================ */

const ADMIN_ORG2 = 'Hartford Mutual';

/* ─── 03 Configs ─────────────────────────────────────────────── */
function ReimAdminConfigs({ isDark }) {
  const configs = [
    { coverage: 'cyber',     name: 'signal_weights',    active: 12, drafts: 1, updated: 'today' },
    { coverage: 'cyber',     name: 'tier_thresholds',   active:  8, drafts: 0, updated: '3d ago' },
    { coverage: 'property',  name: 'signal_weights',    active:  9, drafts: 2, updated: 'yesterday' },
    { coverage: 'property',  name: 'cope_modifiers',    active:  4, drafts: 0, updated: '1w ago' },
    { coverage: 'pi',        name: 'signal_weights',    active:  6, drafts: 1, updated: '2d ago' },
    { coverage: 'do',        name: 'signal_weights',    active:  5, drafts: 0, updated: '5d ago' },
    { coverage: 'casualty',  name: 'signal_weights',    active:  7, drafts: 0, updated: '1w ago' },
    { coverage: 'marine',    name: 'signal_weights',    active:  3, drafts: 1, updated: '4d ago' },
  ];
  const history = [
    { v: 12, status: 'DEPLOYED', author: 'jordan.reyes', updated: '2026-05-21 14:08 UTC', notes: 'Adjust MFA modifier for Industrial cohort post-drift alert DA-879' },
    { v: 11, status: 'READY',    author: 'priya.bhatt',  updated: '2026-05-19 09:42 UTC', notes: 'Cohort recalibration — Q1 2026 sample' },
    { v: 10, status: 'DRAFT',    author: 'jordan.reyes', updated: '2026-05-18 16:30 UTC', notes: 'Exploration: lower weight on backup_encryption signal' },
    { v:  9, status: 'DEPRECATED', author: 'sam.lee',     updated: '2026-04-30 11:15 UTC', notes: 'Pre-Q2 baseline' },
  ];
  const statusTone = (s) => s === 'DEPLOYED' ? 'pos' : s === 'READY' ? 'info' : s === 'DRAFT' ? 'spot' : 'mute';

  return (
    <FrameReimag menu="Configs" entity={ADMIN_ORG2} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Scoring configs</div>
            <h2 className="display" style={{ marginTop: 6 }}>Signal weights + tier thresholds</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Versioned configs per coverage line. Promote from DRAFT → READY → DEPLOYED through governance.
            </div>
          </div>
          <button className="btn ghost"><Icon name="refresh-cw" size={13} /> Refresh</button>
        </div>

        {/* config list */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name="file-stack" size={16} />
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Configs · {configs.length}</h3>
            </div>
          </div>
          <AdminTable
            cols="1.4fr 2fr 100px 100px 120px"
            headers={['Coverage', 'Config', 'Active v', 'Drafts', 'Last updated']}
            rows={configs.map((c, i) => [
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12, fontWeight: 700, textTransform: 'uppercase' }}>{c.coverage}</span>,
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}>{c.name}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>v{c.active}</span>,
              c.drafts > 0
                ? <span className="chip chip-spot">{c.drafts}</span>
                : <span className="micro">—</span>,
              <span className="micro">{c.updated}</span>,
            ])}
          />
        </div>

        {/* version history (focus on cyber/signal_weights) */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <Icon name="history" size={16} />
            <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>
              Version history
            </h3>
            <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12, color: 'var(--ink-soft)' }}>
              cyber / signal_weights · {history.length} versions
            </span>
          </div>
          <AdminTable
            cols="60px 110px 1fr 130px 2fr 200px"
            headers={['v', 'Status', 'Author', 'Updated', 'Notes', 'Actions']}
            rows={history.map((v) => [
              <span style={{ fontFamily: 'ui-monospace, monospace', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>v{v.v}</span>,
              <span className={`chip chip-${statusTone(v.status)}`} style={{ justifySelf: 'flex-start' }}>{v.status}</span>,
              <code style={{ fontSize: 11, color: 'var(--ink-mute)' }}>{v.author}</code>,
              <span className="micro">{v.updated}</span>,
              <span style={{ color: 'var(--ink-soft)', fontSize: 12.5 }}>{v.notes}</span>,
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn ghost" style={{ padding: '4px 10px', fontSize: 11 }}>Validate</button>
                <button className="btn ghost" style={{ padding: '4px 10px', fontSize: 11 }}>Calibrate</button>
                {v.status === 'READY' && (
                  <button className="btn" style={{ padding: '4px 10px', fontSize: 11 }}>
                    <Icon name="shield-check" size={11} /> Deploy
                  </button>
                )}
              </div>,
            ])}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

/* ─── 04 Audit Log ─────────────────────────────────────────── */
function ReimAdminAudit({ isDark }) {
  const events = [
    { when: '14:08:32 today', action: 'CONFIG_DEPLOY',          resource: 'config_version · v12 (cyber/signal_weights)',     user: 'jordan.r', latency: 142, expanded: true },
    { when: '13:55:01 today', action: 'RECALIBRATION_APPROVE',  resource: 'proposal · RP-9842',                              user: 'marcus.a', latency: 89,  expanded: false },
    { when: '13:42:18 today', action: 'USER_INVITE',            resource: 'user · sasha.morales@marsh.com',                  user: 'marcus.a', latency: 64,  expanded: false },
    { when: '11:08:44 today', action: 'SUBMISSION_DECIDE',      resource: 'submission · SUB-26-0144 (Lumina Software)',      user: 'jordan.r', latency: 38,  expanded: false },
    { when: '09:42:11 today', action: 'CONFIG_DRAFT',           resource: 'config_version · v10 (cyber/signal_weights)',     user: 'jordan.r', latency: 24,  expanded: false },
    { when: '08:30:55 today', action: 'LOSS_IMPORT',            resource: 'loss_batch · 142 events',                         user: 'priya.b',  latency: 1842, expanded: false },
  ];

  return (
    <FrameReimag menu="Audit Log" entity={ADMIN_ORG2} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Audit log</div>
            <h2 className="display" style={{ marginTop: 6 }}>Everything that changed</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Every config deploy, decision, user action, recalibration approval. Click an event to see the before / after diff.
            </div>
          </div>
          <button className="btn"><Icon name="download" size={13} /> Export CSV</button>
        </div>

        {/* filters */}
        <div className="card" style={{ padding: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr auto auto', gap: 12, alignItems: 'flex-end' }}>
            <FilterField label="Action">CONFIG_DEPLOY</FilterField>
            <FilterField label="Resource">config_version</FilterField>
            <FilterField label="From">2026-05-01</FilterField>
            <FilterField label="To">2026-05-28</FilterField>
            <button className="btn">Apply</button>
            <button className="btn ghost">Reset</button>
          </div>
        </div>

        {/* events table with one expanded diff */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'grid', gridTemplateColumns: '160px 1.4fr 2.2fr 120px 100px',
            background: 'var(--surface-elev)',
            padding: '10px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['When', 'Action', 'Resource', 'User', 'Latency'].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 11, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {events.map((e, i) => (
            <React.Fragment key={i}>
              <div style={{
                display: 'grid', gridTemplateColumns: '160px 1.4fr 2.2fr 120px 100px',
                gap: 0, alignItems: 'center',
                padding: '12px 20px',
                borderBottom: i < events.length - 1 || e.expanded ? '1px solid var(--rule)' : 0,
                fontSize: 13,
                background: e.expanded ? 'var(--surface-elev)' : 'transparent',
              }}>
                <span className="micro" style={{ fontVariantNumeric: 'tabular-nums' }}>{e.when}</span>
                <code style={{ fontSize: 12, fontWeight: 700 }}>{e.action}</code>
                <span style={{ color: 'var(--ink-soft)' }}>{e.resource}</span>
                <code style={{ fontSize: 11, color: 'var(--ink-mute)' }}>{e.user}</code>
                <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{e.latency} ms</span>
              </div>
              {e.expanded && (
                <div style={{
                  padding: '14px 20px',
                  background: 'var(--surface-sunken)',
                  borderBottom: i < events.length - 1 ? '1px solid var(--rule)' : 0,
                }}>
                  <div className="eyebrow" style={{ marginBottom: 10 }}>State diff</div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <DiffPanel
                      label="Before"
                      tone="neg"
                      json={`{
  "mfa_admin_modifier": 0.92,
  "backup_enc_modifier": 0.95,
  "soc2_modifier": 0.88,
  "version": 11
}`}
                    />
                    <DiffPanel
                      label="After"
                      tone="pos"
                      json={`{
  "mfa_admin_modifier": 0.94,
  "backup_enc_modifier": 0.97,
  "soc2_modifier": 0.86,
  "version": 12
}`}
                    />
                  </div>
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </FrameReimag>
  );
}

function FilterField({ label, children }) {
  return (
    <div>
      <div className="micro" style={{ marginBottom: 4 }}>{label}</div>
      <div style={{
        padding: '8px 12px', fontSize: 13,
        background: 'var(--surface)',
        border: '1px solid var(--rule-strong)',
        borderRadius: 6,
        fontFamily: 'ui-monospace, monospace',
      }}>{children}</div>
    </div>
  );
}

function DiffPanel({ label, tone, json }) {
  const color = tone === 'neg' ? 'var(--neg)' : 'var(--pos)';
  return (
    <div style={{
      padding: 12,
      background: 'var(--surface)',
      border: '1px solid ' + color,
      borderRadius: 8,
    }}>
      <div className="eyebrow" style={{ color, marginBottom: 6 }}>{label}</div>
      <pre style={{
        font: '11.5px ui-monospace, monospace',
        margin: 0, color: 'var(--ink)',
        whiteSpace: 'pre-wrap', lineHeight: 1.5,
      }}>{json}</pre>
    </div>
  );
}

/* ─── 05 Loss Register ─────────────────────────────────────── */
function ReimAdminLosses({ isDark }) {
  const losses = [
    { entity: 'TerraWind Energy',     coverage: 'property',  date: '2025-12-08', gross:  4_200_000, net: 3_100_000, status: 'CLOSED',   linked: true  },
    { entity: 'AscendCare Health',    coverage: 'medprof',   date: '2025-11-22', gross:    840_000, net:   720_000, status: 'CLOSED',   linked: true  },
    { entity: 'Vector Manufacturing', coverage: 'workers',   date: '2025-10-15', gross:    320_000, net:   320_000, status: 'CLOSED',   linked: true  },
    { entity: 'BrightLeaf Pharma',    coverage: 'product',   date: '2025-09-30', gross:  1_650_000, net: 1_650_000, status: 'OPEN',     linked: false },
    { entity: 'NorthRiver Logistics', coverage: 'marine',    date: '2025-08-14', gross:    580_000, net:   430_000, status: 'CLOSED',   linked: true  },
    { entity: 'Eastward Robotics',    coverage: 'cyber',     date: '2025-07-02', gross:     94_000, net:    44_000, status: 'CLOSED',   linked: true  },
    { entity: 'Lumina Software',      coverage: 'cyber',     date: '2025-06-22', gross:    220_000, net:   170_000, status: 'PENDING',  linked: false },
    { entity: 'Aurora Energy',        coverage: 'casualty',  date: '2025-05-18', gross:    760_000, net:   612_000, status: 'CLOSED',   linked: true  },
  ];
  const statusTone = (s) => s === 'OPEN' ? 'spot' : s === 'PENDING' ? 'warn' : 'pos';
  const totalGross = losses.reduce((s, l) => s + l.gross, 0);
  const unlinked = losses.filter(l => !l.linked).length;

  return (
    <FrameReimag menu="Loss Register" entity={ADMIN_ORG2} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Loss register</div>
            <h2 className="display" style={{ marginTop: 6 }}>Loss events feeding recalibration</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Import claims via CSV; we'll attempt to attach them back to the submissions that priced them.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 24 }}>
            <AdminKpi label="Events"     value={losses.length} />
            <AdminKpi label="Gross"      value={`$${(totalGross / 1_000_000).toFixed(2)}M`} />
            <AdminKpi label="Unlinked"   value={unlinked} tone="warn" />
            <AdminKpi label="Open"       value={losses.filter(l => l.status === 'OPEN').length} tone="spot" />
          </div>
        </div>

        {/* import + filter bar */}
        <div className="card" style={{ padding: 16, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="upload-cloud" size={18} color="var(--ink-soft)" />
            <span style={{ fontSize: 13, fontWeight: 600 }}>Drop a CSV here</span>
            <span className="caption">or</span>
            <button className="btn ghost" style={{ padding: '6px 12px', fontSize: 12 }}>Browse</button>
          </div>
          <div style={{ width: 1, alignSelf: 'stretch', background: 'var(--rule)' }} />
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flex: 1 }}>
            <span className="micro">Filter:</span>
            <span className="chip">All</span>
            <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>Unlinked ({unlinked})</span>
            <span className="chip">Open</span>
            <span style={{ flex: 1 }} />
            <button className="btn"><Icon name="link" size={13} /> Link all</button>
          </div>
        </div>

        {/* losses table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <AdminTable
            cols="2fr 1fr 1.2fr 1fr 1fr 110px 90px"
            headers={['Entity', 'Coverage', 'Event date', 'Gross', 'Net', 'Status', 'Linked']}
            rows={losses.map((l) => [
              <span style={{ fontWeight: 600 }}>{l.entity}</span>,
              <code style={{ fontSize: 12 }}>{l.coverage}</code>,
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}>{l.date}</span>,
              <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>${(l.gross / 1000).toFixed(0)}k</span>,
              <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', color: 'var(--ink-soft)' }}>${(l.net / 1000).toFixed(0)}k</span>,
              <span className={`chip chip-${statusTone(l.status)}`} style={{ justifySelf: 'flex-start' }}>{l.status}</span>,
              l.linked
                ? <span className="chip chip-pos" style={{ padding: '2px 8px' }}><Icon name="check" size={10} /> yes</span>
                : <span className="chip chip-spot" style={{ padding: '2px 8px' }}>no</span>,
            ])}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimAdminConfigs, ReimAdminAudit, ReimAdminLosses });
