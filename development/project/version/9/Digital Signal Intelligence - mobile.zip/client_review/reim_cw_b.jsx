/* global React, Icon, ClientWorkbenchFrame, WbCard, WbKpi, WbRow, CW, tierColor, decisionTone */

/* ============================================================
 * Client Workbench tabs — group B (Risk Signals)
 *   • Score & Cohort    (composite + cohort context + history + impact)
 *   • Loss Profile      (propensity, velocities, loss-event history)
 *   • Exposure Profile  (value, band, complexity, YoY)
 * ============================================================ */

/* ─── 05 Score & Cohort ──────────────────────────────────────── */
function CwScore({ isDark }) {
  const cyber = CW.coverages[0]; // featured line
  // score history (version → composite)
  const history = [
    { v: 'v1', score: 690 }, { v: 'v2', score: 702 }, { v: 'v3', score: 706 }, { v: 'v4', score: 724 },
  ];
  const impact = [
    { label: 'MFA enforced (Okta)',        delta: +14, kind: 'up' },
    { label: 'EDR coverage 95.6%',         delta: +9,  kind: 'up' },
    { label: 'No prior cyber claims (5yr)',delta: +8,  kind: 'up' },
    { label: 'Public RDP host exposed',    delta: -7,  kind: 'down' },
    { label: 'SOC 2 Type II not on file',  delta: -11, kind: 'down' },
  ];
  const maxAbs = Math.max(...impact.map(i => Math.abs(i.delta)));

  // mini line chart geometry
  const W = 520, H = 150, padL = 40, padB = 26, padT = 14;
  const lo = 660, hi = 760;
  const x = (i) => padL + (i / (history.length - 1)) * (W - padL - 20);
  const y = (s) => H - padB - ((s - lo) / (hi - lo)) * (H - padB - padT);
  const path = history.map((p, i) => `${i === 0 ? 'M' : 'L'} ${x(i)} ${y(p.score)}`).join(' ');

  return (
    <ClientWorkbenchFrame active="Score & Cohort" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 1fr', gap: 12 }}>
          <CwKpi label="Composite" value={cyber.score} tone="info" sub={`pure ${cyber.pure}`} />
          <CwKpi label="Tier" value={`T${cyber.tier}`} sub={cyber.tierLabel} />
          <CwKpi label="Percentile" value={`${cyber.percentile}th`} sub={`cohort of ${cyber.cohortSize}`} />
          <CwKpi label="Cohort median" value={cyber.cohortMedian} sub="industry · Cyber" />
          <CwKpi label="Top decile" value={cyber.cohortTopDecile} sub="cohort ceiling" />
          <CwKpi label="vs last" value={`+${cyber.score - cyber.prevScore}`} tone="pos" sub={`from ${cyber.prevScore}`} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 14 }}>
          {/* score history */}
          <WbCard title="Score history · Cyber" icon="trending-up-down" headerRight={<span className="chip chip-pos">+34 over 4 versions</span>}>
            <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
              {[660, 685, 710, 735, 760].map(s => (
                <g key={s}>
                  <line x1={padL} y1={y(s)} x2={W - 20} y2={y(s)} stroke="var(--rule)" />
                  <text x={padL - 6} y={y(s) + 3} textAnchor="end" style={{ font: '9.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{s}</text>
                </g>
              ))}
              {/* cohort median reference */}
              <line x1={padL} y1={y(cyber.cohortMedian)} x2={W - 20} y2={y(cyber.cohortMedian)} stroke="var(--ink-mute)" strokeDasharray="4 4" />
              <text x={W - 22} y={y(cyber.cohortMedian) - 4} textAnchor="end" style={{ font: '9.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>cohort median {cyber.cohortMedian}</text>
              <path d={path} fill="none" stroke="var(--info)" strokeWidth="2.5" />
              {history.map((p, i) => (
                <g key={p.v}>
                  <circle cx={x(i)} cy={y(p.score)} r={i === history.length - 1 ? 6 : 3.5} fill="var(--info)" stroke="var(--surface)" strokeWidth={i === history.length - 1 ? 2.5 : 0} />
                  <text x={x(i)} y={H - 8} textAnchor="middle" style={{ font: '9.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{p.v}</text>
                </g>
              ))}
            </svg>
          </WbCard>

          {/* impact breakdown */}
          <WbCard title="Impact breakdown" icon="list-checks" headerRight={<span className="chip">top drivers</span>}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
              {impact.map((it) => (
                <div key={it.label} style={{ display: 'grid', gridTemplateColumns: '1fr 120px 44px', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{it.label}</span>
                  <div style={{ display: 'flex', justifyContent: 'center', position: 'relative', height: 8 }}>
                    <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, background: 'var(--rule)' }} />
                    <div style={{
                      position: 'absolute', top: 1, height: 6, borderRadius: 3,
                      background: it.kind === 'up' ? 'var(--pos)' : 'var(--neg)',
                      width: `${(Math.abs(it.delta) / maxAbs) * 50}%`,
                      left: it.kind === 'up' ? '50%' : undefined,
                      right: it.kind === 'down' ? '50%' : undefined,
                    }} />
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, textAlign: 'right', color: it.kind === 'up' ? 'var(--pos)' : 'var(--neg)', fontVariantNumeric: 'tabular-nums' }}>
                    {it.delta > 0 ? '+' : '−'}{Math.abs(it.delta)}
                  </span>
                </div>
              ))}
            </div>
          </WbCard>
        </div>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 06 Loss Profile ────────────────────────────────────────── */
function CwLoss({ isDark }) {
  // Eastward has a clean cyber history; one minor PI matter on record.
  const events = [
    { date: '2023 Q2', line: 'PI',    incurred: 84000,  paid: 84000, cause: 'Client dispute — delayed integration milestone', status: 'Closed' },
  ];
  const trends = [
    { label: 'Overall',   trend: 'Improving', delta: '−2.4', prev: 36.1, cur: 33.7 },
    { label: 'Frequency', trend: 'Improving', delta: '−1.9', prev: 30.4, cur: 28.5 },
    { label: 'Severity',  trend: 'Stable',    delta: '−0.5', prev: 41.8, cur: 41.3 },
  ];

  return (
    <ClientWorkbenchFrame active="Loss Profile" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 12 }}>
          <CwKpi label="Propensity" value="LOW" tone="pos" />
          <CwKpi label="Band" value="Very low" />
          <CwKpi label="Combined mod" value="0.92x" tone="pos" />
          <CwKpi label="Freq mult" value="0.94x" />
          <CwKpi label="Sev mult" value="0.98x" />
          <CwKpi label="Confidence" value="84%" />
          <CwKpi label="Cohort" value="Ind · Cyber" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title="Loss trajectory" icon="trending-up" padding={18}>
            {trends.map((t, i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 12, alignItems: 'center',
                padding: '11px 0', borderBottom: i < trends.length - 1 ? '1px solid var(--rule)' : 0,
              }}>
                <span style={{ fontSize: 13, fontWeight: 600 }}>{t.label}</span>
                <span className="micro">{t.prev} → {t.cur}</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 700, color: t.trend === 'Stable' ? 'var(--ink-soft)' : 'var(--pos)' }}>
                  <Icon name={t.trend === 'Stable' ? 'minus' : 'trending-down'} size={13} />
                  {t.delta}
                </span>
              </div>
            ))}
            <div className="caption" style={{ marginTop: 12 }}>Loss velocity is negative (improving) on frequency; severity broadly flat.</div>
          </WbCard>

          <WbCard title="Modifiers" icon="sliders-horizontal" padding={18}>
            <WbRow k="Frequency multiplier" v="0.94x" tone="pos" />
            <WbRow k="Severity multiplier"  v="0.98x" tone="pos" />
            <WbRow k="Combined modifier"    v="0.92x" tone="pos" bold />
            <WbRow k="Loss cohort"          v="Industrial · Cyber" />
            <WbRow k="Model confidence"     v="84%" />
            <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--rule)' }} className="caption">
              The combined 0.92x modifier is a net credit — Eastward prices below the loss-neutral line.
            </div>
          </WbCard>
        </div>

        <WbCard title="Loss event history" icon="shield-alert" headerRight={<span className="chip">{events.length} on record · 5yr</span>}>
          <div style={{
            display: 'grid', gridTemplateColumns: '90px 70px 110px 110px 1fr 90px',
            padding: '0 0 8px', borderBottom: '1px solid var(--rule)',
          }}>
            {['Date', 'Line', 'Incurred', 'Paid', 'Cause', 'Status'].map(h => (
              <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {events.map((e, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '90px 70px 110px 110px 1fr 90px',
              alignItems: 'center', padding: '11px 0', fontSize: 13,
            }}>
              <span className="micro">{e.date}</span>
              <span style={{ fontWeight: 600 }}>{e.line}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>${(e.incurred / 1000).toFixed(0)}k</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>${(e.paid / 1000).toFixed(0)}k</span>
              <span style={{ color: 'var(--ink-soft)', fontSize: 12.5 }}>{e.cause}</span>
              <span className="chip chip-pos" style={{ justifySelf: 'flex-start' }}>{e.status}</span>
            </div>
          ))}
          <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--rule)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon name="check-circle-2" size={15} color="var(--pos)" />
            <span style={{ fontSize: 13, color: 'var(--ink-soft)' }}>No cyber or D&O losses in the trailing 5 years.</span>
          </div>
        </WbCard>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 07 Exposure Profile ────────────────────────────────────── */
function CwExposure({ isDark }) {
  const value = 118_000_000, prior = 104_000_000;
  const yoy = ((value - prior) / prior * 100).toFixed(1);
  const bandPct = 0.52; // position within mid-market band
  const boundaries = [
    { label: 'Small',      min: 0,    max: 25,   modifier: '0.92x' },
    { label: 'Mid-market', min: 25,   max: 250,  modifier: '1.04x', active: true },
    { label: 'Large',      min: 250,  max: 1000, modifier: '1.18x' },
  ];

  return (
    <ClientWorkbenchFrame active="Exposure Profile" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
          <CwKpi label="Exposure value" value="$118M" tone="info" />
          <CwKpi label="Band" value="Mid-market" sub="$25M – $250M" />
          <CwKpi label="Size score" value="64" />
          <CwKpi label="Complexity" value="47" />
          <CwKpi label="Modifier" value="1.04x" />
          <CwKpi label="YoY" value={`+${yoy}%`} tone="warn" sub={`from $${(prior / 1_000_000).toFixed(0)}M`} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title="Band position" icon="gauge" padding={18}>
            <div className="caption" style={{ marginBottom: 16 }}>Where Eastward sits within the mid-market band</div>
            <div style={{ position: 'relative', height: 36 }}>
              <div style={{ position: 'absolute', left: 0, right: 0, top: 14, height: 8, borderRadius: 4, background: 'var(--surface-sunken)', border: '1px solid var(--rule)' }} />
              <div style={{ position: 'absolute', left: `${bandPct * 100}%`, top: 0, bottom: 0, width: 2, background: 'var(--info)', transform: 'translateX(-50%)' }} />
              <div style={{ position: 'absolute', left: `${bandPct * 100}%`, top: -22, transform: 'translateX(-50%)', fontSize: 11, fontWeight: 700, color: 'var(--info)', whiteSpace: 'nowrap' }}>$118M</div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--ink-mute)', marginTop: 8 }}>
              <span>$25M floor</span><span>$250M ceiling</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
              <CwKpi label="Band percentile" value="52%" plain />
              <CwKpi label="Below ceiling" value="$132M" plain />
              <CwKpi label="Above floor" value="$93M" plain />
            </div>
          </WbCard>

          <WbCard title="Band boundaries" icon="layers" padding={18}>
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr 1.4fr 80px',
              padding: '0 0 8px', borderBottom: '1px solid var(--rule)',
            }}>
              {['Band', 'Range', 'Modifier'].map(h => <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>)}
            </div>
            {boundaries.map((b, i) => (
              <div key={b.label} style={{
                display: 'grid', gridTemplateColumns: '1fr 1.4fr 80px', alignItems: 'center',
                padding: '12px 0', borderBottom: i < boundaries.length - 1 ? '1px solid var(--rule)' : 0,
                background: b.active ? 'var(--info-soft)' : undefined,
                borderRadius: b.active ? 6 : 0,
                paddingLeft: b.active ? 8 : 0, marginLeft: b.active ? -8 : 0,
              }}>
                <span style={{ fontSize: 13, fontWeight: b.active ? 700 : 500, color: b.active ? 'var(--info-deep)' : 'var(--ink)' }}>
                  {b.label}{b.active ? ' ·' : ''}{b.active ? ' you' : ''}
                </span>
                <span style={{ fontSize: 12.5, color: 'var(--ink-soft)', fontVariantNumeric: 'tabular-nums' }}>${b.min}M – ${b.max}M</span>
                <span style={{ fontSize: 13, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{b.modifier}</span>
              </div>
            ))}
            <div className="caption" style={{ marginTop: 12 }}>At $118M, Eastward is squarely mid-market — the 1.04x modifier reflects scale, not complexity.</div>
          </WbCard>
        </div>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* shared KPI used across group-B tabs — wraps shared <Kpi>. */
function CwKpi({ plain, ...rest }) {
  return <Kpi {...rest} surface={plain ? 'plain' : 'card'} />;
}

Object.assign(window, { CwScore, CwLoss, CwExposure });
