/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, BROKER_CAT_PERILS */

/* ============================================================
 * 09. Risk Aggregation — book-level concentration analysis
 *
 * Layout
 *   row 1 — title + KPIs
 *   row 2 — diversification score with narrative
 *   row 3 — industry + line concentration bars (2 columns)
 *   row 4 — CAT peril exposure grid (6 perils)
 * ============================================================ */

function ReimBrokerAggregation({ isDark }) {
  // industry concentration
  const byIndustry = {};
  for (const p of BROKER_BOOK) {
    byIndustry[p.vertical] = (byIndustry[p.vertical] || 0) + p.premium;
  }
  const total = BROKER_BOOK.reduce((s, p) => s + p.premium, 0);
  const industries = Object.entries(byIndustry)
    .map(([name, premium]) => ({ name, premium, share: premium / total * 100, count: BROKER_BOOK.filter(p => p.vertical === name).length }))
    .sort((a, b) => b.premium - a.premium);

  // line concentration
  const byLine = {};
  for (const p of BROKER_BOOK) {
    byLine[p.line] = (byLine[p.line] || 0) + p.premium;
  }
  const lines = Object.entries(byLine)
    .map(([name, premium]) => ({ name, premium, share: premium / total * 100, count: BROKER_BOOK.filter(p => p.line === name).length }))
    .sort((a, b) => b.premium - a.premium);

  const diversification = 68;  // composite

  return (
    <FrameReimag menu="Risk Aggregation" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Risk aggregation</div>
            <h2 className="display" style={{ marginTop: 6 }}>Where your book concentrates</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Industry + line concentration plus how a peril event would propagate through your book.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 28 }}>
            <KpiSnug label="Total premium" value={`$${(total / 1_000_000).toFixed(2)}M`} />
            <KpiSnug label="Industries"    value={industries.length} />
            <KpiSnug label="Lines"         value={lines.length} />
            <KpiSnug label="Diversification" value={`${diversification}/100`} tone="info" />
          </div>
        </div>

        {/* diversification + narrative */}
        <div className="card-info" style={{ padding: 22, display: 'grid', gridTemplateColumns: '160px 1fr', gap: 20, alignItems: 'center' }}>
          <div style={{ position: 'relative', width: 160, height: 80 }}>
            <svg viewBox="0 0 160 80" style={{ width: '100%', height: '100%' }}>
              <path d="M10,75 A 70,70 0 0,1 150,75" fill="none" stroke="var(--surface)" strokeWidth="12" strokeLinecap="round" />
              <path
                d={`M10,75 A 70,70 0 0,1 ${10 + (diversification / 100) * 140},${75 - Math.sin(Math.PI * diversification / 100) * 70}`}
                fill="none" stroke="var(--info)" strokeWidth="12" strokeLinecap="round"
              />
              <text x="80" y="62" textAnchor="middle" style={{ font: '700 28px IBM Plex Sans', fill: 'var(--info-deep)' }}>
                {diversification}
              </text>
              <text x="80" y="78" textAnchor="middle" style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-soft)' }}>
                of 100
              </text>
            </svg>
          </div>
          <div>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Diversification score</div>
            <h3 style={{ font: '600 18px/1.3 IBM Plex Sans', margin: '6px 0 0' }}>
              Reasonably diversified, with one concentration risk
            </h3>
            <div className="body" style={{ marginTop: 6, fontSize: 13.5 }}>
              Your book spans 5 industries and 8 lines, which is healthy. Industrial Robotics is the
              largest at <strong>30%</strong> of premium — a peril or industry-specific event would
              hit harder than ideal. Diversifying into 1-2 more verticals would push the score above 80.
            </div>
          </div>
        </div>

        {/* concentration bars */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <ConcentrationCard
            title="Industry concentration"
            entries={industries}
            warn={(e) => e.share > 30}
          />
          <ConcentrationCard
            title="Coverage-line concentration"
            entries={lines}
            warn={(e) => e.share > 30}
          />
        </div>

        {/* CAT peril exposure */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow">CAT peril exposure</div>
              <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                How an event in each peril would propagate
              </h3>
            </div>
            <span className="caption">Severity = % of book at meaningful exposure</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {BROKER_CAT_PERILS.map((p) => <PerilCard key={p.slug} p={p} />)}
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function ConcentrationCard({ title, entries, warn }) {
  const max = Math.max(...entries.map(e => e.share));
  return (
    <div className="card" style={{ padding: 22 }}>
      <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: '0 0 14px' }}>{title}</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {entries.map((e) => {
          const isWarn = warn(e);
          return (
            <div key={e.name}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span style={{ fontSize: 13, fontWeight: 600 }}>{e.name}</span>
                <span style={{ fontSize: 13, fontVariantNumeric: 'tabular-nums', color: isWarn ? 'var(--warn)' : 'var(--ink)', fontWeight: 600 }}>
                  {e.share.toFixed(0)}% <span className="micro" style={{ fontWeight: 400 }}>({e.count})</span>
                </span>
              </div>
              <div style={{ height: 6, background: 'var(--surface-sunken)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  width: `${(e.share / max) * 100}%`, height: '100%',
                  background: isWarn ? 'var(--warn)' : 'var(--info)',
                }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PerilCard({ p }) {
  const sev = p.severity * 100;
  const tone = sev >= 60 ? 'neg' : sev >= 40 ? 'warn' : 'pos';
  const toneColor = tone === 'neg' ? 'var(--neg)' : tone === 'warn' ? 'var(--warn)' : 'var(--pos)';
  return (
    <div style={{
      padding: 16,
      background: 'var(--surface-elev)',
      border: '1px solid var(--rule)',
      borderRadius: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
        <Icon name={p.icon} size={16} color={toneColor} />
        <span style={{ fontSize: 13.5, fontWeight: 700 }}>{p.name}</span>
      </div>
      <div className="micro" style={{ marginBottom: 2 }}>Book-relative severity</div>
      <div className="num" style={{ fontSize: 26, color: toneColor, fontVariantNumeric: 'tabular-nums' }}>{Math.round(sev)}%</div>
      <div style={{ height: 5, background: 'var(--surface-sunken)', borderRadius: 3, overflow: 'hidden', marginTop: 6 }}>
        <div style={{ width: `${sev}%`, height: '100%', background: toneColor }} />
      </div>
      <div className="micro" style={{ marginTop: 8 }}>
        {p.exposedPolicies} polic{p.exposedPolicies === 1 ? 'y' : 'ies'} exposed · ${(p.exposedPremiumUsd / 1000).toFixed(0)}k
      </div>
      <div className="caption" style={{ fontSize: 11, marginTop: 4 }}>
        Top verticals: <strong>{p.topVerticals.join(', ')}</strong>
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerAggregation });
