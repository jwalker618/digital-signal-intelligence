/* global BROKER, BROKER_BOOK, BROKER_QUERIES, bookByClient,
   CARRIER_ORG, CARRIER_SUBMISSIONS, WE_ALERTS, WE_SCENARIOS */

/* ============================================================
 * feed_data.js — the mobile companion's single source of truth.
 *
 * The desktop app spans dozens of pages per persona. The phone shows
 * ONE continuous intelligence feed, so every persona is collapsed into
 * the same shape:
 *
 *   { persona, org, brief, score, awaiting[], glance[], threads[], feed[] }
 *
 * buildFeed(persona) reads the shared desktop mocks and distils them
 * down to only what you'd actually check on a phone. Numbers stay
 * consistent with the desktop so the two read as one product.
 * ============================================================ */

const fmtUsd = (n) => {
  if (n >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return '$' + Math.round(n / 1e3) + 'k';
  return '$' + n;
};

/* Map a raw signal score (≈550–800 in the data) onto a 0–1 ring fill. */
const scoreFrac = (v) => Math.max(0.04, Math.min(1, (v - 500) / 300));
const scoreBand = (v) => (v >= 720 ? 'Strong' : v >= 680 ? 'Healthy' : v >= 640 ? 'Watch' : 'Fragile');

/* A deterministic little sparkline that trends toward `end`. */
function spark(end, swing, n = 14) {
  const out = [];
  let v = end - swing * 1.1;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1);
    const wobble = Math.sin(i * 1.7) * swing * 0.28 * (1 - t);
    v = end - swing * (1 - t) + wobble;
    out.push(Math.round(v));
  }
  out[n - 1] = end;
  return out;
}

// ───────────────────────────────────────────────────────────── broker
function brokerFeed() {
  const policies = BROKER_BOOK;
  const clients = bookByClient();
  const totalPrem = policies.reduce((s, p) => s + p.premium, 0);
  const avg = Math.round(policies.reduce((s, p) => s + p.score, 0) / policies.length);
  const onYou = BROKER_QUERIES.filter((q) => q.awaiting === 'broker');
  const renew30 = policies.filter((p) => p.renewalDays <= 30);
  const renewClients = [...new Set(renew30.map((p) => p.entity))];
  const tiers = [1, 2, 3, 4, 5].map((t) => policies.filter((p) => p.tier === t).length);

  return {
    persona: 'broker',
    org: { name: 'Marsh', sub: 'Northeast Specialty', glyph: 'briefcase', initials: 'M' },
    greeting: 'Good morning, Dana',
    brief: `${onYou.length} things need you today. Book signal is up 4 points this week, and BrightLeaf renews in 14 days.`,
    climate: { label: 'Book climate', value: scoreBand(avg), tone: 'pos' },
    score: {
      value: avg, label: 'Book signal', frac: scoreFrac(avg),
      delta: '+4', dir: 'up', tone: 'pos',
      caption: `Average across ${policies.length} policies · ${clients.length} clients`,
      spark: spark(avg, 22),
      movers: [
        { text: 'Eastward Robotics rebound on MFA attestation', delta: '+12', dir: 'up', tone: 'pos' },
        { text: 'BrightLeaf Pharma drift on open recall items', delta: '−7', dir: 'down', tone: 'neg' },
      ],
    },
    awaiting: onYou.map((q) => ({
      id: q.refCode, title: q.entity, line: q.line, carrier: q.carrier,
      sub: q.ask, age: q.age, tone: 'spot', cta: 'Action',
    })),
    glance: [
      { key: 'prem', label: 'Aggregate premium', value: fmtUsd(totalPrem), sub: 'annual, in force', tone: 'info', icon: 'layers' },
      { key: 'pol', label: 'Policies in force', value: String(policies.length), sub: `${clients.length} clients`, tone: 'ink', icon: 'shield-check' },
      { key: 'renew', label: 'Renewals < 30d', value: String(renewClients.length), sub: renewClients.join(' · '), tone: 'spot', icon: 'calendar-clock' },
      { key: 'tier', label: 'Tier mix', kind: 'tiermix', bars: tiers, tone: 'aux', icon: 'bar-chart-3' },
    ],
    threads: BROKER_QUERIES.slice(0, 5).map((q) => ({
      id: q.refCode, who: q.entity, sub: `${q.carrier} · ${q.line}`,
      ask: q.ask, age: q.age,
      awaiting: q.awaiting,
      label: q.awaiting === 'broker' ? 'awaiting you' : q.awaiting === 'client' ? 'awaiting client' : 'resolved',
      tone: q.awaiting === 'broker' ? 'spot' : q.awaiting === 'client' ? 'info' : 'pos',
      messages: threadFor(q),
    })),
    feed: [
      { id: 'f1', icon: 'trending-up', tone: 'pos', title: 'Eastward Robotics · Cyber', text: 'Signal rose +12 to 724 after MFA AAL2 attestation cleared.', time: '2h' },
      { id: 'f2', icon: 'cloud-lightning', tone: 'warn', title: 'Market · Property', text: 'Hurricane Wendell aftershock — coastal capacity tightening into Q2.', time: '5h' },
      { id: 'f3', icon: 'calendar-clock', tone: 'spot', title: 'BrightLeaf Pharma', text: 'Renews in 14 days with 3 open items. Recommend escalating recall reserves.', time: '1d' },
      { id: 'f4', icon: 'lightbulb', tone: 'aux', title: 'Coverage gap · TerraWind', text: 'Energy peers of this scale carry standalone Cyber. TerraWind does not.', time: '1d' },
      { id: 'f5', icon: 'circle-check', tone: 'pos', title: 'AscendCare Health · D&O', text: 'Bound with Chubb at $95k. Thread closed.', time: '2d' },
    ],
  };
}

// ───────────────────────────────────────────────────────────── client
function clientFeed() {
  const mine = BROKER_BOOK.filter((p) => p.entity === 'Eastward Robotics');
  const totalPrem = mine.reduce((s, p) => s + p.premium, 0);
  const avg = Math.round(mine.reduce((s, p) => s + p.score, 0) / mine.length);
  const qs = BROKER_QUERIES.filter((q) => q.entity === 'Eastward Robotics');
  const onClient = qs.filter((q) => q.awaiting === 'client');
  const renewDays = Math.min(...mine.map((p) => p.renewalDays));

  return {
    persona: 'client',
    org: { name: 'Eastward Robotics', sub: 'Industrial Robotics', glyph: 'bot', initials: 'ER' },
    greeting: 'Good morning, Priya',
    brief: `Your signal is healthy and trending up. ${onClient.length} requests from your broker are waiting on you before renewal in ${renewDays} days.`,
    climate: { label: 'Standing', value: scoreBand(avg), tone: 'pos' },
    score: {
      value: avg, label: 'Your signal', frac: scoreFrac(avg),
      delta: '+12', dir: 'up', tone: 'pos',
      caption: `64th percentile among Industrial Robotics peers`,
      spark: spark(avg, 28),
      movers: [
        { text: 'MFA AAL2 attestation accepted by Hartford', delta: '+12', dir: 'up', tone: 'pos' },
        { text: 'D&O placement still in review with Chubb', delta: 'hold', dir: 'flat', tone: 'warn' },
      ],
    },
    awaiting: onClient.map((q) => ({
      id: q.refCode, title: q.line + ' submission', line: q.line, carrier: q.carrier,
      sub: q.ask, age: q.age, tone: 'spot', cta: 'Provide',
    })),
    glance: [
      { key: 'prem', label: 'Total premium', value: fmtUsd(totalPrem), sub: 'across 3 policies', tone: 'info', icon: 'layers' },
      { key: 'cov', label: 'Active coverages', value: String(mine.length), sub: 'Cyber · PI · D&O', tone: 'ink', icon: 'shield-check' },
      { key: 'renew', label: 'Renewal in', value: renewDays + 'd', sub: 'all lines align', tone: 'spot', icon: 'calendar-clock' },
      { key: 'pct', label: 'Peer standing', value: '64th', sub: 'percentile, improving', tone: 'aux', icon: 'trending-up' },
    ],
    threads: qs.map((q) => ({
      id: q.refCode, who: q.line + ' · ' + q.carrier, sub: q.refCode,
      ask: q.ask, age: q.age,
      awaiting: q.awaiting,
      label: q.awaiting === 'client' ? 'awaiting you' : q.awaiting === 'broker' ? 'with broker' : 'resolved',
      tone: q.awaiting === 'client' ? 'spot' : q.awaiting === 'broker' ? 'info' : 'pos',
      messages: threadFor(q),
    })),
    feed: [
      { id: 'f1', icon: 'trending-up', tone: 'pos', title: 'Your signal moved', text: 'Cyber score rose +12 to 724 after your MFA attestation cleared underwriting.', time: '2h' },
      { id: 'f2', icon: 'file-check', tone: 'info', title: 'Document requested', text: 'Hartford asked for a SOC 2 Type II report to finish binding Cyber.', time: '1d' },
      { id: 'f3', icon: 'shield-check', tone: 'pos', title: 'PI bound', text: 'Your Professional Indemnity policy is bound with Beazley at $162k.', time: '3d' },
      { id: 'f4', icon: 'lightbulb', tone: 'aux', title: 'Recommendation', text: 'Peers your size increasingly carry standalone Tech E&O. Worth a conversation.', time: '4d' },
    ],
  };
}

// ───────────────────────────────────────────────────────────── carrier
function carrierFeed() {
  const subs = CARRIER_SUBMISSIONS;
  const refer = subs.filter((s) => s.decision === 'refer');
  const pipelinePrem = subs.reduce((s, x) => s + x.premium, 0);
  const avg = Math.round(subs.reduce((s, x) => s + x.score, 0) / subs.length);
  const ready = subs.filter((s) => s.statusTone === 'pos').length;
  const declines = subs.filter((s) => s.decision === 'decline').length;

  return {
    persona: 'carrier',
    org: { name: 'Hartford Mutual', sub: 'Underwriting desk', glyph: 'building-2', initials: 'H' },
    greeting: 'Good morning, Marco',
    brief: `${refer.length} submissions are referred to you for a decision. Pipeline signal is steady, and the World Engine flagged 1 high-severity drift overnight.`,
    climate: { label: 'Pipeline', value: scoreBand(avg), tone: 'pos' },
    score: {
      value: avg, label: 'Pipeline signal', frac: scoreFrac(avg),
      delta: '−3', dir: 'down', tone: 'neg',
      caption: `Mean across ${subs.length} inbound submissions`,
      spark: spark(avg, 26),
      movers: [
        { text: 'Two Tier-4 energy risks dragging the mean', delta: '−6', dir: 'down', tone: 'neg' },
        { text: 'Software & biotech submissions strengthening', delta: '+5', dir: 'up', tone: 'pos' },
      ],
    },
    awaiting: refer.slice(0, 4).map((s) => ({
      id: s.code, title: s.entity, line: s.line, carrier: s.broker,
      sub: `${fmtUsd(s.premium)} · Tier ${s.tier} · signal ${s.score}`, age: s.received,
      tone: 'spot', cta: 'Decide',
    })),
    glance: [
      { key: 'pipe', label: 'Pipeline premium', value: fmtUsd(pipelinePrem), sub: `${subs.length} submissions`, tone: 'info', icon: 'layers' },
      { key: 'refer', label: 'Referred to you', value: String(refer.length), sub: 'need a decision', tone: 'spot', icon: 'user-round-search' },
      { key: 'ready', label: 'Ready to quote', value: String(ready), sub: 'cleared triage', tone: 'pos', icon: 'circle-check' },
      { key: 'drift', label: 'Drift alerts', value: String(WE_ALERTS.length), sub: '1 high severity', tone: 'aux', icon: 'radar' },
    ],
    threads: subs.filter((s) => s.statusTone === 'spot').slice(0, 5).map((s) => ({
      id: s.code, who: s.entity, sub: `${s.broker} · ${s.line}`,
      ask: `${s.status} — ${fmtUsd(s.premium)} at Tier ${s.tier}. Awaiting your decision.`,
      age: s.received, awaiting: 'broker',
      label: s.decision === 'refer' ? 'referred' : s.status.toLowerCase(),
      tone: 'spot',
      messages: [
        { from: 'them', who: s.broker, text: `Submitting ${s.entity} — ${s.line}. Signal ${s.score}, Tier ${s.tier}. ${fmtUsd(s.premium)} premium. Appetite check?`, time: s.received },
        { from: 'sys', text: `World Engine: ${s.industry} cohort within appetite. Decision references signal ${s.score}.`, time: s.received },
      ],
    })),
    feed: [
      { id: 'f1', icon: 'radar', tone: 'neg', title: 'Drift alert · high', text: 'AAL2 enforcement dropping across the Industrial cohort — possible economic pressure.', time: '6h' },
      { id: 'f2', icon: 'flame', tone: 'warn', title: 'Scenario · elevated', text: 'Ransomware wave on energy operators now rated 34% likely within 6 months.', time: '8h' },
      { id: 'f3', icon: 'user-round-search', tone: 'spot', title: 'New referral · Marsh', text: 'Eastward Robotics Cyber referred — signal 724, Tier 2, $185k.', time: '2h' },
      { id: 'f4', icon: 'circle-check', tone: 'pos', title: 'Bound', text: 'Hemlock Biosciences D&O bound at $142k. Tier 2, clean triage.', time: '4d' },
    ],
  };
}

/* Synthesise a short thread for a broker/client query. */
function threadFor(q) {
  const who = q.carrier || 'Carrier';
  const base = [
    { from: 'them', who, text: q.ask, time: q.age },
  ];
  if (q.awaiting === 'broker') {
    base.push({ from: 'sys', text: 'Signal pre-fill ready — attach the latest attestation to respond in one tap.', time: q.age });
  } else if (q.awaiting === 'client') {
    base.push({ from: 'me', text: 'Forwarded to the client. I’ll chase if we don’t hear back by end of day.', time: q.age });
  } else {
    base.push({ from: 'me', text: 'Resolved — rider bound and thread closed.', time: q.age });
  }
  return base;
}

const FEED_BUILDERS = { broker: brokerFeed, client: clientFeed, carrier: carrierFeed };
function buildFeed(persona) {
  return (FEED_BUILDERS[persona] || brokerFeed)();
}

Object.assign(window, { buildFeed, fmtUsd });
