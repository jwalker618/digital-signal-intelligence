/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, BROKER_CARRIERS */

/* ============================================================
 * 04. Placement Strategy — pick a policy, see ranked carrier matches
 *
 * Layout
 *   row 1 — title
 *   row 2 — two-pane: policy picker (left) + strategy detail (right)
 * ============================================================ */

function ReimBrokerPlacement({ isDark }) {
  // For the static view, pick TerraWind Energy Property as the "selected" submission.
  const selected = BROKER_BOOK.find(p => p.entity === 'TerraWind Energy' && p.line === 'Property');

  // Synthesise ranked carrier matches for this submission.
  const matches = [
    { slug: 'munich-re',      score: 88, lead: true,
      rationale: 'Climate-physical desk leads the market on energy property; capacity ample for $25M sub-limit.',
      pricingLow: 380000, pricingHigh: 450000, commission: 9.8, winRate: 61, esg: 'progressive', stance: 'leaning_in' },
    { slug: 'allianz',        score: 81,
      rationale: 'Strong appetite for renewables-adjacent property; ESG aligned with TerraWind\'s solar / wind mix.',
      pricingLow: 395000, pricingHigh: 470000, commission: 10.5, winRate: 58, esg: 'leader', stance: 'leaning_in' },
    { slug: 'axa-xl',         score: 73,
      rationale: 'Selective but historically strong on TerraWind\'s Texas locations.',
      pricingLow: 405000, pricingHigh: 490000, commission: 11.5, winRate: 63, esg: 'leader', stance: 'neutral' },
    { slug: 'swiss-re',       score: 64,
      rationale: 'Reinsurer route — possible facultative excess but unlikely to lead primary at this size.',
      pricingLow: 420000, pricingHigh: 510000, commission:  9.5, winRate: 55, esg: 'leader', stance: 'selective' },
  ];

  return (
    <FrameReimag menu="Placement Strategy" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 18, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Placement strategy</div>
            <h2 className="display" style={{ marginTop: 6 }}>Ranked carrier matches for in-flight risks</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              For each policy, score every carrier in the universe by appetite, ESG fit, pricing position, and historical win rate.
            </div>
          </div>
          <div className="chip chip-info">Composite scoring v8.2</div>
        </div>

        {/* two-pane */}
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16 }}>

          {/* policy picker */}
          <div className="card" style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div className="eyebrow">In-flight ({BROKER_BOOK.filter(p => p.statusTone === 'spot').length})</div>
            {BROKER_BOOK.filter(p => p.statusTone === 'spot').map((p) => {
              const active = p.code === selected.code;
              return (
                <div key={p.code} style={{
                  padding: '10px 12px',
                  background: active ? 'color-mix(in srgb, var(--surface) 82%, var(--spot) 18%)' : 'var(--surface-elev)',
                  border: '1px solid ' + (active ? 'var(--spot)' : 'var(--rule)'),
                  borderRadius: 8,
                  cursor: 'pointer',
                }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{p.entity}</div>
                  <div className="micro">{p.line} · ${(p.premium / 1000).toFixed(0)}k current</div>
                  <span className={`chip chip-${p.statusTone}`} style={{ marginTop: 6, fontSize: 10, padding: '2px 7px' }}>{p.status}</span>
                </div>
              );
            })}
            <div className="caption" style={{ marginTop: 8, paddingTop: 10, borderTop: '1px solid var(--rule)' }}>
              Click a policy to recompute ranked matches.
            </div>
          </div>

          {/* strategy detail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {/* selected policy header */}
            <div className="card-info" style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16 }}>
                <div>
                  <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Active submission</div>
                  <h3 style={{ font: '600 22px/1.2 IBM Plex Sans', margin: '6px 0 4px' }}>
                    {selected.entity} — {selected.line}
                  </h3>
                  <div className="caption">
                    {selected.vertical} · current quote ${(selected.premium / 1000).toFixed(0)}k with {selected.carrier}
                  </div>
                </div>
                <span className={`chip chip-${selected.statusTone}`}>{selected.status}</span>
              </div>
              <div className="body" style={{ marginTop: 12 }}>
                Property capacity tightening through 2026; energy verticals especially affected.
                4 carriers have credible appetite for this risk — Munich Re leads on climate-physical expertise.
              </div>
            </div>

            {/* lead recommendation */}
            <CarrierMatch match={matches[0]} carrier={BROKER_CARRIERS.find(c => c.slug === matches[0].slug)} lead />

            {/* other matches */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div className="eyebrow">Other matches</div>
              {matches.slice(1).map((m) => (
                <CarrierMatch key={m.slug} match={m} carrier={BROKER_CARRIERS.find(c => c.slug === m.slug)} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </FrameReimag>
  );
}

function CarrierMatch({ match, carrier, lead }) {
  const stanceColor = match.stance === 'leaning_in' ? 'var(--pos)'
                    : match.stance === 'neutral'     ? 'var(--info)'
                    : match.stance === 'selective'   ? 'var(--warn)'
                    : 'var(--neg)';
  const esgColor = match.esg === 'leader' ? 'var(--pos)'
                 : match.esg === 'progressive' ? 'var(--info)'
                 : match.esg === 'neutral' ? 'var(--ink-soft)'
                 : 'var(--warn)';
  return (
    <div className={lead ? 'card' : 'card'} style={{
      padding: lead ? 22 : 16,
      borderLeft: lead ? '4px solid var(--info)' : '1px solid var(--rule)',
    }}>
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 110px 160px', gap: 18, alignItems: 'center' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 6, flexWrap: 'wrap' }}>
            {lead && <span className="chip chip-info">LEAD</span>}
            <span style={{ fontSize: lead ? 18 : 15, fontWeight: 700 }}>{carrier?.name}</span>
            <span className="chip" style={{ color: stanceColor, borderColor: stanceColor }}>{match.stance.replace('_', ' ')}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: esgColor, fontWeight: 600 }}>
              <Icon name="leaf" size={11} /> ESG {match.esg}
            </span>
          </div>
          <div className="caption" style={{ lineHeight: 1.45, fontSize: lead ? 13.5 : 12.5 }}>{match.rationale}</div>
        </div>
        <div>
          <div className="micro">Suitability</div>
          <div className="num" style={{ fontSize: lead ? 28 : 22, color: 'var(--info)', fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>{match.score}</div>
          <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden', marginTop: 4 }}>
            <div style={{ width: `${match.score}%`, height: '100%', background: 'var(--info)' }} />
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="micro">Predicted premium</div>
          <div style={{ fontSize: lead ? 15 : 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>
            ${(match.pricingLow / 1000).toFixed(0)}k – ${(match.pricingHigh / 1000).toFixed(0)}k
          </div>
          <div className="micro" style={{ marginTop: 4 }}>
            Cmsn {match.commission}% · Win {match.winRate}%
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerPlacement });
