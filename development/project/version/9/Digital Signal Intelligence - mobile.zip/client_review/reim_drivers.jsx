/* global React, FrameReimag, Icon, LossOutlookCard, ExposureCard */

/* ============================================================
 * Risk Insights (reimagined) — v2
 *
 * Layout
 *   row 1 — title strip
 *   row 2 — 4 headline math cards
 *   row 3 — premium build-up (waterfall)         — its own card
 *   row 4 — loss outlook | exposure | next move  (3 equal)
 *
 * Color discipline
 *   • info teal — facts (final premium, base premium)
 *   • coral     — opportunity & actions (4 signals to act on, "see action plan →")
 *   • pos green — strengths, value-positive deltas
 *   • aux blue  — secondary informative (exposure)
 *
 *   Opportunity is treated as a call-to-action (coral), not info:
 *   it's a list of things for the client to do, not a neutral fact.
 * ============================================================ */

const E = 'Eastward Robotics';

function ReimDrivers({ isDark }) {
  // waterfall: base → strengths (down) → opportunity drags (up) → final
  const items = [
    { label: 'Base',                value: 157000, type: 'base' },
    { label: 'MFA on admin',        value: -12100, type: 'pos' },
    { label: 'No prior claims',     value: -9300,  type: 'pos' },
    { label: 'EDR coverage 95%+',   value: -6700,  type: 'pos' },
    { label: 'SOC 2 Type II',       value: 18200,  type: 'opp' },
    { label: 'Backup encryption',   value: 11400,  type: 'opp' },
    { label: 'Public-facing RDP',   value: 6200,   type: 'opp' },
    { label: 'IR playbook',         value: 4900,   type: 'opp' },
    { label: 'Final',               value: 185200, type: 'final' },
  ];
  let running = 0;
  const bars = items.map((it) => {
    if (it.type === 'base')  { const b = { ...it, lo: 0, hi: it.value }; running = it.value; return b; }
    if (it.type === 'final') { return { ...it, lo: 0, hi: it.value }; }
    const lo = it.value > 0 ? running : running + it.value;
    const hi = it.value > 0 ? running + it.value : running;
    running += it.value;
    return { ...it, lo, hi };
  });
  const maxY = Math.max(...bars.map(b => b.hi));
  const W = 1180, H = 220, barW = W / bars.length - 14;

  return (
    <FrameReimag menu="Risk Insights" entity={E} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* row 1 — title */}
        <div>
          <div className="eyebrow">Risk insights</div>
          <h2 className="display" style={{ marginTop: 6 }}>
            Your premium, broken down to the signal
          </h2>
        </div>

        {/* row 2 — 4 headline math cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          <div className="card">
            <div className="eyebrow">Base premium</div>
            <div className="num" style={{ marginTop: 6 }}>$157,000</div>
            <div className="caption">Industry × revenue × limit</div>
          </div>
          <div className="card-pos">
            <div className="eyebrow" style={{ color: 'var(--pos)' }}>Strengths</div>
            <div className="num pos" style={{ marginTop: 6 }}>−$28.1k</div>
            <div className="caption">3 signals lowering your premium</div>
          </div>
          {/* Opportunity — CORAL (things to do, not a fact) */}
          <div className="card-spot">
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Opportunity</div>
            <div className="num" style={{ marginTop: 6, color: 'var(--spot-deep)' }}>+$40.7k</div>
            <div className="caption">4 signals to act on</div>
          </div>
          <div className="card-info">
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Final premium</div>
            <div className="num" style={{ marginTop: 6, color: 'var(--info-deep)' }}>$185,200</div>
            <div className="caption">As quoted by Hartford Mutual</div>
          </div>
        </div>

        {/* row 3 — waterfall as its own card */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <div>
              <div className="eyebrow">Premium build-up</div>
              <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                From base to bound — every signal accounted for
              </h3>
            </div>
            <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }} className="micro">
                <span style={{ width: 10, height: 10, background: 'var(--pos)', borderRadius: 2 }} /> Strengths
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }} className="micro">
                <span style={{ width: 10, height: 10, background: 'var(--spot)', borderRadius: 2 }} /> Opportunity
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }} className="micro">
                <span style={{ width: 10, height: 10, background: 'var(--ink)', borderRadius: 2 }} /> Premium
              </span>
            </div>
          </div>
          <svg width="100%" viewBox={`0 0 ${W} ${H + 32}`} style={{ display: 'block' }}>
            <defs>
              <linearGradient id="anchor-bar" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%"  stopColor="var(--ink)" stopOpacity="0.18" />
                <stop offset="100%" stopColor="var(--ink)" stopOpacity="0.78" />
              </linearGradient>
            </defs>
            {bars.map((b, i) => {
              const x = i * (W / bars.length) + 8;
              const yScale = H / maxY;
              const y = H - b.hi * yScale;
              const h = (b.hi - b.lo) * yScale;
              const isAnchor = b.type === 'base' || b.type === 'final';
              const fill = isAnchor                ? 'url(#anchor-bar)'
                         : b.type === 'pos'         ? 'var(--pos)'
                         :                            'var(--spot)';
              return (
                <g key={i}>
                  <rect x={x} y={y} width={barW} height={h} fill={fill} rx="3" />
                  <text x={x + barW/2} y={y - 6} textAnchor="middle"
                    style={{ font: '600 12px IBM Plex Sans', fill: 'var(--ink)' }}>
                    {b.type === 'pos' ? `−$${(Math.abs(b.value)/1000).toFixed(1)}k`
                     : b.type === 'opp' ? `+$${(b.value/1000).toFixed(1)}k`
                     : `$${(b.value/1000).toFixed(0)}k`}
                  </text>
                  <text x={x + barW/2} y={H + 18} textAnchor="middle"
                    style={{ font: '11px IBM Plex Sans', fill: 'var(--ink-soft)' }}>
                    {b.label.length > 16 ? b.label.slice(0, 14) + '…' : b.label}
                  </text>
                </g>
              );
            })}
            {bars.slice(0, -1).map((b, i) => {
              const next = bars[i + 1];
              if (next.type === 'final') return null;
              const x1 = i * (W / bars.length) + 8 + barW;
              const x2 = (i + 1) * (W / bars.length) + 8;
              const yScale = H / maxY;
              const y = H - b.hi * yScale;
              return <line key={`c-${i}`} x1={x1} y1={y} x2={x2} y2={y}
                stroke="var(--ink-mute)" strokeDasharray="3 3" strokeWidth="1" />;
            })}
          </svg>
        </div>

        {/* row 4 — three separate cards: loss / exposure / next move */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          <LossOutlookCard
            band="Low"
            trend="Improving"
            quarters={[0, 0, 0, 0,  0, 0.4, 0, 0,  0, 0, 0.7, 0]}
            quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
            frequency={{ value: 32, cohort: 48 }}
            severity={{ value: 41, cohort: 44 }}
          />
          <ExposureCard
            value="$118M"
            yoy="+12%"
            band="mid"
            sub="2 states · diversified"
          />

          {/* Next move — coral CTA */}
          <div className="card-spot" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow" style={{ color: 'var(--spot)' }}>Your next move</div>
                <div className="num-sm" style={{ fontSize: 20, color: 'var(--spot-deep)', marginTop: 4 }}>
                  −$40.7k available
                </div>
              </div>
              <span className="chip chip-spot">4 actions</span>
            </div>
            <div className="caption">
              The four opportunity signals above are each linked to a concrete remediation,
              prioritised by leverage (impact ÷ effort).
            </div>
            <div style={{ marginTop: 'auto', display: 'flex', gap: 8 }}>
              <button className="btn spot">See action plan →</button>
              <button className="btn ghost">Export PDF</button>
            </div>
          </div>
        </div>
      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimDrivers });
