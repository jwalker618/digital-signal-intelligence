/* global React, FrameReimag, Icon, ScoreHistory, CohortBar, PremiumBreakdown, Sparkline */

/* ============================================================
 * Awaiting card — coral spotlight with pager + next-up peek
 * ============================================================ */
function AwaitingCard({ items }) {
  const [idx, setIdx] = React.useState(0);
  const item = items[idx];
  const next = items[(idx + 1) % items.length];
  const canBack = idx > 0;
  const canFwd  = idx < items.length - 1;
  return (
    <div className="card-spot" style={{ display: 'flex', flexDirection: 'column', padding: 22, gap: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className="eyebrow" style={{ color: 'var(--spot)' }}>Awaiting you</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <button
            aria-label="Previous query"
            onClick={() => canBack && setIdx(idx - 1)}
            disabled={!canBack}
            style={pagerBtn(canBack)}
          ><Icon name="chevron-left" size={14} /></button>
          <span className="chip chip-spot" style={{ minWidth: 50, justifyContent: 'center' }}>
            {idx + 1} of {items.length}
          </span>
          <button
            aria-label="Next query"
            onClick={() => canFwd && setIdx(idx + 1)}
            disabled={!canFwd}
            style={pagerBtn(canFwd)}
          ><Icon name="chevron-right" size={14} /></button>
        </div>
      </div>
      <div>
        <div style={{ font: '600 16px/1.25 IBM Plex Sans', color: 'var(--ink)' }}>{item.ask}</div>
        <div className="caption" style={{ marginTop: 4 }}>{item.age} · {item.line}</div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
        <button className="btn spot">Open thread</button>
        <button className="btn ghost">Snooze</button>
      </div>
      {/* peek of the next item */}
      {items.length > 1 && (
        <div style={{
          paddingTop: 10, marginTop: 4, borderTop: '1px dashed var(--spot)',
          display: 'flex', alignItems: 'center', gap: 8, fontSize: 12,
          color: 'var(--spot-deep)', cursor: 'pointer',
        }}
          onClick={() => setIdx((idx + 1) % items.length)}
        >
          <span style={{ opacity: 0.7 }}>Next →</span>
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>
            {next.ask}
          </span>
        </div>
      )}
    </div>
  );
}
function pagerBtn(enabled) {
  return {
    width: 22, height: 22, borderRadius: 6,
    background: 'transparent',
    border: '1px solid var(--spot)',
    color: 'var(--spot)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: enabled ? 'pointer' : 'not-allowed',
    opacity: enabled ? 1 : 0.3,
    padding: 0,
  };
}

/* ============================================================
 * LossOutlookCard — 36-month claims strip + freq/sev vs cohort
 * ============================================================ */
function LossOutlookCard({ band, trend, quarters, quarterLabels, frequency, severity }) {
  // quarters: array of 12 values; 0 = no claim, >0 = severity intensity (0–1)
  return (
    <div className="card-pos" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow" style={{ color: 'var(--pos)' }}>Loss outlook</div>
          <div className="num-sm" style={{ fontSize: 20, color: 'var(--pos)', marginTop: 4 }}>{band}</div>
        </div>
        <span className="chip chip-pos">
          <Icon name="trending-down" size={11} /> {trend}
        </span>
      </div>
      {/* claims strip */}
      <div>
        <div className="micro" style={{ marginBottom: 4 }}>Claims, last 12 quarters</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 3 }}>
          {quarters.map((v, i) => (
            <div
              key={i}
              title={v > 0 ? `Q${(i % 4) + 1} '${23 + Math.floor(i/4)} — claim` : `Q${(i % 4) + 1} '${23 + Math.floor(i/4)} — no claim`}
              style={{
                height: 14, borderRadius: 2,
                background: v > 0
                  ? `color-mix(in srgb, var(--neg) ${30 + v * 70}%, transparent)`
                  : 'var(--surface)',
                border: `1px solid ${v > 0 ? 'var(--neg)' : 'var(--rule)'}`,
              }}
            />
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
          {quarterLabels.map((l) => <span key={l} className="micro">{l}</span>)}
        </div>
      </div>
      {/* freq + sev vs cohort */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 'auto' }}>
        <CompareBar label="Frequency" value={frequency.value} cohort={frequency.cohort} max={100} />
        <CompareBar label="Severity"  value={severity.value}  cohort={severity.cohort}  max={100} />
      </div>
    </div>
  );
}
function CompareBar({ label, value, cohort, max }) {
  // value < cohort = better (lower frequency/severity is good)
  const better = value < cohort;
  const W = 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span className="micro">{label}</span>
        <span className="micro">vs {cohort}</span>
      </div>
      <div style={{ position: 'relative', height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4 }}>
        <div style={{
          position: 'absolute', left: 0, top: 0, height: '100%',
          width: `${(value / max) * 100}%`,
          background: better ? 'var(--pos)' : 'var(--neg)',
          borderRadius: 2,
        }} />
        <div style={{
          position: 'absolute', top: -3, height: 10, width: 2,
          background: 'var(--ink-soft)',
          left: `${(cohort / max) * 100}%`,
        }} />
      </div>
      <div style={{ marginTop: 4, fontSize: 12, fontWeight: 600, color: better ? 'var(--pos)' : 'var(--neg)' }}>
        {value}
      </div>
    </div>
  );
}

/* ============================================================
 * ExposureCard — position on cohort size scale + YoY
 * ============================================================ */
function ExposureCard({ value, yoy, band, sub }) {
  // band can be 'small' | 'mid' | 'large'
  const positions = { small: 0.18, mid: 0.55, large: 0.85 };
  const pinPct = positions[band] * 100;
  return (
    <div className="card-aux" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow" style={{ color: 'var(--aux)' }}>Exposure</div>
          <div className="num-sm" style={{ fontSize: 20, color: 'var(--aux)', marginTop: 4 }}>{value}</div>
        </div>
        <span className="chip chip-pos">
          <Icon name="trending-up" size={11} /> {yoy} YoY
        </span>
      </div>
      {/* position on scale */}
      <div style={{ marginTop: 4 }}>
        <div className="micro" style={{ marginBottom: 4 }}>Where you sit in market scale</div>
        <div style={{ position: 'relative', height: 28 }}>
          <div style={{
            position: 'absolute', left: 0, right: 0, top: 12, height: 6,
            background: 'linear-gradient(to right, var(--surface) 0%, var(--aux-soft) 50%, var(--aux) 100%)',
            borderRadius: 3, border: '1px solid var(--rule-strong)',
          }} />
          {/* labels */}
          <div style={{ position: 'absolute', left: 0, top: 22, fontSize: 9.5 }} className="micro">Small</div>
          <div style={{ position: 'absolute', left: '50%', top: 22, transform: 'translateX(-50%)', fontSize: 9.5 }} className="micro">Mid-market</div>
          <div style={{ position: 'absolute', right: 0, top: 22, fontSize: 9.5 }} className="micro">Large</div>
          {/* you pin */}
          <div style={{
            position: 'absolute', left: `${pinPct}%`, top: 0,
            transform: 'translateX(-50%)',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
          }}>
            <span style={{
              background: 'var(--aux)', color: '#fff', fontSize: 10, fontWeight: 600,
              padding: '2px 6px', borderRadius: 4,
            }}>YOU</span>
            <div style={{ width: 2, height: 12, background: 'var(--aux)' }} />
          </div>
        </div>
      </div>
      <div className="caption" style={{ marginTop: 'auto' }}>{sub}</div>
    </div>
  );
}

/* ============================================================
 * CoverageShapeCard — held lines + typical peer gaps
 * ============================================================ */
function CoverageShapeCard({ held, gaps }) {
  const total = held.length + gaps.length;
  return (
    <div className="card" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow">Coverage shape</div>
          <div className="num-sm" style={{ fontSize: 20, marginTop: 4 }}>
            {held.length} of {total} typical lines
          </div>
        </div>
        <span className="chip chip-spot">{gaps.length} typical adds</span>
      </div>
      <div>
        <div className="micro" style={{ marginBottom: 6 }}>Held</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {held.map((l) => (
            <span key={l} className="chip chip-pos" style={{ padding: '4px 9px' }}>
              <Icon name="check" size={11} /> {l}
            </span>
          ))}
        </div>
      </div>
      <div style={{ marginTop: 'auto' }}>
        <div className="micro" style={{ marginBottom: 6 }}>Often added by peers</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {gaps.map((g) => (
            <span key={g.line} className="chip" style={{
              padding: '4px 9px',
              border: '1px dashed var(--rule-strong)',
              background: 'transparent',
            }}>
              <Icon name="circle" size={11} /> {g.line}
              <span style={{ opacity: 0.6, marginLeft: 4, fontSize: 10 }}>{g.peerPct}%</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
 * Overview — reimagined v2
 *
 * Layout
 *   row 1 — hero strip: SCORE / PREMIUM / AWAITING-YOU       (3 equal)
 *   row 2 — analytics:  SIGNAL PULSE / COHORT STANDING       (2 equal)
 *   row 3 — footer:     LOSS OUTLOOK / EXPOSURE / COVERAGE   (3 equal)
 *
 * Color discipline
 *   • info teal  — neutral hero facts (score, premium, charts)
 *   • coral spot — awaiting-you / urgent ONLY (the right hero card)
 *   • pos green  — value-positive deltas (above median, savings)
 *   • aux blue   — secondary informative (exposure)
 *   • opportunity in Signal Pulse uses INFO TEAL (it's a call to
 *     review, not a "bad" thing) — strengths stay green
 * ============================================================ */

const ENT = 'Eastward Robotics';

function ReimOverview({ isDark }) {
  // — score state ----------------------------------------------
  const score = 724;
  const prev  = 706;
  const median = 714;
  const vsMedian   = score - median;
  const vsPrev     = score - prev;
  const scoreHist = [
    { label: 'Q1 ’25', value: 692 },
    { label: 'Q2 ’25', value: 705 },
    { label: 'Q3 ’25', value: 712 },
    { label: 'last quote', value: 706, marker: 'prev' },
    { label: 'now',    value: 724 },
  ];

  // — premium book --------------------------------------------
  const policies = [
    { name: 'Cyber', amount: 185200, color: 'var(--info)' },
    { name: 'PI',    amount: 162000, color: 'var(--aux)' },
    { name: 'D&O',   amount: 140500, color: 'var(--ink-soft)' },
    // — uncomment to see overflow behaviour ——
    // { name: 'Property', amount: 92000, color: 'var(--warn)' },
    // { name: 'GL',       amount: 64000, color: 'var(--info-deep)' },
  ];

  return (
    <FrameReimag menu="Overview" entity={ENT} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* ────────── ROW 1 — hero strip ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 1fr 1.1fr', gap: 16 }}>

          {/* Score */}
          <div className="card-info" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Your signal score</div>
            <div style={{ display: 'flex', gap: 20, marginTop: 10, alignItems: 'flex-start' }}>
              <div className="num-xl" style={{ color: 'var(--info-deep)', lineHeight: 1 }}>{score}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 4 }}>
                <span className="chip chip-pos" style={{ alignSelf: 'flex-start' }}>
                  <Icon name="arrow-up" size={11} /> +{vsMedian} vs median
                </span>
                <span className="chip chip-pos" style={{ alignSelf: 'flex-start' }}>
                  <Icon name="trending-up" size={11} /> +{vsPrev} since last quote
                </span>
              </div>
            </div>
            <div style={{ flex: 1, marginTop: 14, minHeight: 96 }}>
              <ScoreHistory history={scoreHist} />
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
              <span className="chip"><Icon name="check" size={12} /> Standard tier</span>
              <span className="chip chip-info"><Icon name="trending-up" size={12} /> 64th percentile</span>
            </div>
          </div>

          {/* Premium */}
          <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div className="eyebrow">Annual premium</div>
            <div className="num-xl" style={{ marginTop: 10, lineHeight: 1 }}>
              ${(policies.reduce((s, p) => s + p.amount, 0)).toLocaleString()}
            </div>
            <div className="caption" style={{ marginTop: 4 }}>
              Across {policies.length} active polic{policies.length === 1 ? 'y' : 'ies'}
            </div>
            <div style={{ marginTop: 'auto' }}>
              <PremiumBreakdown policies={policies} />
            </div>
          </div>

          {/* Awaiting you — coral spotlight, with pager + next-up preview */}
          <AwaitingCard
            items={[
              {
                from: 'Hartford Mutual',
                line: 'Cyber referral',
                age:  '2 hours ago',
                ask:  'Hartford Mutual needs MFA attestation for the cyber bind',
              },
              {
                from: 'Hartford Mutual',
                line: 'Cyber referral',
                age:  '1 day ago',
                ask:  'Provide latest SOC 2 Type II report or equivalent audit',
              },
            ]}
          />
        </div>

        {/* ────────── ROW 2 — analytics: pulse + cohort ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>

          {/* Signal pulse: helping (green) + opportunity (INFO teal — review, not bad) */}
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div>
                <div className="eyebrow">Signal pulse</div>
                <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: '6px 0 0' }}>What's moving your premium</h3>
              </div>
              <span className="micro">cyber · primary line</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
              <PulseColumn
                heading="Helping"
                headingChip="chip chip-pos"
                headingIcon="arrow-down"
                deltaLabel="−$28.1k"
                deltaClass="pos"
                accent="var(--pos)"
                rows={[
                  ['MFA on admins',        12100, 12100],
                  ['No prior claims (5y)',  9300, 12100],
                  ['EDR coverage 95%+',     6700, 12100],
                ]}
                sign="−"
              />
              <PulseColumn
                heading="Opportunity"
                headingChip="chip chip-spot"
                headingIcon="lightbulb"
                deltaLabel="+$40.7k"
                deltaClass="spot"
                accent="var(--spot)"
                rows={[
                  ['SOC 2 Type II',     18200, 18200],
                  ['Backup encryption', 11400, 18200],
                  ['Public RDP exposed', 6200, 18200],
                ]}
                sign="+"
              />
            </div>
          </div>

          {/* Cohort standing — horizontal distribution strip */}
          <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow">Cohort standing</div>
                <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                  You sit at the <span className="pos">64th percentile</span>
                </h3>
              </div>
              <span className="micro">38 peers</span>
            </div>
            <div style={{ marginTop: 18, flex: 1, display: 'flex', alignItems: 'center' }}>
              <CohortBar value={score} median={median} topDecile={784} range={[600, 880]} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
              <div>
                <div className="micro">vs median</div>
                <div className="num-sm pos">+{vsMedian}</div>
              </div>
              <div>
                <div className="micro">your score</div>
                <div className="num-sm info">{score}</div>
              </div>
              <div>
                <div className="micro">to top decile</div>
                <div className="num-sm">{784 - score}</div>
              </div>
            </div>
          </div>
        </div>

        {/* ────────── ROW 3 — footer informational cards (3 equal) ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          <LossOutlookCard
            band="Low"
            trend="Improving"
            quarters={[
              0, 0, 0, 0,
              0, 0.4, 0, 0,
              0, 0, 0.7, 0,
            ]}
            quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
            frequency={{ value: 32, cohort: 48 }}
            severity={{ value: 41, cohort: 44 }}
          />
          <ExposureCard
            value="$118M"
            yoy="+12%"
            band="mid"
            sub="2 states · diversified"
          />
          <CoverageShapeCard
            held={['Cyber', 'PI', 'D&O']}
            gaps={[
              { line: 'Property', peerPct: 78 },
              { line: 'GL',       peerPct: 65 },
              { line: 'Crime',    peerPct: 42 },
            ]}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

/* ─── helpers (kept local to keep the page legible) ─────────── */

function PulseColumn({ heading, headingChip, headingIcon, deltaLabel, deltaClass, accent, rows, sign }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
        <span className={headingChip}><Icon name={headingIcon} size={12} /> {heading}</span>
        <span className={`num-sm ${deltaClass}`}>{deltaLabel}</span>
      </div>
      {rows.map((r, i) => (
        <div key={i} style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, gap: 8, whiteSpace: 'nowrap' }}>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[0]}</span>
            <span className={deltaClass} style={{ fontWeight: 600, flexShrink: 0 }}>
              {sign}${(r[1] / 1000).toFixed(1)}k
            </span>
          </div>
          <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
            <div style={{ width: `${(r[1] / r[2]) * 100}%`, height: '100%', background: accent }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function FooterCard({ variant, eyebrow, eyebrowColor, headline, headlineColor, sub, spark, sparkColor, customRight }) {
  return (
    <div className={variant} style={{ padding: 20, display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="eyebrow" style={{ color: eyebrowColor }}>{eyebrow}</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: 8, gap: 12 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="num-sm" style={{ fontSize: 22, color: headlineColor }}>{headline}</div>
          <div className="caption" style={{ marginTop: 4 }}>{sub}</div>
        </div>
        <div style={{ flexShrink: 0 }}>
          {customRight ?? <Sparkline points={spark} color={sparkColor} width={88} height={32} />}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ReimOverview, LossOutlookCard, ExposureCard, CompareBar, AwaitingCard });
