/* global React, Icon, WorkbenchShell */

/* ============================================================
 * Carrier · Submission Workbench — drill-down into a single
 * inbound submission. The carrier nav collapses; a workbench-
 * specific nav replaces it with the drill-down tab tree.
 *
 * Active submission storyline: SUB-26-0118 (Eastward Robotics ·
 * Cyber) — same insured as the Client + Broker portals so numbers
 * line up across personas.
 *
 * Tabs covered as representative artboards:
 *   • Summary
 *   • Pricing Anatomy           (Technical)
 *   • Risk Assessment           (Technical)
 *   • Loss Assessment           (Technical)
 *   • Exposure Assessment       (Technical)
 *   • Scenarios                 (Technical)
 *   • Referral Actions          (Technical)
 *   • Model Versions            (Technical)
 *   • Premium Assembly          (Commercial)
 *   • Distribution              (Commercial)
 *   • Coverage Terms            (Risk)
 *   • Deductible Structure      (Risk)
 *   • SIR & Waiting Periods     (Risk)
 *   • Aggregate & Reinstatement (Risk)
 *   • Commercial Terms          (Commercial)
 * ============================================================ */

const WB = {
  code:     'SUB-26-0118',
  entity:   'Eastward Robotics, Inc.',
  broker:   'Marsh — Northeast Specialty',
  line:     'Cyber',
  score:    724,
  tier:     2,
  tierLabel:'Standard',
  decision: 'refer',
  premium:  185200,
  limit:    10_000_000,
  deductible: 50_000,
  received: 'Apr 24, 2026',
};

/* Drill-down nav structure */
const DRILL_NAV = [
  { kind: 'leaf',  name: 'Summary',                 icon: 'gauge' },
  { kind: 'group', name: 'Commercial Terms',         icon: 'building-2',
    children: [
      { name: 'Terms Overview',   icon: 'file-text'   },
      { name: 'Premium Assembly', icon: 'calculator'  },
      { name: 'Distribution',     icon: 'network'     },
    ] },
  { kind: 'group', name: 'Risk Terms',               icon: 'scale',
    children: [
      { name: 'Deductible Structure',      icon: 'layers'     },
      { name: 'Coverage Terms',            icon: 'file-check' },
      { name: 'SIR & Waiting Periods',     icon: 'clock'      },
      { name: 'Aggregate & Reinstatement', icon: 'refresh-cw' },
    ] },
  { kind: 'group', name: 'Technical Assessment',     icon: 'chart-no-axes-gantt',
    children: [
      { name: 'Pricing Anatomy',     icon: 'calculator'  },
      { name: 'Risk Assessment',     icon: 'glasses'     },
      { name: 'Loss Assessment',     icon: 'shield-alert'},
      { name: 'Exposure Assessment', icon: 'globe'       },
      { name: 'Scenarios',           icon: 'flask-conical' },
      { name: 'Referral Actions',    icon: 'user-star'   },
      { name: 'Model Versions',      icon: 'file-stack'  },
    ] },
];

/* ============================================================
 * Carrier workbench frame — thin config over the shared
 * <WorkbenchShell> primitive (primitives.jsx).
 * ============================================================ */
function WorkbenchFrame({ active, children, isDark }) {
  const isSummary = active === 'Summary';
  const lead = (
    <React.Fragment>
      <span style={{ color: 'var(--ink-mute)' }}>/</span>
      <code style={{ fontSize: 12, color: 'var(--ink-mute)' }}>{WB.code}</code>
      <span style={{ color: 'var(--ink-mute)' }}>·</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
        <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>{WB.entity}</span>
        <span className="chip" style={{ fontSize: 11 }}>{WB.line}</span>
        {/* Decision is the headline of the Summary banner below; only repeat on deeper tabs. */}
        {!isSummary && <span className="chip chip-spot" style={{ fontSize: 11 }}>{WB.decision.toUpperCase()}</span>}
        <span className="micro" style={{ fontSize: 11, marginLeft: 2 }}>via {WB.broker}</span>
      </div>
    </React.Fragment>
  );
  return (
    <WorkbenchShell
      nav={DRILL_NAV}
      active={active}
      isDark={isDark}
      backLabel="Pipeline"
      account={{ initials: 'JR', name: 'Jordan Reyes', email: 'jordan.reyes@hartfordmutual.com' }}
      scope={{ label: 'Submission', lines: [`${WB.code} · ${WB.entity}`] }}
      lead={lead}
      contextStats={[
        { label: 'Score', value: WB.score, tone: 'info' },
        { label: 'Tier', value: `T${WB.tier}` },
        { label: 'Premium', value: `$${(WB.premium / 1000).toFixed(0)}k` },
      ]}
    >
      {children}
    </WorkbenchShell>
  );
}
function WbCard({ title, icon, headerRight, children, padding = 22, style }) {
  return (
    <div className="card" style={{ padding: 0, overflow: 'hidden', ...style }}>
      {title && (
        <div style={{
          padding: '12px 18px', borderBottom: '1px solid var(--rule)',
          background: 'var(--surface-elev)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {icon && <Icon name={icon} size={15} color="var(--ink-soft)" />}
            <h3 style={{ font: '600 14px/1 IBM Plex Sans', margin: 0 }}>{title}</h3>
          </div>
          {headerRight}
        </div>
      )}
      <div style={{ padding }}>{children}</div>
    </div>
  );
}
/* Thin wrapper over the shared <Kpi> primitive (primitives.jsx). */
function WbKpi(props) {
  return <Kpi {...props} />;
}
function WbRow({ k, v, tone, mono, bold }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '6px 0', borderBottom: '1px solid var(--rule)' }}>
      <span className="micro">{k}</span>
      <span style={{
        fontSize: 13,
        fontWeight: bold ? 700 : 500,
        color: tone === 'info' ? 'var(--info)' : tone === 'pos' ? 'var(--pos)' : tone === 'neg' ? 'var(--neg)' : 'var(--ink)',
        fontFamily: mono ? 'ui-monospace, monospace' : 'inherit',
        fontVariantNumeric: 'tabular-nums',
      }}>{v}</span>
    </div>
  );
}

Object.assign(window, { WorkbenchFrame, WbCard, WbKpi, WbRow, WB });
