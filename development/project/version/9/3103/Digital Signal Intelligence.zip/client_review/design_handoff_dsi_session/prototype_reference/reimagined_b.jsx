/* global React, FrameReimag, Icon, Sparkline, Dial,
   useCoverage, PageHead, MiniCohort, OppByLineBar, StatusChip,
   CLIENT_LINES, CLIENT_PORTFOLIO, lineByKey, kMoney */

const E2 = 'Eastward Robotics';

const effortChip = (e) =>
  e === 'LOW' ? 'chip chip-pos' : e === 'MEDIUM' ? 'chip chip-warn' : 'chip chip-neg';

/* ──────────────────────────────────────────────────────────────
 * 3. Action Plan — All (cross-line leverage rank) + per-line
 * ────────────────────────────────────────────────────────────── */
function ReimActions({ isDark }) {
  const [cov, setCov] = useCoverage('all');
  const line = cov === 'all' ? null : lineByKey(cov);

  // Ranked actions for the current scope.
  const ranked = cov === 'all'
    ? CLIENT_PORTFOLIO.allActions
    : [...line.actions].map((a) => ({ ...a, lineKey: line.key, lineShort: line.short, lineName: line.line }))
        .sort((x, y) => (y.leverage - x.leverage) || (y.delta - x.delta));

  const totalDelta = ranked.reduce((s, a) => s + a.delta, 0);
  const lowWins = ranked.filter((a) => a.effort === 'LOW').length;
  const top = ranked[0];
  const others = ranked.slice(1);

  const title = cov === 'all'
    ? `${ranked.length} moves to take −${kMoney(totalDelta)} off your book`
    : `${ranked.length} move${ranked.length === 1 ? '' : 's'} on ${line.line}`;
  const sub = cov === 'all'
    ? 'Every opportunity across your three lines, ranked by leverage — premium impact over the effort to deliver it.'
    : `Prioritised by leverage. ${line.note || 'Premium impact over effort to deliver.'}`;

  return (
    <FrameReimag menu="Action Plan" entity={E2} isDark={isDark}>
      <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 18, height: '100%', alignContent: 'start' }}>
        <PageHead
          eyebrow="Action plan" title={title} sub={sub} active={cov} onChange={setCov}
          right={(
            <div style={{ display: 'flex', gap: 24 }}>
              <div style={{ textAlign: 'right' }}>
                <div className="micro">total impact</div>
                <div className="num pos">−{kMoney(totalDelta)}</div>
              </div>
              <div className="divider" />
              <div style={{ textAlign: 'right' }}>
                <div className="micro">low-effort wins</div>
                <div className="num pos">{lowWins}</div>
              </div>
            </div>
          )}
        />

        {/* For the portfolio view, show where the upside concentrates. */}
        {cov === 'all' && (
          <div className="card" style={{ padding: 20, display: 'grid', gridTemplateColumns: '1fr 1.1fr', gap: 28, alignItems: 'center' }}>
            <div>
              <div className="eyebrow">Opportunity by line</div>
              <div className="caption" style={{ marginTop: 4 }}>
                {CLIENT_PORTFOLIO.weakLine.short} holds the largest single lever and the lowest score — the clearest place to start.
              </div>
            </div>
            <OppByLineBar data={CLIENT_PORTFOLIO.oppByLine} />
          </div>
        )}

        {/* Hero action */}
        <div className="card-info" style={{ padding: 28, display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 28 }}>
          <div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 10, flexWrap: 'wrap' }}>
              <span className="chip chip-info">#1 BIGGEST LEVER</span>
              <span className={effortChip(top.effort)}>{top.effort} EFFORT</span>
              {cov === 'all' && <LineTag short={top.lineShort} />}
            </div>
            <h2 className="huge" style={{ marginTop: 4 }}>{top.headline}</h2>
            <div className="body" style={{ marginTop: 10, fontSize: 14 }}>{top.why}</div>
            <div style={{ display: 'flex', gap: 32, marginTop: 18, paddingTop: 16, borderTop: '1px solid var(--rule)' }}>
              <HeroStat label="typical duration" value={top.duration} />
              <HeroStat label="approx. cost" value={top.cost} />
              <HeroStat label="leverage score" value={top.leverage} />
            </div>
            <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
              <button className="btn info">Discuss with broker</button>
              <button className="btn ghost">View references</button>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>If you close this gap</div>
              <div style={{ marginTop: 8 }}>
                <span className="num-xl pos">−{kMoney(top.delta)}</span>
                <span className="num" style={{ color: 'var(--ink-soft)' }}> /yr</span>
              </div>
              <div className="caption" style={{ marginTop: 4 }}>
                {top.pct ? `${top.pct}% off your ${top.lineShort || (line && line.short)} premium` : `on ${top.lineName || (line && line.line)}`}
              </div>
            </div>
            <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 14, marginTop: 14 }}>
              <div className="micro">Evidence required</div>
              <div style={{ fontSize: 13, marginTop: 4 }}>{top.evidence}</div>
            </div>
          </div>
        </div>

        {/* Supporting actions */}
        {others.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${Math.min(3, others.length)}, 1fr)`, gap: 14, alignItems: 'stretch' }}>
            {others.slice(0, 3).map((a, i) => (
              <div key={i} className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span className="chip">#{i + 2}</span>
                    {cov === 'all' && <LineTag short={a.lineShort} />}
                  </div>
                  <span className={effortChip(a.effort)}>{a.effort}</span>
                </div>
                <h3 style={{ font: '600 17px/1.25 IBM Plex Sans', margin: 0, color: 'var(--ink)' }}>{a.headline}</h3>
                <div className="caption" style={{ marginTop: 6 }}>{a.signal}</div>
                <div style={{ marginTop: 'auto', paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid var(--rule)' }}>
                  <div>
                    <div className="micro">savings</div>
                    <div className="num pos">−{kMoney(a.delta)}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="micro">leverage · {a.leverage}</div>
                    <div className="caption">{a.duration}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* overflow note when there are more than 4 ranked moves (portfolio) */}
        {others.length > 3 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 18px', border: '1px dashed var(--rule-strong)', borderRadius: 10, background: 'var(--surface-sunken)' }}>
            <Icon name="list-plus" size={16} color="var(--ink-soft)" />
            <span className="caption" style={{ flex: 1 }}>
              {others.length - 3} more ranked move{others.length - 3 === 1 ? '' : 's'} across your book — {others.slice(3).map((a) => a.headline).join(' · ')}.
            </span>
            <button className="btn ghost">See all {ranked.length}</button>
          </div>
        )}
      </div>
    </FrameReimag>
  );
}

function HeroStat({ label, value }) {
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num-sm" style={{ marginTop: 2 }}>{value}</div>
    </div>
  );
}
function LineTag({ short }) {
  return (
    <span className="chip" style={{ background: 'var(--surface-sunken)', borderColor: 'var(--rule)', fontWeight: 600 }}>
      <Icon name="shield" size={11} /> {short}
    </span>
  );
}

/* ──────────────────────────────────────────────────────────────
 * 4. Industry Benchmarks — per-line cohorts + All small-multiples
 * ────────────────────────────────────────────────────────────── */
function ReimPeers({ isDark }) {
  const [cov, setCov] = useCoverage('all');
  const line = cov === 'all' ? null : lineByKey(cov);
  const title = cov === 'all'
    ? 'How you compare, line by line'
    : `How you compare to ${line.peers} peers in your ${line.short} cohort`;
  const sub = cov === 'all'
    ? 'Each line is scored against its own cohort — different peers, different medians. Pick a line for its full distribution.'
    : line.cohortLabel;

  return (
    <FrameReimag menu="Industry Benchmarks" entity={E2} isDark={isDark}>
      <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 18, height: '100%', alignContent: 'start' }}>
        <PageHead
          eyebrow="Industry benchmarks" title={title} sub={sub} active={cov} onChange={setCov}
          right={cov === 'all' ? (
            <div style={{ display: 'flex', gap: 12 }}>
              <MiniStat tone="pos" label="strongest" value={`${CLIENT_PORTFOLIO.bestLine.short} · ${CLIENT_PORTFOLIO.bestLine.score}`} />
              <MiniStat tone="warn" label="weakest" value={`${CLIENT_PORTFOLIO.weakLine.short} · ${CLIENT_PORTFOLIO.weakLine.score}`} />
            </div>
          ) : (
            <div style={{ display: 'flex', gap: 12 }}>
              <div className="card-info" style={{ padding: '14px 18px', borderRadius: 12, minWidth: 92 }}>
                <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>You</div>
                <div className="num" style={{ color: 'var(--info-deep)', marginTop: 4 }}>{line.score}</div>
              </div>
              <div className="card" style={{ padding: '14px 18px', minWidth: 92 }}>
                <div className="eyebrow">median</div>
                <div className="num" style={{ marginTop: 4 }}>{line.median}</div>
              </div>
              <div className="card" style={{ padding: '14px 18px', minWidth: 92 }}>
                <div className="eyebrow">top decile</div>
                <div className="num" style={{ marginTop: 4 }}>{line.topDecile}</div>
              </div>
            </div>
          )}
        />

        {cov === 'all' ? <PeersPortfolio onPick={setCov} /> : <PeersLine line={line} />}
      </div>
    </FrameReimag>
  );
}

function MiniStat({ tone, label, value }) {
  return (
    <div className={`card${tone === 'pos' ? '-pos' : tone === 'warn' ? '-spot' : ''}`} style={{ padding: '14px 18px', borderRadius: 12, minWidth: 120 }}>
      <div className="eyebrow" style={{ color: tone === 'pos' ? 'var(--pos)' : 'var(--warn)' }}>{label}</div>
      <div className="num-sm" style={{ fontSize: 18, marginTop: 4 }}>{value}</div>
    </div>
  );
}

/* All — small multiples + cross-line opportunities */
function PeersPortfolio({ onPick }) {
  // pull every "opportunity" practice across lines, tag + sort by peer adoption.
  const oppPractices = CLIENT_LINES.flatMap((l) =>
    l.practices.filter((p) => !p.you).map((p) => ({ ...p, lineShort: l.short, lineKey: l.key })))
    .sort((a, b) => b.pct - a.pct);

  return (
    <React.Fragment>
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: 0 }}>Standing in each cohort</h3>
          <span className="micro">click a line for its full distribution</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${CLIENT_LINES.length}, 1fr)`, gap: 14 }}>
          {CLIENT_LINES.map((l) => <MiniCohort key={l.key} line={l} onPick={onPick} />)}
        </div>
      </div>

      <div className="card" style={{ padding: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
          <div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: 0 }}>Top opportunities across your cohorts</h3>
            <div className="caption" style={{ marginTop: 4 }}>Practices your peers hold that you don't — % of peers with each in place</div>
          </div>
          <span className="chip chip-spot">{oppPractices.length} gaps</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          {oppPractices.map((p, i) => (
            <div key={i}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <LineTag short={p.lineShort} />{p.name}
                </span>
                <span className="num-sm">{p.pct}%</span>
              </div>
              <div style={{ height: 8, background: 'var(--surface-sunken)', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ width: `${p.pct}%`, height: '100%', background: 'var(--spot)' }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </React.Fragment>
  );
}

/* Per-line — full bell curve + practices */
function PeersLine({ line }) {
  const aboveMedian = line.score >= line.median;
  const subjColor = aboveMedian ? 'var(--info)' : 'var(--warn)';
  return (
    <React.Fragment>
      <div className="card" style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 28 }}>
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: 0 }}>Distribution of cohort scores</h3>
            <span className="caption">{line.peers} peers</span>
          </div>
          <BellCurve line={line} subjColor={subjColor} />
          <div className="body" style={{ marginTop: 4 }}>
            {aboveMedian
              ? <>You're outperforming the typical peer — <span className="info" style={{ fontWeight: 600 }}>{Math.max(0, line.topDecile - line.score)} points of headroom</span> separate you from the top-decile profile.</>
              : <>You're below the cohort median — <span className="warn" style={{ fontWeight: 600 }}>{line.median - line.score} points</span> would bring you back to typical, {line.topDecile - line.score} to the top decile.</>}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, paddingLeft: 20, borderLeft: '1px solid var(--rule)' }}>
          <div>
            <div className="eyebrow">How to read this</div>
            <p className="caption" style={{ marginTop: 6, lineHeight: 1.45 }}>
              Each peer in your {line.short} cohort is one point under the curve. Your score sits where the pin lands; the green band marks the top decile.
            </p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
            <div><div className="micro">cohort range</div><div className="num-sm">{line.range[0]}–{line.range[1]}</div></div>
            <div><div className="micro">cohort std dev</div><div className="num-sm">{line.sd} pts</div></div>
            <div><div className="micro">peers above you</div><div className="num-sm">{line.peersAbove} of {line.peers}</div></div>
            <div><div className="micro">to top decile</div><div className={`num-sm ${aboveMedian ? 'spot' : 'warn'}`}>+{Math.max(0, line.topDecile - line.score)}</div></div>
          </div>
          <div style={{ marginTop: 'auto', paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
            <div className="caption" style={{ marginBottom: 8 }}>
              {line.practices.filter((p) => !p.you).length} opportunities below could close that headroom.
            </div>
            <button className="btn spot">See action plan →</button>
          </div>
        </div>
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
          <div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: 0 }}>Practices that drive your peers' scores</h3>
            <div className="caption" style={{ marginTop: 4 }}>% of top-decile {line.short} peers with the practice in place</div>
          </div>
          <span className="chip chip-spot">opportunities highlighted</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          {line.practices.map((p) => (
            <div key={p.name}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <span style={{ fontSize: 13 }}>
                  {p.you
                    ? <span className="chip chip-pos" style={{ marginRight: 6 }}><Icon name="check" size={10} /> you</span>
                    : <span className="chip chip-spot" style={{ marginRight: 6 }}>opportunity</span>}
                  {p.name}
                </span>
                <span className="num-sm">{p.pct}%</span>
              </div>
              <div style={{ height: 8, background: 'var(--surface-sunken)', borderRadius: 4, overflow: 'hidden' }}>
                <div style={{ width: `${p.pct}%`, height: '100%', background: p.you ? 'var(--pos)' : 'var(--spot)' }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </React.Fragment>
  );
}

/* Generalised bell curve driven by a line's cohort params. */
function BellCurve({ line, subjColor = 'var(--info)' }) {
  const mean = line.cohortMean, sd = line.sd;
  const W = 720, H = 200;
  const lo = mean - 3 * sd, hi = mean + 3 * sd;
  const xs = [];
  for (let i = 0; i <= 60; i++) xs.push(lo + (hi - lo) * (i / 60));
  const ys = xs.map((x) => Math.exp(-0.5 * Math.pow((x - mean) / sd, 2)));
  const maxY = Math.max(...ys);
  const path = ys.map((y, i) => {
    const px = (i / 60) * W;
    const py = H - (y / maxY) * (H - 30);
    return `${i === 0 ? 'M' : 'L'}${px.toFixed(1)},${py.toFixed(1)}`;
  }).join(' ');
  const sx = (v) => ((v - lo) / (hi - lo)) * W;
  const subjectX = sx(line.score), medianX = sx(line.median), topX = sx(line.topDecile);
  // tick marks at rounded 50s within range
  const ticks = [];
  for (let t = Math.ceil(lo / 50) * 50; t <= hi; t += 50) ticks.push(t);
  const subjY = H - (Math.exp(-0.5 * Math.pow((line.score - mean) / sd, 2)) / maxY) * (H - 30);

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H + 30}`} preserveAspectRatio="xMidYMid meet" style={{ display: 'block' }}>
      <path d={`${path} L${W},${H} L0,${H} Z`} fill="var(--surface-sunken)" />
      <path d={path} fill="none" stroke="var(--ink-soft)" strokeWidth="1.5" />
      {ticks.map((s) => {
        const x = sx(s);
        return (
          <g key={s}>
            <line x1={x} y1={H} x2={x} y2={H + 4} stroke="var(--ink-mute)" />
            <text x={x} y={H + 18} textAnchor="middle" style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{s}</text>
          </g>
        );
      })}
      <line x1={medianX} y1={0} x2={medianX} y2={H} stroke="var(--ink-mute)" strokeDasharray="3 3" />
      <text x={medianX} y={14} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--ink-mute)' }}>median</text>
      <line x1={topX} y1={0} x2={topX} y2={H} stroke="var(--pos)" strokeDasharray="3 3" />
      <text x={topX} y={14} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--pos)' }}>top decile</text>
      <line x1={subjectX} y1={0} x2={subjectX} y2={H} stroke={subjColor} strokeWidth="2" />
      <circle cx={subjectX} cy={subjY} r="6" fill={subjColor} stroke="var(--surface)" strokeWidth="2" />
      <rect x={Math.max(2, subjectX - 54)} y={H - 96} width={108} height={46} fill={subjColor} rx="10" />
      <text x={Math.max(56, subjectX)} y={H - 76} textAnchor="middle" style={{ font: '700 16px IBM Plex Sans', fill: '#fff', letterSpacing: '0.02em' }}>YOU · {line.score}</text>
      <text x={Math.max(56, subjectX)} y={H - 59} textAnchor="middle" style={{ font: '500 11.5px IBM Plex Sans', fill: 'rgba(255,255,255,0.88)' }}>{line.percentile}th percentile</text>
      <polygon points={`${subjectX - 7},${H - 50} ${subjectX + 7},${H - 50} ${subjectX},${H - 42}`} fill={subjColor} />
    </svg>
  );
}

Object.assign(window, { ReimActions, ReimPeers });
