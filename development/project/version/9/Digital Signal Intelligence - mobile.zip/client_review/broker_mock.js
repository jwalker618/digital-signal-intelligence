/* global */

/* ============================================================
 * Mock data for the broker portal pages.
 *
 * One shared dataset so figures match across screens — Book of Clients
 * roster lines up with Client Health, Recommendations, Communications,
 * etc. The broker is "Marsh" with a 12-policy book.
 *
 * All numbers are illustrative and chosen to surface a realistic mix
 * of strong / mid / quiet engagement, tier spread, and a credible
 * line-of-business + industry breadth.
 * ============================================================ */

const BROKER = {
  name: 'Marsh — Northeast Specialty',
  shortName: 'Marsh',
};

const CARRIERS = [
  { slug: 'hartford-mutual',  name: 'Hartford Mutual', type: 'Carrier',     specialties: ['Cyber', 'PI'],      commission: 12.5, pricing: 'tight',  winRate: 0.72, esg: 'leader',      capacity: 'Large' },
  { slug: 'beazley',          name: 'Beazley',         type: 'Specialty',   specialties: ['Cyber', 'PI'],      commission: 13.8, pricing: 'tight',  winRate: 0.68, esg: 'progressive', capacity: 'Mid'   },
  { slug: 'chubb',            name: 'Chubb',           type: 'Carrier',     specialties: ['D&O', 'PI'],        commission: 11.2, pricing: 'median', winRate: 0.65, esg: 'neutral',     capacity: 'Large' },
  { slug: 'allianz',          name: 'Allianz',         type: 'Carrier',     specialties: ['Property', 'GL'],   commission: 10.5, pricing: 'median', winRate: 0.58, esg: 'leader',      capacity: 'Large' },
  { slug: 'munich-re',        name: 'Munich Re',       type: 'Reinsurer',   specialties: ['Property', 'CAT'],  commission:  9.8, pricing: 'light',  winRate: 0.61, esg: 'progressive', capacity: 'Large' },
  { slug: 'aspen',            name: 'Aspen',           type: 'Specialty',   specialties: ['Marine', 'Energy'], commission: 14.2, pricing: 'median', winRate: 0.54, esg: 'neutral',     capacity: 'Mid'   },
  { slug: 'aig',              name: 'AIG',             type: 'Carrier',     specialties: ['Casualty', 'D&O'],  commission: 11.7, pricing: 'light',  winRate: 0.49, esg: 'restrictive', capacity: 'Large' },
  { slug: 'axa-xl',           name: 'AXA XL',          type: 'Carrier',     specialties: ['Property', 'PI'],   commission: 11.5, pricing: 'median', winRate: 0.63, esg: 'leader',      capacity: 'Large' },
  { slug: 'travelers',        name: 'Travelers',       type: 'Carrier',     specialties: ['Workers Comp'],     commission: 10.8, pricing: 'tight',  winRate: 0.70, esg: 'neutral',     capacity: 'Large' },
  { slug: 'liberty-mutual',   name: 'Liberty Mutual',  type: 'Carrier',     specialties: ['Casualty', 'GL'],   commission: 11.0, pricing: 'median', winRate: 0.57, esg: 'progressive', capacity: 'Large' },
  { slug: 'zurich',           name: 'Zurich',          type: 'Carrier',     specialties: ['MedProf', 'GL'],    commission: 11.4, pricing: 'median', winRate: 0.60, esg: 'leader',      capacity: 'Large' },
  { slug: 'swiss-re',         name: 'Swiss Re',        type: 'Reinsurer',   specialties: ['CAT', 'Property'],  commission:  9.5, pricing: 'light',  winRate: 0.55, esg: 'leader',      capacity: 'Large' },
];

/**
 * Book of 12 clients across 5 industries. Tiers + scores spread to give
 * a realistic curve: a few stars (tier 2 / score 740+), most mid, a
 * couple in tier 4-5 needing attention.
 */
const BOOK = [
  // strong
  { code: 'SUB-26-0118', entity: 'Eastward Robotics',     vertical: 'Industrial Robotics', line: 'Cyber',          carrier: 'Hartford Mutual', score: 724, tier: 2, percentile: 64, premium: 185200, status: 'In review',    statusTone: 'spot', engagement: 78, opps: 2, risks: 0, renewalDays: 38 },
  { code: 'SUB-26-0119', entity: 'Eastward Robotics',     vertical: 'Industrial Robotics', line: 'PI',             carrier: 'Beazley',         score: 758, tier: 2, percentile: 79, premium: 162000, status: 'Bound',        statusTone: 'pos',  engagement: 78, opps: 0, risks: 0, renewalDays: 38 },
  { code: 'SUB-26-0120', entity: 'Eastward Robotics',     vertical: 'Industrial Robotics', line: 'D&O',            carrier: 'Chubb',           score: 648, tier: 4, percentile: 42, premium: 140500, status: 'Awaiting',     statusTone: 'spot', engagement: 78, opps: 1, risks: 0, renewalDays: 38 },
  { code: 'SUB-26-0121', entity: 'AscendCare Health',     vertical: 'Healthcare',          line: 'MedProf',        carrier: 'Zurich',          score: 712, tier: 3, percentile: 58, premium: 248000, status: 'Bound',        statusTone: 'pos',  engagement: 84, opps: 1, risks: 0, renewalDays: 142 },
  { code: 'SUB-26-0122', entity: 'AscendCare Health',     vertical: 'Healthcare',          line: 'D&O',            carrier: 'Chubb',           score: 692, tier: 3, percentile: 52, premium: 95000, status: 'Bound',        statusTone: 'pos',  engagement: 84, opps: 0, risks: 0, renewalDays: 142 },
  { code: 'SUB-26-0123', entity: 'TerraWind Energy',      vertical: 'Energy',              line: 'Property',       carrier: 'Munich Re',       score: 681, tier: 3, percentile: 47, premium: 412000, status: 'In review',    statusTone: 'spot', engagement: 56, opps: 2, risks: 1, renewalDays: 21 },
  { code: 'SUB-26-0124', entity: 'TerraWind Energy',      vertical: 'Energy',              line: 'Casualty',       carrier: 'AIG',             score: 654, tier: 4, percentile: 38, premium: 178000, status: 'In review',    statusTone: 'spot', engagement: 56, opps: 1, risks: 1, renewalDays: 21 },
  { code: 'SUB-26-0125', entity: 'NorthRiver Logistics',  vertical: 'Transportation',      line: 'Marine',         carrier: 'Aspen',           score: 705, tier: 3, percentile: 54, premium: 162000, status: 'Bound',        statusTone: 'pos',  engagement: 71, opps: 1, risks: 0, renewalDays: 87 },
  { code: 'SUB-26-0126', entity: 'NorthRiver Logistics',  vertical: 'Transportation',      line: 'GL',             carrier: 'Liberty Mutual',  score: 696, tier: 3, percentile: 51, premium: 89000, status: 'Bound',        statusTone: 'pos',  engagement: 71, opps: 0, risks: 0, renewalDays: 87 },
  { code: 'SUB-26-0127', entity: 'BrightLeaf Pharma',     vertical: 'Pharmaceuticals',     line: 'Product Liability', carrier: 'AIG',          score: 668, tier: 4, percentile: 41, premium: 296000, status: 'Awaiting',     statusTone: 'spot', engagement: 32, opps: 3, risks: 2, renewalDays: 14 },
  { code: 'SUB-26-0128', entity: 'BrightLeaf Pharma',     vertical: 'Pharmaceuticals',     line: 'D&O',            carrier: 'Chubb',           score: 642, tier: 4, percentile: 36, premium: 148000, status: 'Bound',        statusTone: 'pos',  engagement: 32, opps: 1, risks: 1, renewalDays: 14 },
  { code: 'SUB-26-0129', entity: 'FifthRail Industrial',  vertical: 'Industrial Robotics', line: 'Workers Comp',   carrier: 'Travelers',       score: 738, tier: 2, percentile: 71, premium: 102000, status: 'Bound',        statusTone: 'pos',  engagement: 35, opps: 1, risks: 1, renewalDays: 56 },
];

/* Engagement label derived from score */
function engagementLabel(score) {
  if (score >= 80) return 'Strong';
  if (score >= 60) return 'Active';
  if (score >= 40) return 'Quiet';
  return 'Dormant';
}

/* Aggregate the book into per-client rows for Client Health */
function bookByClient() {
  const map = new Map();
  for (const p of BOOK) {
    if (!map.has(p.entity)) {
      map.set(p.entity, {
        entity: p.entity, vertical: p.vertical,
        policies: [], totalPremium: 0,
        avgScore: 0, engagement: p.engagement,
        opps: 0, risks: 0,
        nextRenewalDays: Infinity,
      });
    }
    const row = map.get(p.entity);
    row.policies.push(p);
    row.totalPremium += p.premium;
    row.avgScore += p.score;
    row.opps     += p.opps;
    row.risks    += p.risks;
    if (p.renewalDays < row.nextRenewalDays) row.nextRenewalDays = p.renewalDays;
  }
  for (const row of map.values()) {
    row.avgScore = Math.round(row.avgScore / row.policies.length);
    row.engagementLabel = engagementLabel(row.engagement);
  }
  return Array.from(map.values()).sort((a, b) => b.engagement - a.engagement);
}

/* Coverage-gap recommendations per client.
 * For each client, suggest lines they're missing that peers in their
 * vertical typically carry. */
const RECS = [
  { entity: 'TerraWind Energy',     vertical: 'Energy',              line: 'Cyber',              rationale: 'Energy operators of TerraWind\'s scale typically carry standalone cyber. Recent ransomware events affecting the sector reinforce the case.', range: [180000, 320000] },
  { entity: 'BrightLeaf Pharma',    vertical: 'Pharmaceuticals',     line: 'Cyber',              rationale: 'Pharma supply-chain attacks have spiked 40% YoY. BrightLeaf carries no standalone cyber today.', range: [220000, 410000] },
  { entity: 'BrightLeaf Pharma',    vertical: 'Pharmaceuticals',     line: 'Clinical Trials',     rationale: 'Two active Phase II trials. Clinical trial liability is standard for the cohort.',          range: [95000, 180000]  },
  { entity: 'NorthRiver Logistics', vertical: 'Transportation',      line: 'Cyber',              rationale: 'TMS + fleet telematics expose digital footprint. Mid-size carriers in the cohort moved to cyber over 2025.', range: [120000, 240000] },
  { entity: 'FifthRail Industrial', vertical: 'Industrial Robotics', line: 'Cyber',              rationale: 'OT environment increasingly targeted. Eastward (sister vertical) carries cyber primary.',   range: [160000, 290000] },
  { entity: 'FifthRail Industrial', vertical: 'Industrial Robotics', line: 'Product Liability',  rationale: 'Heavy-equipment exposure on the floor. Industry default to carry product liability.',       range: [110000, 210000] },
];

/* Open broker-side queries — these mirror the client-side Communications
 * data but from the broker's vantage (across the whole book). */
const BROKER_QUERIES = [
  { entity: 'Eastward Robotics',     line: 'Cyber',  carrier: 'Hartford Mutual', ask: 'Need MFA AAL2 attestation before binding',                       awaiting: 'client',  age: '2h',  refCode: 'REF-2026-04832' },
  { entity: 'Eastward Robotics',     line: 'Cyber',  carrier: 'Hartford Mutual', ask: 'SOC 2 Type II report or equivalent attestation requested',       awaiting: 'client',  age: '1d',  refCode: 'REF-2026-04833' },
  { entity: 'TerraWind Energy',      line: 'Property',carrier: 'Munich Re',      ask: 'COPE valuation update + flood elevation on the Texas locations', awaiting: 'broker',  age: '4h',  refCode: 'REF-2026-04841' },
  { entity: 'TerraWind Energy',      line: 'Casualty',carrier: 'AIG',            ask: 'Updated loss runs through Q1 2026',                              awaiting: 'broker',  age: '6h',  refCode: 'REF-2026-04842' },
  { entity: 'AscendCare Health',     line: 'D&O',    carrier: 'Chubb',           ask: 'Updated board roster + bios for current FY',                      awaiting: 'client',  age: '3d',  refCode: 'REF-2026-04812' },
  { entity: 'BrightLeaf Pharma',     line: 'Product Liability', carrier: 'AIG',  ask: 'Recall reserves and historical recall summary',                  awaiting: 'broker',  age: '2d',  refCode: 'REF-2026-04855' },
  { entity: 'NorthRiver Logistics',  line: 'Marine', carrier: 'Aspen',           ask: "Acknowledged — we'll close this thread when the rider is bound.", awaiting: 'resolved', age: '5d', refCode: 'REF-2026-04790' },
];

/* Market pulse lines */
const MARKET_LINES = [
  { slug: 'cyber',    name: 'Cyber',                 cycle: 'Softening',   rateYoY: -3.5, capacity: 'Abundant', capacityTrend: 'Expanding',   lossTrend: 'Improving',   esgOverlay: 'Carriers diverging — Allianz / AXA tightening on fossil-fuel adjacent risk.' },
  { slug: 'property', name: 'Property',              cycle: 'Hardening',   rateYoY:  8.2, capacity: 'Tight',    capacityTrend: 'Contracting', lossTrend: 'Deteriorating', esgOverlay: 'Climate-physical underwriting now table-stakes — Munich Re leading.' },
  { slug: 'casualty', name: 'Casualty / GL',         cycle: 'Hardening',   rateYoY:  5.8, capacity: 'Stable',   capacityTrend: 'Selective',   lossTrend: 'Deteriorating', esgOverlay: 'Social inflation cited in 60% of recent appetite revisions.' },
  { slug: 'pi',       name: 'Professional Indemnity', cycle: 'Balanced',   rateYoY:  1.4, capacity: 'Stable',   capacityTrend: 'Stable',      lossTrend: 'Stable',       esgOverlay: 'Quiet — ESG less prominent here than other lines.' },
  { slug: 'do',       name: 'Directors & Officers',  cycle: 'Softening',   rateYoY: -4.8, capacity: 'Abundant', capacityTrend: 'Expanding',   lossTrend: 'Improving',     esgOverlay: 'Greenwashing claims a watch-item; otherwise benign.' },
  { slug: 'marine',   name: 'Marine',                cycle: 'Hardening',   rateYoY:  6.5, capacity: 'Tight',    capacityTrend: 'Contracting', lossTrend: 'Worsening',     esgOverlay: 'Red Sea routing + climate effects driving rate.' },
  { slug: 'medprof',  name: 'Medical Professional',  cycle: 'Hardening',   rateYoY:  9.4, capacity: 'Tight',    capacityTrend: 'Contracting', lossTrend: 'Worsening',     esgOverlay: 'Mental-health claim drift broadening definition of harm.' },
];

const LOSS_EVENTS = [
  { date: '2026 Q1', line: 'Cyber',     headline: 'Major ransomware operator hits 3 European energy majors', industryLossB: 4.2, implication: 'Reinforces case for OT-specific incident planning; carriers tightening on standalone industrial-controls cover.' },
  { date: '2025 Q4', line: 'Property',  headline: 'Atlantic Hurricane "Wendell" — Florida + Carolinas',     industryLossB: 28.5, implication: 'Property capacity for coastal exposures contracting through Q1 2026; Munich Re leading retrenchment.' },
  { date: '2025 Q4', line: 'Marine',    headline: 'Red Sea routing crisis enters its 18th month',           industryLossB: 5.1, implication: 'Hull + cargo rates up 18% YoY for Suez-transit risks; rerouting premiums likely sticky.' },
  { date: '2025 Q3', line: 'Casualty',  headline: 'Three nuclear verdicts $250M+ in California auto cases', industryLossB: 1.8, implication: 'Excess casualty pricing harder; auto-fleet capacity rationing observed.' },
];

/* CAT peril exposure on the book */
const CAT_PERILS = [
  { slug: 'atlantic-hurricane', name: 'Atlantic Hurricane',   icon: 'cloud',         severity: 0.42, exposedPolicies: 4, exposedPremiumUsd: 614000, topVerticals: ['Energy', 'Healthcare']     },
  { slug: 'wildfire',           name: 'Wildfire',             icon: 'flame',         severity: 0.28, exposedPolicies: 3, exposedPremiumUsd: 392000, topVerticals: ['Energy', 'Transportation'] },
  { slug: 'earthquake-cascadia',name: 'Earthquake (Cascadia)',icon: 'activity',      severity: 0.18, exposedPolicies: 2, exposedPremiumUsd: 247000, topVerticals: ['Industrial Robotics']       },
  { slug: 'cyber-ransomware',   name: 'Cyber Ransomware Wave',icon: 'shield-alert',  severity: 0.62, exposedPolicies: 5, exposedPremiumUsd: 487700, topVerticals: ['Industrial Robotics', 'Pharmaceuticals'] },
  { slug: 'cloud-outage',       name: 'Cloud Outage',         icon: 'cloud-off',     severity: 0.34, exposedPolicies: 6, exposedPremiumUsd: 502000, topVerticals: ['Pharmaceuticals', 'Healthcare']         },
  { slug: 'supply-chain',       name: 'Supply-chain Disruption', icon: 'network',    severity: 0.48, exposedPolicies: 5, exposedPremiumUsd: 728000, topVerticals: ['Energy', 'Pharmaceuticals']             },
];

Object.assign(window, {
  BROKER, BROKER_BOOK: BOOK, BROKER_CARRIERS: CARRIERS, BROKER_RECS: RECS,
  BROKER_QUERIES, BROKER_MARKET_LINES: MARKET_LINES, BROKER_LOSS_EVENTS: LOSS_EVENTS,
  BROKER_CAT_PERILS: CAT_PERILS, bookByClient, engagementLabel,
});
