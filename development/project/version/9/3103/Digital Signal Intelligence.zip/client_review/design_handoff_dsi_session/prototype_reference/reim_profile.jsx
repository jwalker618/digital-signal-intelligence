/* global React, FrameReimag, Icon */

/* ============================================================
 * Profile — "Who you are"
 *
 * Layout
 *   row 1 — hero strip: identity hero + signal-apparatus completeness
 *   row 2 — identity facts | active coverage lines (2 cards)
 *   row 3 — signal apparatus (captured + pending grid)
 *   row 4 — privacy footer
 * ============================================================ */

const ENT_P = 'Eastward Robotics, Inc.';

function ReimProfile({ isDark }) {
  const captured = [
    { name: 'Identity & domain',     icon: 'building-2' },
    { name: 'Cyber posture',         icon: 'shield-check' },
    { name: 'Financial signals',     icon: 'trending-up' },
    { name: 'Claims history',        icon: 'history' },
    { name: 'Exposure scale',        icon: 'globe' },
    { name: 'Industry baseline',     icon: 'briefcase' },
  ];
  const pending = [
    { name: 'Third-party audit attestations', icon: 'file-badge' },
    { name: 'Supply-chain dependencies',      icon: 'link' },
  ];
  const lines = [
    { name: 'Cyber',                     status: 'active', tier: 2, premium: 185200 },
    { name: 'Professional Indemnity',    status: 'active', tier: 2, premium: 162000 },
    { name: 'Directors & Officers',      status: 'active', tier: 4, premium: 140500 },
  ];

  return (
    <FrameReimag menu="Your Profile" entity={ENT_P.replace(', Inc.', '')} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* ROW 1 — hero strip */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 24, display: 'flex', gap: 24, alignItems: 'center' }}>
            <div style={{
              width: 72, height: 72, borderRadius: 12,
              background: 'var(--info-soft)',
              color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Icon name="cpu" size={36} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">Insured</div>
              <h2 className="display" style={{ marginTop: 4 }}>{ENT_P}</h2>
              <div className="caption" style={{ marginTop: 6 }}>
                Industrial Robotics · NAICS 333999 · USA · Revenue band 50–250M
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
                <span className="chip"><Icon name="building-2" size={11} /> Marsh, broker</span>
                <span className="chip chip-pos"><Icon name="check" size={11} /> 3 policies active</span>
                <span className="chip"><Icon name="globe" size={11} /> 2 states</span>
              </div>
            </div>
          </div>
          <div className="card-info" style={{ padding: 22 }}>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Signal apparatus</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 8 }}>
              <span className="num-xl" style={{ color: 'var(--info-deep)' }}>6/8</span>
              <span className="caption">categories captured</span>
            </div>
            <div style={{ marginTop: 12, height: 6, background: 'var(--surface-sunken)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: '75%', height: '100%', background: 'var(--info)' }} />
            </div>
            <div className="caption" style={{ marginTop: 10 }}>
              Two categories pending — see below for what would strengthen the picture.
            </div>
          </div>
        </div>

        {/* ROW 2 — identity facts + active coverage lines */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Identity</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>Registered details</h3>
            <FactList rows={[
              ['Legal entity',    ENT_P],
              ['Domain',          'eastwardrobotics.com'],
              ['Country',         'United States'],
              ['NAICS',           '333999 — Industrial machinery'],
              ['Revenue band',    '$50M – $250M'],
              ['Broker of record', 'Marsh'],
              ['Joined DSI',      'March 2024'],
            ]} />
          </div>
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow">Active coverage lines</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>What you currently hold</h3>
              </div>
              <span className="caption">3 lines · $487,700 total</span>
            </div>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {lines.map((l) => (
                <div key={l.name} style={{
                  display: 'grid', gridTemplateColumns: '1fr 80px 100px',
                  alignItems: 'center', gap: 12,
                  padding: '10px 14px',
                  background: 'var(--surface-elev)', borderRadius: 10,
                  border: '1px solid var(--rule)',
                }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{l.name}</div>
                    <div className="micro">Tier {l.tier}</div>
                  </div>
                  <span className="chip chip-pos" style={{ justifySelf: 'start' }}>Active</span>
                  <div style={{ textAlign: 'right', fontSize: 13, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>
                    ${(l.premium / 1000).toFixed(0)}k
                  </div>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 6, color: 'var(--info-deep)' }}>
              <Icon name="shield-check" size={13} /> Open any line in Coverages for its full policy record
            </div>
          </div>
        </div>

        {/* ROW 3 — signal apparatus detail */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow">Signal apparatus</div>
              <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>What DSI observes about you</h3>
              <div className="caption" style={{ marginTop: 4 }}>
                Captured categories contributed to your current quote; pending categories would strengthen the picture if data became available.
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            <div>
              <div className="chip chip-pos" style={{ marginBottom: 10 }}>
                <Icon name="check-circle-2" size={12} /> Captured · 6 categories
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {captured.map((c) => (
                  <div key={c.name} style={{
                    display: 'flex', alignItems: 'center', gap: 8,
                    padding: '10px 12px', borderRadius: 8,
                    background: 'color-mix(in srgb, var(--surface) 92%, var(--pos) 8%)',
                    border: '1px solid var(--pos-soft)',
                  }}>
                    <Icon name={c.icon} size={16} color="var(--pos)" />
                    <span style={{ fontSize: 13 }}>{c.name}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="chip chip-spot" style={{ marginBottom: 10 }}>
                <Icon name="circle" size={12} /> Pending · 2 categories
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {pending.map((c) => (
                  <div key={c.name} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8,
                    padding: '12px 14px', borderRadius: 8,
                    border: '1px dashed var(--spot)',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <Icon name={c.icon} size={16} color="var(--spot)" />
                      <span style={{ fontSize: 13 }}>{c.name}</span>
                    </div>
                    <span style={{ fontSize: 12 }} className="spot">Share with broker →</span>
                  </div>
                ))}
                <div className="caption" style={{ marginTop: 8 }}>
                  Sharing these would let DSI close two of the remaining headroom signals on your renewal.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ROW 4 — privacy */}
        <div style={{
          padding: '14px 18px',
          border: '1px solid var(--rule)',
          borderRadius: 10,
          background: 'var(--surface-sunken)',
          display: 'flex', alignItems: 'flex-start', gap: 12,
        }}>
          <Icon name="lock" size={18} color="var(--ink-soft)" style={{ marginTop: 1, flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 600, marginBottom: 2 }}>Privacy</div>
            <div className="caption" style={{ lineHeight: 1.5 }}>
              Your DSI profile is built from publicly-observable signals and information you've
              shared through your broker. We never use your data to make decisions affecting other
              clients, and you can request the full audit trail of any signal at any time.
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function FactList({ rows }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
      {rows.map(([label, value], i) => (
        <div key={i} style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          padding: '8px 0', borderBottom: i < rows.length - 1 ? '1px solid var(--rule)' : 0,
        }}>
          <span className="micro">{label}</span>
          <span style={{ fontSize: 13, fontWeight: 600, textAlign: 'right' }}>{value}</span>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { ReimProfile });
