/* global React, Icon, CLIENT_LINES, CLIENT_PORTFOLIO, COVERAGE_OPTIONS, lineByKey, kMoney, CohortBar */

/* ============================================================
 * client_switcher.jsx — the live coverage switcher + the shared
 * portfolio building blocks used across the four client pages.
 *
 * One segmented control: [ All · Cyber · PI · D&O ]. "All" renders
 * the portfolio roll-up; any line re-renders the page for that line.
 * Scales past the three real lines (horizontal overflow + counts).
 * ============================================================ */

const { useState } = React;

/* useCoverage — page-local selected-line state. */
function useCoverage(initial = 'all') {
  const [active, setActive] = useState(initial);
  return [active, setActive];
}

/* ─── CoverageSwitcher — segmented control, top of every page ───── */
function CoverageSwitcher({ active, onChange, options = COVERAGE_OPTIONS, count }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 4, padding: 4,
      background: 'var(--surface-sunken)', border: '1px solid var(--rule)',
      borderRadius: 12, maxWidth: '100%', overflowX: 'auto',
    }}>
      {options.map((o) => {
        const on = o.key === active;
        const isAll = o.key === 'all';
        return (
          <button
            key={o.key}
            onClick={() => onChange(o.key)}
            title={o.short}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 7,
              padding: '8px 14px', borderRadius: 9, whiteSpace: 'nowrap',
              border: '1px solid ' + (on ? 'var(--rule)' : 'transparent'),
              background: on ? 'var(--surface)' : 'transparent',
              boxShadow: on ? '0 1px 3px rgba(11,34,55,0.10)' : 'none',
              color: on ? 'var(--ink)' : 'var(--ink-mute)',
              fontWeight: on ? 600 : 500, fontSize: 13.5, cursor: 'pointer',
              fontFamily: 'IBM Plex Sans, sans-serif', transition: 'all .15s ease',
            }}
          >
            <Icon name={o.icon} size={15} color={on ? (isAll ? 'var(--ink)' : 'var(--info-deep)') : 'var(--ink-mute)'} />
            {o.short}
            {isAll && (
              <span style={{
                fontSize: 11, fontWeight: 700, lineHeight: 1,
                padding: '2px 6px', borderRadius: 999,
                background: on ? 'var(--ink)' : 'var(--rule)',
                color: on ? 'var(--canvas)' : 'var(--ink-soft)',
              }}>{count != null ? count : (options.length - 1)}</span>
            )}
            {!isAll && o.statusTone === 'spot' && (
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--spot)' }} />
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ─── PageHead — eyebrow + title + switcher in one consistent strip ─ */
function PageHead({ eyebrow, title, sub, active, onChange, right }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24, flexWrap: 'wrap' }}>
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h2 className="display" style={{ marginTop: 6 }}>{title}</h2>
          {sub && <div className="caption" style={{ marginTop: 6 }}>{sub}</div>}
        </div>
        {right}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <CoverageSwitcher active={active} onChange={onChange} />
        <span className="micro" style={{ color: 'var(--ink-mute)' }}>
          {active === 'all'
            ? `Portfolio view · ${CLIENT_PORTFOLIO.lineCount} active lines`
            : `Viewing ${lineByKey(active).line} · ${lineByKey(active).carrier}`}
        </span>
      </div>
    </div>
  );
}

/* ─── StatusChip — line status as a tone chip ───────────────────── */
function StatusChip({ tone, children }) {
  return <span className={`chip chip-${tone}`}>{children}</span>;
}

/* ─── StandingStrip — per-line standing cards (Summary portfolio) ──
 *  Each card is clickable and drills the page into that line. */
function StandingStrip({ onPick, activeKey }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${CLIENT_LINES.length}, 1fr)`, gap: 14 }}>
      {CLIENT_LINES.map((l) => {
        const up = l.score >= l.prev;
        const delta = l.score - l.prev;
        const aboveMedian = l.score >= l.median;
        return (
          <button
            key={l.key}
            onClick={() => onPick(l.key)}
            className="card"
            style={{
              textAlign: 'left', cursor: 'pointer', padding: 18,
              border: activeKey === l.key ? '1.5px solid var(--info)' : '1px solid var(--rule)',
              display: 'flex', flexDirection: 'column', gap: 12,
              fontFamily: 'IBM Plex Sans, sans-serif',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                <div style={{
                  width: 30, height: 30, borderRadius: 8, background: 'var(--surface-elev)',
                  border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon name={l.icon} size={15} color="var(--ink)" />
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{l.short}</div>
                  <div className="micro">{l.carrier}</div>
                </div>
              </div>
              <Icon name="chevron-right" size={16} color="var(--ink-mute)" />
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
              <div>
                <div className="num" style={{ fontSize: 30, color: aboveMedian ? 'var(--info-deep)' : 'var(--warn)', lineHeight: 1 }}>{l.score}</div>
                <div className="micro" style={{ marginTop: 3 }}>{l.percentile}th percentile</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
                <span className={`chip chip-${up ? 'pos' : 'neg'}`}>
                  <Icon name={up ? 'arrow-up' : 'arrow-down'} size={10} /> {up ? '+' : ''}{delta}
                </span>
                <StatusChip tone={l.statusTone}>{l.status}</StatusChip>
              </div>
            </div>
            {/* position-on-cohort micro bar */}
            <div style={{ position: 'relative', height: 5, background: 'var(--surface-sunken)', borderRadius: 3 }}>
              <div style={{
                position: 'absolute', top: -2, height: 9, width: 2.5, borderRadius: 2,
                background: 'var(--ink-mute)',
                left: `${((l.median - l.range[0]) / (l.range[1] - l.range[0])) * 100}%`,
              }} />
              <div style={{
                position: 'absolute', top: '50%', transform: 'translate(-50%,-50%)',
                width: 10, height: 10, borderRadius: '50%',
                background: aboveMedian ? 'var(--info)' : 'var(--warn)', border: '2px solid var(--surface)',
                left: `${((l.score - l.range[0]) / (l.range[1] - l.range[0])) * 100}%`,
              }} />
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ─── OppByLineBar — "where the upside is" proportional bars ─────── */
function OppByLineBar({ data, max }) {
  const peak = max || Math.max(...data.map((d) => d.amount));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {data.map((d) => (
        <div key={d.key}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
            <span style={{ fontSize: 13, fontWeight: 500 }}>{d.name}</span>
            <span className="num-sm spot" style={{ fontSize: 14 }}>−{kMoney(d.amount)}</span>
          </div>
          <div style={{ height: 8, background: 'var(--surface-sunken)', borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ width: `${(d.amount / peak) * 100}%`, height: '100%', background: d.color, borderRadius: 4 }} />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── MiniCohort — compact per-line standing row for Benchmarks All ─ */
function MiniCohort({ line, onPick }) {
  const aboveMedian = line.score >= line.median;
  const scale = (v) => ((v - line.range[0]) / (line.range[1] - line.range[0])) * 100;
  return (
    <button
      onClick={() => onPick && onPick(line.key)}
      className="card"
      style={{ textAlign: 'left', cursor: 'pointer', padding: 18, display: 'flex', flexDirection: 'column', gap: 12, fontFamily: 'IBM Plex Sans, sans-serif' }}
    >
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <Icon name={line.icon} size={16} color="var(--ink)" />
          <span style={{ fontSize: 14.5, fontWeight: 600 }}>{line.line}</span>
        </div>
        <span className="caption">{line.peers} peers</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <span className="num" style={{ fontSize: 26, color: aboveMedian ? 'var(--info-deep)' : 'var(--warn)' }}>{line.score}</span>
        <span className="micro">{line.percentile}th percentile · {line.peersAbove} of {line.peers} above you</span>
      </div>
      {/* track */}
      <div style={{ position: 'relative', height: 12, marginTop: 2 }}>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 4, height: 6, background: 'var(--surface-sunken)', borderRadius: 3 }} />
        <div style={{
          position: 'absolute', top: 4, height: 6, borderRadius: 3, background: 'var(--pos-soft)',
          left: `${scale(line.topDecile)}%`, right: 0,
        }} />
        <div style={{ position: 'absolute', top: 0, height: 14, width: 2, background: 'var(--ink-mute)', left: `${scale(line.median)}%` }} />
        <div style={{ position: 'absolute', top: 0, height: 14, width: 2, background: 'var(--pos)', left: `${scale(line.topDecile)}%` }} />
        <div style={{
          position: 'absolute', top: '50%', transform: 'translate(-50%,-50%)', width: 13, height: 13, borderRadius: '50%',
          background: aboveMedian ? 'var(--info)' : 'var(--warn)', border: '2px solid var(--surface)',
          left: `${scale(line.score)}%`,
        }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span className="micro">median {line.median}</span>
        <span className="micro" style={{ color: 'var(--pos)' }}>top 10% {line.topDecile}</span>
      </div>
    </button>
  );
}

Object.assign(window, {
  useCoverage, CoverageSwitcher, PageHead, StatusChip,
  StandingStrip, OppByLineBar, MiniCohort,
});
