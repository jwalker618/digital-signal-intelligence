/* global React, FrameReimag, Icon, AdminTable, AdminKpi */

/* ============================================================
 * Admin Console — Recalibration list + detail
 * ============================================================ */

const ADMIN_ORG3 = 'Hartford Mutual';

/* ─── 06 Recalibration list ───────────────────────────────── */
function ReimAdminRecalibration({ isDark }) {
  const proposals = [
    { id: 'RP-9842', coverage: 'cyber',    config: 'signal_weights',   trigger: 'Drift alert DA-879',    sample: 1820, weights:  4, tiers: 0, proposed: '6h ago',   status: 'PENDING_REVIEW' },
    { id: 'RP-9839', coverage: 'property', config: 'cope_modifiers',   trigger: 'Quarterly recal',       sample:  920, weights:  6, tiers: 1, proposed: '1d ago',   status: 'PENDING_REVIEW' },
    { id: 'RP-9836', coverage: 'pharma',   config: 'signal_weights',   trigger: 'Loss event linkage',    sample:  540, weights:  3, tiers: 0, proposed: '3d ago',   status: 'APPROVED'       },
    { id: 'RP-9830', coverage: 'cyber',    config: 'tier_thresholds',  trigger: 'Quarterly recal',       sample: 1820, weights:  0, tiers: 2, proposed: '5d ago',   status: 'DEPLOYED'       },
    { id: 'RP-9824', coverage: 'do',       config: 'signal_weights',   trigger: 'Manual exploration',    sample:  410, weights:  2, tiers: 0, proposed: '1w ago',   status: 'REJECTED'       },
    { id: 'RP-9819', coverage: 'casualty', config: 'signal_weights',   trigger: 'Drift alert DA-721',    sample:  680, weights:  5, tiers: 1, proposed: '2w ago',   status: 'DEPLOYED'       },
  ];
  const statusTone = (s) =>
      s === 'DEPLOYED'        ? 'pos'
    : s === 'APPROVED'        ? 'info'
    : s === 'PENDING_REVIEW'  ? 'spot'
    : s === 'REJECTED'        ? 'neg'
    : 'mute';

  return (
    <FrameReimag menu="Recalibration" entity={ADMIN_ORG3} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Recalibration</div>
            <h2 className="display" style={{ marginTop: 6 }}>Proposals awaiting governance</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Model-suggested weight + tier changes. Approve → Deploy through the detail page. Drift-triggered proposals are prioritised.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 24 }}>
            <AdminKpi label="Pending"  value={proposals.filter(p => p.status === 'PENDING_REVIEW').length} tone="spot" />
            <AdminKpi label="Approved" value={proposals.filter(p => p.status === 'APPROVED').length}      tone="info" />
            <AdminKpi label="Deployed" value={proposals.filter(p => p.status === 'DEPLOYED').length}      tone="pos" />
            <AdminKpi label="Rejected" value={proposals.filter(p => p.status === 'REJECTED').length} />
          </div>
        </div>

        {/* filter bar */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="micro" style={{ marginRight: 4 }}>Status:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
          <span className="chip">Pending</span>
          <span className="chip">Approved</span>
          <span className="chip">Deployed</span>
          <span className="chip">Rejected</span>
          <span style={{ width: 16 }} />
          <span className="micro">Coverage:</span>
          <span className="chip">Cyber</span>
          <span className="chip">Property</span>
          <span className="chip">Casualty</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: newest first</span>
        </div>

        {/* table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <AdminTable
            cols="100px 1fr 1.4fr 1.6fr 80px 80px 70px 110px 130px 80px"
            headers={['ID', 'Coverage', 'Config', 'Trigger', 'Sample', 'Weights', 'Tiers', 'Proposed', 'Status', '']}
            rows={proposals.map((p) => [
              <code style={{ fontSize: 12, fontWeight: 700 }}>{p.id}</code>,
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12, textTransform: 'uppercase', fontWeight: 600 }}>{p.coverage}</span>,
              <code style={{ fontSize: 12 }}>{p.config}</code>,
              <span className="caption">{p.trigger}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{p.sample}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: p.weights > 0 ? 600 : 400 }}>{p.weights}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: p.tiers > 0 ? 600 : 400 }}>{p.tiers}</span>,
              <span className="micro">{p.proposed}</span>,
              <span className={`chip chip-${statusTone(p.status)}`} style={{ justifySelf: 'flex-start' }}>{p.status.replace('_', ' ')}</span>,
              <a href="#" style={{ fontSize: 12, fontWeight: 600, color: 'var(--info)' }}>Review →</a>,
            ])}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

/* ─── 07 Recalibration · detail ─────────────────────────────── */
function ReimAdminRecalDetail({ isDark }) {
  const weights = [
    { signal: 'mfa_admin_coverage',      current: 0.182, proposed: 0.205, why: 'Stronger negative correlation with cyber loss propensity post-DA-879 cohort refresh' },
    { signal: 'backup_encryption',       current: 0.128, proposed: 0.142, why: 'Loss-attribution showed higher protective value than v11 estimate' },
    { signal: 'soc2_attestation',        current: 0.246, proposed: 0.220, why: 'Diminishing marginal lift after population shift toward universal SOC 2 adoption' },
    { signal: 'public_rdp_exposed',      current: 0.094, proposed: 0.108, why: 'Population shift smaller than expected; effect size held' },
  ];
  const tiers = [
    { band: 'TIER_2', boundary: 'upper', current: 750, proposed: 745 },
    { band: 'TIER_3', boundary: 'upper', current: 700, proposed: 695 },
  ];

  return (
    <FrameReimag menu="Recalibration" entity={ADMIN_ORG3} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* breadcrumb + header */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <a className="micro" style={{ display: 'flex', alignItems: 'center', gap: 4 }} href="#">
              <Icon name="arrow-left" size={12} /> All proposals
            </a>
            <span className="micro">/</span>
            <span className="micro" style={{ fontFamily: 'ui-monospace, monospace' }}>RP-9842</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 10 }}>
            <div>
              <h2 className="display">Recalibration proposal · RP-9842</h2>
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                <span className="chip chip-spot">PENDING REVIEW</span>
                <span className="chip" style={{ fontFamily: 'ui-monospace, monospace' }}>cyber / signal_weights</span>
                <span className="chip">Drift-triggered (DA-879)</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn ghost"><Icon name="play-circle" size={13} /> Simulate</button>
              <button className="btn ghost"><Icon name="x-circle" size={13} /> Reject</button>
              <button className="btn"><Icon name="check-circle-2" size={13} /> Approve</button>
            </div>
          </div>
        </div>

        {/* scope + review */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Scope</div>
            <div style={{ display: 'flex', flexDirection: 'column', marginTop: 12 }}>
              {[
                ['Coverage', 'cyber'],
                ['Config',   'signal_weights'],
                ['Trigger',  'Drift alert DA-879 — distribution drift'],
                ['Proposer', 'world_engine_v8.2 (auto)'],
                ['Sample',   '1,820 assessments · last 90 days'],
                ['Proposed', '2026-05-27 08:14 UTC'],
              ].map(([k, v], i, arr) => (
                <div key={k} style={{
                  display: 'grid', gridTemplateColumns: '120px 1fr',
                  gap: 12, padding: '8px 0',
                  borderBottom: i < arr.length - 1 ? '1px solid var(--rule)' : 0,
                }}>
                  <span className="micro">{k}</span>
                  <span style={{ fontSize: 13, fontWeight: 500, fontFamily: ['Coverage', 'Config', 'Proposer'].includes(k) ? 'ui-monospace, monospace' : 'inherit' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card-spot" style={{ padding: 22 }}>
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Reviewer rationale</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 12px' }}>Required for approval or rejection</h3>
            <div style={{
              padding: '12px 14px', minHeight: 96, fontSize: 13.5, lineHeight: 1.55,
              background: 'var(--surface)', border: '1px solid var(--rule-strong)',
              borderRadius: 8, color: 'var(--ink-mute)',
            }}>
              Document why this proposal should (or shouldn't) deploy — drift evidence, sample adequacy, downstream impact, anything reviewers should know…
            </div>
            <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
              <button className="btn spot"><Icon name="check-circle-2" size={13} /> Approve with rationale</button>
            </div>
          </div>
        </div>

        {/* weight changes */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <Icon name="sliders-horizontal" size={16} />
            <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Weight changes</h3>
            <span className="chip">{weights.length}</span>
          </div>
          <AdminTable
            cols="1.4fr 100px 100px 110px 2.4fr"
            headers={['Signal', 'From', 'To', 'Δ', 'Rationale']}
            rows={weights.map((w) => {
              const d = w.proposed - w.current;
              const up = d > 0;
              return [
                <code style={{ fontSize: 12 }}>{w.signal}</code>,
                <span style={{ fontVariantNumeric: 'tabular-nums' }}>{w.current.toFixed(3)}</span>,
                <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700, color: 'var(--info)' }}>{w.proposed.toFixed(3)}</span>,
                <span style={{
                  fontVariantNumeric: 'tabular-nums', fontWeight: 600,
                  color: up ? 'var(--pos)' : 'var(--warn)',
                  display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  <Icon name={up ? 'arrow-up' : 'arrow-down'} size={11} />
                  {up ? '+' : ''}{d.toFixed(3)}
                </span>,
                <span className="caption" style={{ fontSize: 12.5, lineHeight: 1.4 }}>{w.why}</span>,
              ];
            })}
          />
        </div>

        {/* tier changes */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <Icon name="layers" size={16} />
            <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Tier threshold changes</h3>
            <span className="chip">{tiers.length}</span>
          </div>
          <AdminTable
            cols="1fr 1fr 1fr 1fr 1fr"
            headers={['Band', 'Boundary', 'From', 'To', 'Δ']}
            rows={tiers.map((t) => {
              const d = t.proposed - t.current;
              return [
                <code style={{ fontSize: 12, fontWeight: 700 }}>{t.band}</code>,
                <span style={{ textTransform: 'capitalize' }}>{t.boundary}</span>,
                <span style={{ fontVariantNumeric: 'tabular-nums' }}>{t.current}</span>,
                <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700, color: 'var(--info)' }}>{t.proposed}</span>,
                <span style={{
                  fontVariantNumeric: 'tabular-nums', fontWeight: 600,
                  color: d < 0 ? 'var(--warn)' : 'var(--pos)',
                }}>{d > 0 ? '+' : ''}{d}</span>,
              ];
            })}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimAdminRecalibration, ReimAdminRecalDetail });
