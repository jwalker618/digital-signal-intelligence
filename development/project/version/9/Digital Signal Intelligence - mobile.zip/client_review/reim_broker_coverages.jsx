/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK */

/* ============================================================
 * 03. Coverages (broker view) — book-wide policy table
 *
 * Differs from the client coverages view in scope:
 *   - all clients' policies, not just one
 *   - grouped by coverage LINE so the broker sees their book shape
 *   - filter pills for line, status, carrier
 * ============================================================ */

function ReimBrokerCoverages({ isDark }) {
  const groups = {};
  for (const p of BROKER_BOOK) {
    const key = p.line;
    if (!groups[key]) groups[key] = [];
    groups[key].push(p);
  }
  // Sort groups by total premium desc
  const groupArr = Object.entries(groups)
    .map(([line, ps]) => ({
      line, policies: ps,
      total: ps.reduce((s, p) => s + p.premium, 0),
    }))
    .sort((a, b) => b.total - a.total);

  const totalPolicies = BROKER_BOOK.length;
  const totalLines    = Object.keys(groups).length;
  const totalPremium  = BROKER_BOOK.reduce((s, p) => s + p.premium, 0);
  const inReview      = BROKER_BOOK.filter(p => p.status === 'In review' || p.status === 'Awaiting').length;

  return (
    <FrameReimag menu="Coverages" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Coverages</div>
            <h2 className="display" style={{ marginTop: 6 }}>Your book, grouped by line</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Every active policy across your client roster, organised by coverage line and ranked by premium share.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 28 }}>
            <KpiSnug label="Policies"        value={totalPolicies} />
            <KpiSnug label="Lines"           value={totalLines} />
            <KpiSnug label="Annual premium"  value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} />
            <KpiSnug label="In review"       value={inReview} tone="spot" />
          </div>
        </div>

        {/* filters */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="micro" style={{ marginRight: 4 }}>Group by:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>Line</span>
          <span className="chip">Client</span>
          <span className="chip">Carrier</span>
          <span style={{ width: 16 }} />
          <span className="micro" style={{ marginRight: 4 }}>Status:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
          <span className="chip">Bound</span>
          <span className="chip">In review</span>
          <span className="chip">Awaiting</span>
        </div>

        {/* per-line cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {groupArr.map((g) => (
            <div key={g.line} className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '14px 20px',
                background: 'var(--surface-elev)',
                borderBottom: '1px solid var(--rule)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8,
                    background: 'var(--surface)', border: '1px solid var(--rule)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Icon name="shield-check" size={16} />
                  </div>
                  <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>{g.line}</h3>
                  <span className="chip">{g.policies.length} polic{g.policies.length === 1 ? 'y' : 'ies'}</span>
                </div>
                <span className="num-sm" style={{ fontSize: 15, fontVariantNumeric: 'tabular-nums' }}>
                  ${(g.total / 1000).toFixed(0)}k
                </span>
              </div>
              {g.policies.map((p, i) => (
                <div key={p.code} style={{
                  display: 'grid',
                  gridTemplateColumns: '2fr 1.4fr 70px 90px 110px 130px 28px',
                  gap: 12, alignItems: 'center',
                  padding: '12px 20px',
                  borderTop: i === 0 ? 0 : '1px solid var(--rule)',
                  fontSize: 13,
                }}>
                  <div>
                    <div style={{ fontWeight: 600 }}>{p.entity}</div>
                    <div className="micro">{p.vertical}</div>
                  </div>
                  <span className="caption">{p.carrier}</span>
                  <div>
                    <div className="micro">Score</div>
                    <span className="info" style={{ fontWeight: 700 }}>{p.score}</span>
                  </div>
                  <div>
                    <div className="micro">Tier</div>
                    <span style={{ fontWeight: 600 }}>Tier {p.tier}</span>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="micro">Premium</div>
                    <span style={{ fontWeight: 600 }}>${(p.premium / 1000).toFixed(0)}k</span>
                  </div>
                  <span className={`chip chip-${p.statusTone}`} style={{ justifySelf: 'flex-start' }}>{p.status}</span>
                  <Icon name="chevron-right" size={16} color="var(--ink-mute)" />
                </div>
              ))}
            </div>
          ))}
        </div>

      </div>
    </FrameReimag>
  );
}

/* Thin wrapper over the shared <Kpi> primitive. */
function KpiSnug(props) {
  return <Kpi {...props} />;
}

Object.assign(window, { ReimBrokerCoverages, KpiSnug });
