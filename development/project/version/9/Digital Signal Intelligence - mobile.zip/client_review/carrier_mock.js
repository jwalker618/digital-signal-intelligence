/* global */

/* ============================================================
 * Carrier portal mock data — inbound submissions awaiting underwriting
 * decision, plus World Engine state (drift alerts, relationships,
 * emerging scenarios).
 * ============================================================ */

const CARRIER_ORG = {
  name: 'Hartford Mutual',
  shortName: 'Hartford Mutual',
};

/** Inbound submissions from brokers — the carrier's queue. */
const CARRIER_SUBMISSIONS = [
  { code: 'SUB-26-0118', entity: 'Eastward Robotics',   broker: 'Marsh',   line: 'Cyber',       score: 724, tier: 2, decision: 'refer',    premium: 185200, status: 'In review',     statusTone: 'spot', received: '2h',   industry: 'Industrial Robotics' },
  { code: 'SUB-26-0144', entity: 'Lumina Software',     broker: 'Aon',     line: 'Cyber',       score: 742, tier: 2, decision: 'approve',  premium:  98000, status: 'Ready to quote',statusTone: 'pos',  received: '4h',   industry: 'Software'         },
  { code: 'SUB-26-0145', entity: 'KestrelView Drones',  broker: 'WTW',     line: 'PI',          score: 631, tier: 4, decision: 'refer',    premium:  72000, status: 'Awaiting docs', statusTone: 'spot', received: '8h',   industry: 'Aerospace'        },
  { code: 'SUB-26-0146', entity: 'Orca Marine Logistics', broker: 'Marsh', line: 'Marine',      score: 605, tier: 4, decision: 'refer',    premium: 410000, status: 'In review',     statusTone: 'spot', received: '12h',  industry: 'Transportation'   },
  { code: 'SUB-26-0147', entity: 'Cinder + Bloom',      broker: 'Lockton', line: 'Property',    score: 698, tier: 3, decision: 'approve',  premium:  68000, status: 'Bound',         statusTone: 'pos',  received: '1d',   industry: 'Hospitality'      },
  { code: 'SUB-26-0148', entity: 'TerraWind Energy',    broker: 'Marsh',   line: 'Property',    score: 681, tier: 3, decision: 'refer',    premium: 412000, status: 'In review',     statusTone: 'spot', received: '1d',   industry: 'Energy'           },
  { code: 'SUB-26-0149', entity: 'BrightLeaf Pharma',   broker: 'Marsh',   line: 'Product Liab.', score: 668, tier: 4, decision: 'refer',  premium: 296000, status: 'Awaiting docs', statusTone: 'spot', received: '2d',   industry: 'Pharmaceuticals'  },
  { code: 'SUB-26-0150', entity: 'NorthStar Logistics', broker: 'Aon',     line: 'GL',          score: 712, tier: 3, decision: 'approve',  premium: 134000, status: 'Bound',         statusTone: 'pos',  received: '2d',   industry: 'Transportation'   },
  { code: 'SUB-26-0151', entity: 'AscendCare Health',   broker: 'Marsh',   line: 'MedProf',     score: 712, tier: 3, decision: 'approve',  premium: 248000, status: 'Quoted',        statusTone: 'pos',  received: '3d',   industry: 'Healthcare'       },
  { code: 'SUB-26-0152', entity: 'Vector Manufacturing',broker: 'WTW',     line: 'Workers Comp', score: 588, tier: 5, decision: 'decline', premium:  85000, status: 'Declined',      statusTone: 'neg',  received: '3d',   industry: 'Manufacturing'    },
  { code: 'SUB-26-0153', entity: 'Hemlock Biosciences', broker: 'Lockton', line: 'D&O',         score: 728, tier: 2, decision: 'approve',  premium: 142000, status: 'Bound',         statusTone: 'pos',  received: '4d',   industry: 'Biotech'          },
  { code: 'SUB-26-0154', entity: 'Aurora Energy',       broker: 'Aon',     line: 'Property',    score: 654, tier: 4, decision: 'refer',    premium: 380000, status: 'Awaiting docs', statusTone: 'spot', received: '5d',   industry: 'Energy'           },
];

/** World Engine — open drift alerts. */
const WE_ALERTS = [
  { id: 'DA-882', signal: 'cyber.mfa_coverage', severity: 'high',   type: 'distribution drift', detected: '6h',  description: 'AAL2 enforcement rates dropping across Industrial cohort — possible economic pressure.' },
  { id: 'DA-879', signal: 'energy.flood_zone', severity: 'medium', type: 'correlation drift',  detected: '1d',  description: 'Flood-zone exposure now correlates with hurricane-Wendell modelling — investigate.' },
  { id: 'DA-871', signal: 'pharma.recall_history', severity: 'medium', type: 'population shift',  detected: '2d', description: 'Mid-sized pharma recall events trending up; reserve assumption may need refresh.' },
  { id: 'DA-867', signal: 'logistics.cyber_posture', severity: 'low', type: 'new relationship', detected: '4d',  description: 'TMS-coverage correlation with cyber score strengthening — promote to active?' },
];

/** Discovered relationships between signals. */
const WE_RELATIONSHIPS = [
  { id: 'R-1042', source: 'cyber.mfa_coverage', target: 'cyber.loss_propensity',   direction: 'positive lift', rho: -0.62, influence: 0.34, population: 1820, lifecycle: 'active',    discovered: '2025-04-12' },
  { id: 'R-1037', source: 'property.cope_score', target: 'property.severity_band', direction: 'positive lift', rho:  0.54, influence: 0.41, population:  920, lifecycle: 'active',    discovered: '2025-03-21' },
  { id: 'R-1029', source: 'pharma.recall_history', target: 'pharma.product_severity', direction: 'positive lift', rho: 0.71, influence: 0.46, population: 540, lifecycle: 'active', discovered: '2025-02-14' },
  { id: 'R-1024', source: 'energy.flood_zone', target: 'property.catastrophe_severity', direction: 'positive lift', rho: 0.39, influence: 0.22, population: 380, lifecycle: 'provisional', discovered: '2026-01-08' },
  { id: 'R-1019', source: 'logistics.tms_integration', target: 'cyber.score', direction: 'positive lift', rho: 0.33, influence: 0.17, population: 280, lifecycle: 'candidate',    discovered: '2026-02-20' },
];

/** Emerging scenarios the world model is monitoring. */
const WE_SCENARIOS = [
  { id: 'ES-014', name: 'Ransomware wave hits energy operators', likelihood: 0.34, likelihoodLabel: 'Elevated', scope: 'energy', magnitude: 18, horizon: '6 mo', source: 'Industry chatter + Q1 events' },
  { id: 'ES-015', name: 'Hurricane Wendell — secondary impact', likelihood: 0.62, likelihoodLabel: 'High',     scope: 'property',    magnitude: 32, horizon: '3 mo', source: 'CAT model rerun' },
  { id: 'ES-016', name: 'Pharma supply-chain disruption',         likelihood: 0.41, likelihoodLabel: 'Elevated', scope: 'pharma',    magnitude: 22, horizon: '9 mo', source: 'Supply chain risk model' },
  { id: 'ES-017', name: 'AI liability claims uptick',             likelihood: 0.28, likelihoodLabel: 'Moderate', scope: 'pi',        magnitude: 15, horizon: '12 mo', source: 'Litigation trend analysis' },
];

const WE_MATURITY = {
  stage: 'Mature',
  assessedEntities: 8420,
  timeDepthMonths: 24.6,
  activeRelationships: 142,
  provisional: 38,
  candidate: 21,
  entitiesWithTemporalData: 5612,
};

Object.assign(window, {
  CARRIER_ORG, CARRIER_SUBMISSIONS, WE_ALERTS, WE_RELATIONSHIPS,
  WE_SCENARIOS, WE_MATURITY,
});
