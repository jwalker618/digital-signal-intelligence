/* global React, FrameReimag, Icon, ScoreHistory, CohortBar, PremiumBreakdown, Sparkline,
   useCoverage, PageHead, StandingStrip, OppByLineBar, StatusChip,
   CLIENT_LINES, CLIENT_PORTFOLIO, lineByKey, kMoney */

/* ============================================================
 * Overview — portfolio-first summary with a live coverage switcher.
 *
 *   All   → portfolio roll-up: blended signal, premium split, the
 *           per-line standing strip, and where the upside sits.
 *   line  → that coverage's full summary (score history, signal
 *           pulse, cohort standing, loss, exposure, policy terms).
 * ============================================================ */

const ENT = 'Eastward Robotics';

/* per-line "awaiting you" items — drawn from each carrier's open asks. */
function lineAwaiting(key) {
  if (key === 'cyber') return [
    { line: 'Cyber referral', age: '2 hours ago', ask: 'Hartford Mutual needs MFA attestation for the cyber bind' },
    { line: 'Cyber referral', age: '1 day ago', ask: 'Provide latest SOC 2 Type II report or equivalent audit' },
  ];
  if (key === 'do') return [
    { line: 'D&O bind', age: '4 hours ago', ask: 'Chubb requests completed, ratified board minutes (trailing 8 quarters)' },
    { line: 'D&O bind', age: '2 days ago', ask: 'Confirm related-party disclosure schedule before terms are released' },
  ];
  return []; // PI is preferred / clean — nothing awaiting
}

function ReimOverview({ isDark }) {
  const [cov, setCov] = useCoverage('all');
  const line = cov === 'all' ? null : lineByKey(cov);
  const title = cov === 'all' ? 'Your portfolio at a glance' : `${line.line} summary`;
  const sub = cov === 'all'
    ? 'A blended read across every active line. Pick a coverage to drill into its own score, loss outlook and cohort.'
    : line.cohortLabel;

  return (
    <FrameReimag menu="Overview" entity={ENT} isDark={isDark}>
      <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 18, height: '100%', alignContent: 'start' }}>
        <PageHead eyebrow="Overview" title={title} sub={sub} active={cov} onChange={setCov} />
        {cov === 'all'
          ? <PortfolioSummary onPick={setCov} />
          : <LineSummary line={line} />}
      </div>
    </FrameReimag>
  );
}

/* ════════════════════════════ PORTFOLIO (All) ════════════════════════════ */
function PortfolioSummary({ onPick }) {
  const P = CLIENT_PORTFOLIO;
  const vsPrev = P.delta;
  return (
    <React.Fragment>
      {/* ROW 1 — blended signal + premium + awaiting */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 1fr 1.1fr', gap: 16 }}>
        {/* blended signal */}
        <div className="card-info" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
          <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Portfolio signal · premium-weighted</div>
          <div style={{ display: 'flex', gap: 20, marginTop: 10, alignItems: 'flex-start' }}>
            <div className="num-xl" style={{ color: 'var(--info-deep)', lineHeight: 1 }}>{P.score}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 4 }}>
              <span className={`chip chip-${vsPrev >= 0 ? 'pos' : 'neg'}`} style={{ alignSelf: 'flex-start' }}>
                <Icon name={vsPrev >= 0 ? 'trending-up' : 'trending-down'} size={11} /> {vsPrev >= 0 ? '+' : ''}{vsPrev} since last quote
              </span>
              <span className="chip" style={{ alignSelf: 'flex-start' }}>
                <Icon name="layers" size={12} /> {P.lineCount} active lines
              </span>
            </div>
          </div>
          <div style={{ flex: 1, marginTop: 14, minHeight: 96 }}>
            <ScoreHistory history={P.scoreHist} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
            <span className="chip chip-pos"><Icon name="arrow-up" size={12} /> {P.bestLine.short} strongest · {P.bestLine.score}</span>
            <span className="chip chip-warn"><Icon name="arrow-down" size={12} /> {P.weakLine.short} weakest · {P.weakLine.score}</span>
          </div>
        </div>

        {/* premium split */}
        <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
          <div className="eyebrow">Annual premium</div>
          <div className="num-xl" style={{ marginTop: 10, lineHeight: 1 }}>${P.totalPremium.toLocaleString()}</div>
          <div className="caption" style={{ marginTop: 4 }}>Across {P.lineCount} active lines</div>
          <div style={{ marginTop: 'auto' }}>
            <PremiumBreakdown policies={P.premiumPolicies} />
          </div>
        </div>

        {/* awaiting across the book */}
        <AwaitingCard
          items={[
            { line: 'D&O bind', age: '4 hours ago', ask: 'Chubb requests completed, ratified board minutes for the D&O bind' },
            { line: 'Cyber referral', age: '2 hours ago', ask: 'Hartford needs MFA attestation to finish the cyber bind' },
          ]}
        />
      </div>

      {/* ROW 2 — per-line standing strip */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: 0 }}>Standing by coverage</h3>
          <span className="micro">click any line to drill in</span>
        </div>
        <StandingStrip onPick={onPick} />
      </div>

      {/* ROW 3 — where the upside is + book facts */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 16 }}>
            <div>
              <div className="eyebrow">Where the upside is</div>
              <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Premium opportunity by line</h3>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="micro">total identified</div>
              <div className="num spot">−{kMoney(P.totalOpp)}</div>
            </div>
          </div>
          <OppByLineBar data={P.oppByLine} />
          <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--rule)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="lightbulb" size={16} color="var(--spot)" />
            <span className="caption" style={{ flex: 1 }}>
              {P.weakLine.short} carries the largest single opportunity — it’s also your weakest line. Start there.
            </span>
            <button className="btn spot" onClick={() => onPick(P.weakLine.key)}>Open {P.weakLine.short} →</button>
          </div>
        </div>

        {/* book facts */}
        <div className="card-aux" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 0 }}>
          <div className="eyebrow" style={{ color: 'var(--aux)' }}>Book at a glance</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 14 }}>
            <BookFact label="Aggregate exposure" value={P.aggExposure} sub="across 3 lines" />
            <BookFact label="Blended loss outlook" value={P.lossBand} sub="D&O elevated" tone="warn" />
            <BookFact label="Low-effort wins" value={String(P.lowEffortWins)} sub="quick credits" tone="pos" />
            <BookFact label="Open actions" value={String(P.totalActions)} sub="across the book" />
          </div>
          <div style={{ marginTop: 'auto', paddingTop: 16 }}>
            <button className="btn ghost" style={{ width: '100%' }} onClick={() => onPick('cyber')}>
              Browse a coverage <Icon name="arrow-right" size={14} />
            </button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

function BookFact({ label, value, sub, tone }) {
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num-sm" style={{ fontSize: 24, marginTop: 2, color: tone ? `var(--${tone})` : 'var(--ink)' }}>{value}</div>
      <div className="micro" style={{ marginTop: 2 }}>{sub}</div>
    </div>
  );
}

/* ════════════════════════════ SINGLE LINE ════════════════════════════ */
function LineSummary({ line }) {
  const vsMedian = line.score - line.median;
  const vsPrev = line.score - line.prev;
  const aboveMedian = line.score >= line.median;
  const scoreColor = aboveMedian ? 'var(--info-deep)' : 'var(--warn)';
  const awaiting = lineAwaiting(line.key);
  const helpTotal = line.helping.reduce((s, h) => s + h[1], 0);
  const oppTotal = line.opportunity.reduce((s, o) => s + o[1], 0);
  const helpMax = Math.max(...line.helping.map((h) => h[1]));
  const oppMax = Math.max(...line.opportunity.map((o) => o[1]));

  return (
    <React.Fragment>
      {/* ROW 1 — score / premium+terms / awaiting */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 1fr 1.1fr', gap: 16 }}>
        {/* score */}
        <div className="card-info" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
          <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>{line.short} signal score</div>
          <div style={{ display: 'flex', gap: 20, marginTop: 10, alignItems: 'flex-start' }}>
            <div className="num-xl" style={{ color: scoreColor, lineHeight: 1 }}>{line.score}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 4 }}>
              <span className={`chip chip-${aboveMedian ? 'pos' : 'neg'}`} style={{ alignSelf: 'flex-start' }}>
                <Icon name={aboveMedian ? 'arrow-up' : 'arrow-down'} size={11} /> {vsMedian >= 0 ? '+' : ''}{vsMedian} vs median
              </span>
              <span className={`chip chip-${vsPrev >= 0 ? 'pos' : 'neg'}`} style={{ alignSelf: 'flex-start' }}>
                <Icon name={vsPrev >= 0 ? 'trending-up' : 'trending-down'} size={11} /> {vsPrev >= 0 ? '+' : ''}{vsPrev} since last quote
              </span>
            </div>
          </div>
          <div style={{ flex: 1, marginTop: 14, minHeight: 96 }}>
            <ScoreHistory history={line.scoreHist} color={scoreColor} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
            <span className="chip chip-info"><Icon name="trending-up" size={12} /> {line.percentile}th percentile</span>
            <StatusChip tone={line.statusTone}>{line.status}</StatusChip>
          </div>
        </div>

        {/* premium + terms */}
        <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
          <div className="eyebrow">Annual premium</div>
          <div className="num-xl" style={{ marginTop: 10, lineHeight: 1 }}>${line.premium.toLocaleString()}</div>
          <div className="caption" style={{ marginTop: 4 }}>{line.carrier}</div>
          <div style={{ marginTop: 'auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, paddingTop: 16 }}>
            <TermFact label="Limit / Aggregate" value={line.limit} />
            <TermFact label="Retention" value={line.retention} />
            <TermFact label="Renews" value={line.expires.slice(5).replace('-', '/') + '/' + line.expires.slice(0, 4).slice(2)} />
            <TermFact label="Status" value={line.status} tone={line.statusTone} />
          </div>
        </div>

        {/* awaiting (or on-track) */}
        {awaiting.length > 0
          ? <AwaitingCard items={awaiting} />
          : (
            <div className="card-pos" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 12 }}>
              <span className="eyebrow" style={{ color: 'var(--pos)' }}>Nothing awaiting you</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--pos-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name="check" size={22} color="var(--pos)" />
                </div>
                <div style={{ font: '600 16px/1.3 IBM Plex Sans' }}>This line is preferred and fully placed</div>
              </div>
              <div className="caption" style={{ marginTop: 'auto' }}>
                {line.carrier} has you at preferred terms. Renews {line.expires}. No open requests.
              </div>
              <button className="btn ghost">View policy</button>
            </div>
          )}
      </div>

      {/* ROW 2 — signal pulse + cohort standing */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow">Signal pulse</div>
              <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: '6px 0 0' }}>What's moving your premium</h3>
            </div>
            <span className="micro">{line.line.toLowerCase()}</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <PulseColumn
              heading="Helping" headingChip="chip chip-pos" headingIcon="arrow-down"
              deltaLabel={`−${kMoney(helpTotal)}`} deltaClass="pos" accent="var(--pos)"
              rows={line.helping.map((h) => [h[0], h[1], helpMax])} sign="−"
            />
            {line.opportunity.length > 0 ? (
              <PulseColumn
                heading="Opportunity" headingChip="chip chip-spot" headingIcon="lightbulb"
                deltaLabel={`+${kMoney(oppTotal)}`} deltaClass="spot" accent="var(--spot)"
                rows={line.opportunity.map((o) => [o[0], o[1], oppMax])} sign="+"
              />
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', color: 'var(--ink-mute)', gap: 6 }}>
                <Icon name="badge-check" size={28} color="var(--pos)" />
                <div className="caption">No open opportunities — this line is already optimised.</div>
              </div>
            )}
          </div>
        </div>

        {/* cohort standing */}
        <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div>
              <div className="eyebrow">Cohort standing</div>
              <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                <span className={aboveMedian ? 'pos' : 'warn'}>{line.percentile}th percentile</span>
              </h3>
            </div>
            <span className="micro">{line.peers} peers</span>
          </div>
          <div style={{ marginTop: 18, flex: 1, display: 'flex', alignItems: 'center' }}>
            <CohortBar value={line.score} median={line.median} topDecile={line.topDecile} range={line.range} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
            <div>
              <div className="micro">vs median</div>
              <div className={`num-sm ${vsMedian >= 0 ? 'pos' : 'warn'}`}>{vsMedian >= 0 ? '+' : ''}{vsMedian}</div>
            </div>
            <div>
              <div className="micro">your score</div>
              <div className="num-sm info">{line.score}</div>
            </div>
            <div>
              <div className="micro">to top decile</div>
              <div className="num-sm">{Math.max(0, line.topDecile - line.score)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ROW 3 — loss / exposure / coverage shape */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        <LossOutlookCard
          band={line.loss.band} trend={line.loss.trend}
          quarters={line.loss.quarters} quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
          frequency={line.loss.frequency} severity={line.loss.severity}
        />
        <ExposureCard value={line.exposure.value} yoy={line.exposure.yoy} band={line.exposure.band} sub={line.exposure.sub} />
        <CoverageShapeCard
          held={CLIENT_LINES.map((l) => l.short)}
          activeShort={line.short}
          gaps={[
            { line: 'Property', peerPct: 78 },
            { line: 'GL', peerPct: 65 },
            { line: 'Crime', peerPct: 42 },
          ]}
        />
      </div>
    </React.Fragment>
  );
}

function TermFact({ label, value, tone }) {
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num-sm" style={{ fontSize: 14, marginTop: 2, color: tone ? `var(--${tone})` : 'var(--ink)' }}>{value}</div>
    </div>
  );
}

/* ============================================================
 * Awaiting card — coral spotlight with pager + next-up peek
 * ============================================================ */
function AwaitingCard({ items }) {
  const [idx, setIdx] = React.useState(0);
  const safeIdx = Math.min(idx, items.length - 1);
  const item = items[safeIdx];
  const next = items[(safeIdx + 1) % items.length];
  const canBack = safeIdx > 0;
  const canFwd = safeIdx < items.length - 1;
  return (
    <div className="card-spot" style={{ display: 'flex', flexDirection: 'column', padding: 22, gap: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className="eyebrow" style={{ color: 'var(--spot)' }}>Awaiting you</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <button aria-label="Previous query" onClick={() => canBack && setIdx(safeIdx - 1)} disabled={!canBack} style={pagerBtn(canBack)}><Icon name="chevron-left" size={14} /></button>
          <span className="chip chip-spot" style={{ minWidth: 50, justifyContent: 'center' }}>{safeIdx + 1} of {items.length}</span>
          <button aria-label="Next query" onClick={() => canFwd && setIdx(safeIdx + 1)} disabled={!canFwd} style={pagerBtn(canFwd)}><Icon name="chevron-right" size={14} /></button>
        </div>
      </div>
      <div>
        <div style={{ font: '600 16px/1.25 IBM Plex Sans', color: 'var(--ink)' }}>{item.ask}</div>
        <div className="caption" style={{ marginTop: 4 }}>{item.age} · {item.line}</div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
        <button className="btn spot">Open thread</button>
        <button className="btn ghost">Snooze</button>
      </div>
      {items.length > 1 && (
        <div style={{ paddingTop: 10, marginTop: 4, borderTop: '1px dashed var(--spot)', display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--spot-deep)', cursor: 'pointer' }} onClick={() => setIdx((safeIdx + 1) % items.length)}>
          <span style={{ opacity: 0.7 }}>Next →</span>
          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>{next.ask}</span>
        </div>
      )}
    </div>
  );
}
function pagerBtn(enabled) {
  return {
    width: 22, height: 22, borderRadius: 6, background: 'transparent',
    border: '1px solid var(--spot)', color: 'var(--spot)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    cursor: enabled ? 'pointer' : 'not-allowed', opacity: enabled ? 1 : 0.3, padding: 0,
  };
}

/* ============================================================
 * LossOutlookCard — 36-month claims strip + freq/sev vs cohort
 * ============================================================ */
function LossOutlookCard({ band, trend, quarters, quarterLabels, frequency, severity }) {
  const worsening = /wors/i.test(trend);
  const accent = band === 'Elevated' || worsening ? 'var(--neg)' : 'var(--pos)';
  const cardClass = band === 'Elevated' || worsening ? 'card-spot' : 'card-pos';
  return (
    <div className={cardClass} style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow" style={{ color: accent }}>Loss outlook</div>
          <div className="num-sm" style={{ fontSize: 20, color: accent, marginTop: 4 }}>{band}</div>
        </div>
        <span className={`chip chip-${worsening ? 'neg' : 'pos'}`}>
          <Icon name={worsening ? 'trending-up' : 'trending-down'} size={11} /> {trend}
        </span>
      </div>
      <div>
        <div className="micro" style={{ marginBottom: 4 }}>Claims, last 12 quarters</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 3 }}>
          {quarters.map((v, i) => (
            <div key={i} title={v > 0 ? 'claim' : 'no claim'} style={{
              height: 14, borderRadius: 2,
              background: v > 0 ? `color-mix(in srgb, var(--neg) ${30 + v * 70}%, transparent)` : 'var(--surface)',
              border: `1px solid ${v > 0 ? 'var(--neg)' : 'var(--rule)'}`,
            }} />
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
          {quarterLabels.map((l) => <span key={l} className="micro">{l}</span>)}
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 'auto' }}>
        <CompareBar label="Frequency" value={frequency.value} cohort={frequency.cohort} max={100} />
        <CompareBar label="Severity" value={severity.value} cohort={severity.cohort} max={100} />
      </div>
    </div>
  );
}
function CompareBar({ label, value, cohort, max }) {
  const better = value < cohort;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span className="micro">{label}</span>
        <span className="micro">vs {cohort}</span>
      </div>
      <div style={{ position: 'relative', height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4 }}>
        <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: `${(value / max) * 100}%`, background: better ? 'var(--pos)' : 'var(--neg)', borderRadius: 2 }} />
        <div style={{ position: 'absolute', top: -3, height: 10, width: 2, background: 'var(--ink-soft)', left: `${(cohort / max) * 100}%` }} />
      </div>
      <div style={{ marginTop: 4, fontSize: 12, fontWeight: 600, color: better ? 'var(--pos)' : 'var(--neg)' }}>{value}</div>
    </div>
  );
}

/* ============================================================
 * ExposureCard — position on cohort size scale + YoY
 * ============================================================ */
function ExposureCard({ value, yoy, band, sub }) {
  const positions = { small: 0.18, mid: 0.55, large: 0.85 };
  const pinPct = positions[band] * 100;
  return (
    <div className="card-aux" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow" style={{ color: 'var(--aux)' }}>Exposure</div>
          <div className="num-sm" style={{ fontSize: 20, color: 'var(--aux)', marginTop: 4 }}>{value}</div>
        </div>
        <span className="chip chip-pos"><Icon name="trending-up" size={11} /> {yoy} YoY</span>
      </div>
      <div style={{ marginTop: 4 }}>
        <div className="micro" style={{ marginBottom: 4 }}>Where you sit in market scale</div>
        <div style={{ position: 'relative', height: 28 }}>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 12, height: 6, background: 'linear-gradient(to right, var(--surface) 0%, var(--aux-soft) 50%, var(--aux) 100%)', borderRadius: 3, border: '1px solid var(--rule-strong)' }} />
          <div style={{ position: 'absolute', left: 0, top: 22, fontSize: 9.5 }} className="micro">Small</div>
          <div style={{ position: 'absolute', left: '50%', top: 22, transform: 'translateX(-50%)', fontSize: 9.5 }} className="micro">Mid-market</div>
          <div style={{ position: 'absolute', right: 0, top: 22, fontSize: 9.5 }} className="micro">Large</div>
          <div style={{ position: 'absolute', left: `${pinPct}%`, top: 0, transform: 'translateX(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <span style={{ background: 'var(--aux)', color: '#fff', fontSize: 10, fontWeight: 600, padding: '2px 6px', borderRadius: 4 }}>YOU</span>
            <div style={{ width: 2, height: 12, background: 'var(--aux)' }} />
          </div>
        </div>
      </div>
      <div className="caption" style={{ marginTop: 'auto' }}>{sub}</div>
    </div>
  );
}

/* ============================================================
 * CoverageShapeCard — held lines (active highlighted) + peer gaps
 * ============================================================ */
function CoverageShapeCard({ held, gaps, activeShort }) {
  const total = held.length + gaps.length;
  return (
    <div className="card" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div className="eyebrow">Coverage shape</div>
          <div className="num-sm" style={{ fontSize: 20, marginTop: 4 }}>{held.length} of {total} typical lines</div>
        </div>
        <span className="chip chip-spot">{gaps.length} typical adds</span>
      </div>
      <div>
        <div className="micro" style={{ marginBottom: 6 }}>Held</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {held.map((l) => (
            <span key={l} className={`chip chip-pos`} style={{ padding: '4px 9px', outline: l === activeShort ? '2px solid var(--info)' : 'none', outlineOffset: 1 }}>
              <Icon name="check" size={11} /> {l}
            </span>
          ))}
        </div>
      </div>
      <div style={{ marginTop: 'auto' }}>
        <div className="micro" style={{ marginBottom: 6 }}>Often added by peers</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {gaps.map((g) => (
            <span key={g.line} className="chip" style={{ padding: '4px 9px', border: '1px dashed var(--rule-strong)', background: 'transparent' }}>
              <Icon name="circle" size={11} /> {g.line}
              <span style={{ opacity: 0.6, marginLeft: 4, fontSize: 10 }}>{g.peerPct}%</span>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── shared pulse column ─────────────────────────────────────── */
function PulseColumn({ heading, headingChip, headingIcon, deltaLabel, deltaClass, accent, rows, sign }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
        <span className={headingChip}><Icon name={headingIcon} size={12} /> {heading}</span>
        <span className={`num-sm ${deltaClass}`}>{deltaLabel}</span>
      </div>
      {rows.map((r, i) => (
        <div key={i} style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, gap: 8, whiteSpace: 'nowrap' }}>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[0]}</span>
            <span className={deltaClass} style={{ fontWeight: 600, flexShrink: 0 }}>{sign}${(r[1] / 1000).toFixed(1)}k</span>
          </div>
          <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
            <div style={{ width: `${(r[1] / r[2]) * 100}%`, height: '100%', background: accent }} />
          </div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { ReimOverview, LossOutlookCard, ExposureCard, CompareBar, AwaitingCard });
