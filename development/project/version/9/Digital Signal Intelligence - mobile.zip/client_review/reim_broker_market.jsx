/* global React, FrameReimag, Icon, BROKER, BROKER_MARKET_LINES, BROKER_LOSS_EVENTS */

/* ============================================================
 * 08. Market Pulse — cycle position by line + climate overlay
 *
 * Layout
 *   row 1 — title + KPIs (cycle overall, hardening/softening count)
 *   row 2 — climate pulse narrative card
 *   row 3 — 7 line dashboards in a 3-col grid
 *   row 4 — recent loss events
 * ============================================================ */

function ReimBrokerMarket({ isDark }) {
  const lines = BROKER_MARKET_LINES;
  const events = BROKER_LOSS_EVENTS;
  const hardening = lines.filter(l => l.cycle === 'Hardening').length;
  const softening = lines.filter(l => l.cycle === 'Softening').length;

  return (
    <FrameReimag menu="Market Pulse" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Market pulse</div>
            <h2 className="display" style={{ marginTop: 6 }}>By-line market intelligence</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              Cycle position, capacity, loss trends, and the climate overlay shaping placement decisions.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 28 }}>
            <KpiSnug label="Cycle overall"  value="Hardening" tone="warn" />
            <KpiSnug label="Hardening"      value={hardening} tone="warn" />
            <KpiSnug label="Softening"      value={softening} tone="pos" />
            <KpiSnug label="Lines watched"  value={lines.length} />
          </div>
        </div>

        {/* climate pulse */}
        <div className="card-pos" style={{ padding: 22, display: 'grid', gridTemplateColumns: '40px 1fr', gap: 18 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10,
            background: 'var(--pos-soft)', color: 'var(--pos)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="leaf" size={22} />
          </div>
          <div>
            <div className="eyebrow" style={{ color: 'var(--pos)' }}>Climate pulse — the active market force</div>
            <p style={{ margin: '8px 0 0', fontSize: 14, lineHeight: 1.55 }}>
              Climate-physical underwriting is now table-stakes across property and marine. Carriers
              with ESG-leader stances (Munich Re, AXA XL, Zurich) are differentiating on parametric
              and bespoke climate cover. Restrictive carriers are exiting fossil-fuel adjacent lines.
              <span className="caption"> For your book, this most affects TerraWind (energy) and the property book.</span>
            </p>
          </div>
        </div>

        {/* by-line dashboards */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
            <h3 style={{ font: '600 17px/1 IBM Plex Sans', margin: 0 }}>By-line dashboards</h3>
            <span className="caption">Click a line for full carrier + loss-event detail</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            {lines.map((l) => <LineCard key={l.slug} line={l} />)}
          </div>
        </div>

        {/* loss events */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <div>
              <div className="eyebrow">Recent loss events</div>
              <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Events shaping market direction</h3>
            </div>
            <span className="caption">Last 12 months</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {events.map((e, i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '90px 1fr auto', gap: 16, alignItems: 'flex-start',
                padding: '12px 14px',
                background: 'var(--surface-elev)',
                border: '1px solid var(--rule)',
                borderRadius: 8,
              }}>
                <div>
                  <span className="chip">{e.line}</span>
                  <div className="micro" style={{ marginTop: 4 }}>{e.date}</div>
                </div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 600 }}>{e.headline}</div>
                  <div className="caption" style={{ marginTop: 4, fontStyle: 'italic', lineHeight: 1.4 }}>{e.implication}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="micro">industry loss</div>
                  <div style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontSize: 16, color: 'var(--neg)' }}>
                    ${e.industryLossB}B
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function LineCard({ line }) {
  const cycleColor = line.cycle === 'Hardening' ? 'var(--warn)'
                   : line.cycle === 'Softening' ? 'var(--pos)'
                   : 'var(--info)';
  const rateColor  = line.rateYoY > 5 ? 'var(--warn)' : line.rateYoY < -3 ? 'var(--pos)' : 'var(--ink-soft)';
  const lossColor  = line.lossTrend.startsWith('Deter') || line.lossTrend.startsWith('Worsen') ? 'var(--neg)'
                   : line.lossTrend.startsWith('Improv') ? 'var(--pos)' : 'var(--ink-soft)';

  return (
    <div className="card" style={{
      padding: 16,
      borderTop: `3px solid ${cycleColor}`,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
        <span style={{ fontSize: 14, fontWeight: 700 }}>{line.name}</span>
        <span className="chip" style={{ color: cycleColor, borderColor: cycleColor }}>{line.cycle}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 10 }}>
        <div>
          <div className="micro">Rate YoY</div>
          <div className="num" style={{ fontSize: 20, color: rateColor, fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>
            {line.rateYoY > 0 ? '+' : ''}{line.rateYoY.toFixed(1)}%
          </div>
        </div>
        <div>
          <div className="micro">Capacity</div>
          <div className="num" style={{ fontSize: 14, marginTop: 2 }}>{line.capacity}</div>
          <div className="micro" style={{ marginTop: 2 }}>{line.capacityTrend}</div>
        </div>
      </div>
      <div style={{ fontSize: 12, marginBottom: 10 }}>
        <span className="micro">Loss trend: </span>
        <span style={{ fontWeight: 600, color: lossColor }}>{line.lossTrend}</span>
      </div>
      <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 10 }}>
        <div className="micro" style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4 }}>
          <Icon name="leaf" size={11} /> ESG overlay
        </div>
        <div className="caption" style={{ fontSize: 11.5, lineHeight: 1.4 }}>{line.esgOverlay}</div>
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerMarket });
