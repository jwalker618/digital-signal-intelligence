/* global React, FrameReimag, Icon, BROKER, BROKER_QUERIES */

/* ============================================================
 * 07. Communications (broker) — queries across the whole book
 *
 * Differs from client comms:
 *   - threads span multiple clients (add Client column)
 *   - awaiting flag can be "on you" or "on client" — broker triages both
 * ============================================================ */

function ReimBrokerComms({ isDark }) {
  const qs = BROKER_QUERIES;
  const onBroker = qs.filter(q => q.awaiting === 'broker').length;
  const onClient = qs.filter(q => q.awaiting === 'client').length;
  const resolved = qs.filter(q => q.awaiting === 'resolved').length;

  return (
    <FrameReimag menu="Communications" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 18, height: '100%', alignContent: 'start' }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Communications</div>
            <h2 className="display" style={{ marginTop: 6 }}>Queries across your client book</h2>
          </div>
          <div style={{ display: 'flex', gap: 28 }}>
            <KpiSnug label="Total open"      value={qs.length - resolved} />
            <KpiSnug label="Awaiting you"    value={onBroker} tone="spot" />
            <KpiSnug label="Awaiting client" value={onClient} tone="info" />
            <KpiSnug label="Resolved (30d)"  value={resolved} tone="pos" />
          </div>
        </div>

        {/* filter pills */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="micro" style={{ marginRight: 4 }}>Awaiting:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All open</span>
          <span className="chip">On me</span>
          <span className="chip">On client</span>
          <span className="chip">Resolved</span>
          <span style={{ width: 16 }} />
          <span className="micro" style={{ marginRight: 4 }}>Line:</span>
          <span className="chip">Cyber</span>
          <span className="chip">Property</span>
          <span className="chip">Casualty</span>
          <span className="chip">D&O</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: most recent</span>
        </div>

        {/* threads */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {qs.map((q, i) => <BrokerThreadRow key={q.refCode} q={q} first={i === 0} />)}
        </div>

      </div>
    </FrameReimag>
  );
}

function BrokerThreadRow({ q, first }) {
  const tone = q.awaiting === 'broker'   ? 'spot'
             : q.awaiting === 'client'   ? 'info'
             : 'pos';
  const accent = tone === 'spot' ? 'var(--spot)' : tone === 'info' ? 'var(--info)' : 'var(--pos)';
  const statusLabel = q.awaiting === 'broker'   ? 'awaiting you'
                    : q.awaiting === 'client'   ? 'awaiting client'
                    :                              'resolved';

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '4px 1.6fr 2.4fr 110px 110px 70px 28px',
      gap: 16, alignItems: 'center',
      padding: '16px 20px 16px 16px',
      borderTop: first ? 0 : '1px solid var(--rule)',
    }}>
      <div style={{
        width: 4, height: 40, borderRadius: 2,
        background: q.awaiting !== 'resolved' ? accent : 'transparent',
      }} />
      <div>
        <div style={{ fontSize: 13.5, fontWeight: 700 }}>{q.entity}</div>
        <div className="micro" style={{ marginTop: 2 }}>{q.carrier} · {q.refCode}</div>
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: 13, color: 'var(--ink)',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>"{q.ask}"</div>
      </div>
      <span className="chip" style={{ alignSelf: 'flex-start' }}>{q.line}</span>
      <span className={`chip chip-${tone}`}>{statusLabel}</span>
      <span className="micro" style={{ textAlign: 'right' }}>{q.age}</span>
      <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
    </div>
  );
}

Object.assign(window, { ReimBrokerComms });
