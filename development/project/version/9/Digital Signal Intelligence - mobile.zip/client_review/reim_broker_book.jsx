/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, BROKER_QUERIES, bookByClient */

/* ============================================================
 * 01. Book of Clients — broker home
 *
 * Layout
 *   row 1 — hero strip: broker identity + book stats (4 KPIs)
 *   row 2 — book roster (filterable table)
 *   row 3 — tier mix bar + open queries snapshot
 * ============================================================ */

function ReimBrokerBook({ isDark }) {
  const policies = BROKER_BOOK;
  const clients  = bookByClient();
  const totalPremium = policies.reduce((s, p) => s + p.premium, 0);
  const avgScore = Math.round(policies.reduce((s, p) => s + p.score, 0) / policies.length);
  const awaitingBroker = BROKER_QUERIES.filter(q => q.awaiting === 'broker').length;
  const awaitingClient = BROKER_QUERIES.filter(q => q.awaiting === 'client').length;
  const tiers = [1, 2, 3, 4, 5].map(t => ({
    t, n: policies.filter(p => p.tier === t).length,
  }));
  const maxTier = Math.max(...tiers.map(b => b.n), 1);

  // Roster search — find a particular entity / line / carrier.
  const [query, setQuery] = React.useState('');
  const q = query.trim().toLowerCase();
  const visible = q
    ? policies.filter(p => [p.entity, p.line, p.carrier, p.code, p.vertical]
        .some(f => String(f || '').toLowerCase().includes(q)))
    : policies;

  // Open-queries filter — this view is the broker's comms hub, so it needs
  // to slice a potentially long queue.
  const [qFilter, setQFilter] = React.useState('open');
  const queryTabs = [
    { key: 'open',   label: 'Open',      n: BROKER_QUERIES.filter(x => x.awaiting !== 'resolved').length },
    { key: 'broker', label: 'On you',    n: awaitingBroker },
    { key: 'client', label: 'On client', n: awaitingClient },
    { key: 'resolved', label: 'Resolved', n: BROKER_QUERIES.filter(x => x.awaiting === 'resolved').length },
  ];
  const queriesShown = BROKER_QUERIES.filter(qq =>
    qFilter === 'open' ? qq.awaiting !== 'resolved' : qq.awaiting === qFilter
  );

  return (
    <FrameReimag menu="Book of Clients" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* row 1 — hero stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 24, display: 'flex', alignItems: 'center', gap: 18 }}>
            <div style={{
              width: 64, height: 64, borderRadius: 12,
              background: 'var(--info-soft)', color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="briefcase" size={32} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">Broker book</div>
              <h2 className="display" style={{ marginTop: 4, lineHeight: 1.1 }}>
                Marsh
                <span style={{ display: 'block', fontSize: 18, fontWeight: 400, color: 'var(--ink-soft)', marginTop: 4 }}>
                  Northeast Specialty
                </span>
              </h2>
              <div className="caption" style={{ marginTop: 8 }}>
                {clients.length} clients · {policies.length} policies in force
              </div>
            </div>
          </div>
          <KpiCard label="Aggregate premium" value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} sub="annual" />
          <KpiCard label="Avg signal score" value={avgScore} sub="across the book" tone="info" />
          <KpiCard label="Awaiting you" value={awaitingBroker} sub={`of ${BROKER_QUERIES.length} open queries`} tone="spot" />
        </div>

        {/* row 2 — roster table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)', gap: 16, flexWrap: 'wrap',
          }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Book roster</h3>
              <span className="chip">{q ? `${visible.length} of ${policies.length}` : `${policies.length} policies`}</span>
            </div>
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
              <label className="pl-search">
                <Icon name="search" size={15} color="var(--ink-mute)" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search client, carrier…"
                />
                {query && (
                  <button type="button" className="pl-search-clear" aria-label="Clear search" onClick={() => setQuery('')}>
                    <Icon name="x" size={13} />
                  </button>
                )}
              </label>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span className="micro" style={{ marginRight: 4 }}>Filter:</span>
                <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
                <span className="chip">Industrial</span>
                <span className="chip">Healthcare</span>
                <span className="chip">Energy</span>
                <span className="chip">Pharma</span>
                <span className="chip">Transport</span>
              </div>
            </div>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '2fr 1.4fr 1fr 80px 70px 95px 110px 120px 28px',
            background: 'var(--surface-sunken)',
            padding: '8px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Client', 'Coverage', 'Carrier', 'Score', 'Tier', 'Percentile', 'Premium', 'Status', ''].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {visible.map((p, i) => (
            <div key={p.code} className="pl-row" title={`Open ${p.entity}`} style={{
              display: 'grid',
              gridTemplateColumns: '2fr 1.4fr 1fr 80px 70px 95px 110px 120px 64px',
              gap: 0, alignItems: 'center',
              padding: '10px 20px',
              borderBottom: i < visible.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13,
            }}>
              <span style={{ fontWeight: 600 }}>{p.entity}</span>
              <span style={{ color: 'var(--ink-soft)' }}>{p.line}</span>
              <span style={{ color: 'var(--ink-soft)' }}>{p.carrier}</span>
              <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{p.score}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 24, height: 24, borderRadius: 6,
                background: tierColor(p.tier) + '22',
                color: tierColor(p.tier),
                fontWeight: 700, fontSize: 12,
              }}>{p.tier}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{p.percentile}th</span>
              <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(p.premium / 1000).toFixed(0)}k</span>
              <span className={`chip chip-${p.statusTone}`} style={{ alignSelf: 'flex-start', justifySelf: 'flex-start' }}>{p.status}</span>
              {/* Opens the client workbench. Affordance is revealed on row hover. */}
              <span className="pl-open" style={{ justifySelf: 'end' }}>
                <span className="pl-open-label">Open</span>
                <Icon name="chevron-right" size={16} />
              </span>
            </div>
          ))}
          {visible.length === 0 && (
            <div style={{ padding: '36px 20px', textAlign: 'center' }} className="caption">
              No policies match “{query}”.
            </div>
          )}
        </div>

        {/* row 3 — tier mix + open queries */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Tier mix</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 12px' }}>Risk quality across the book</h3>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 116, marginTop: 8 }}>
              {tiers.map(({ t, n }) => (
                <div key={t} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <span className="num-sm" style={{ fontSize: 16, color: tierColor(t), fontVariantNumeric: 'tabular-nums' }}>{n}</span>
                  <div style={{
                    width: '100%', height: `${(n / maxTier) * 100}%`, minHeight: 4,
                    background: tierColor(t), borderRadius: '6px 6px 0 0',
                  }} />
                  <span className="micro">Tier {t}</span>
                </div>
              ))}
            </div>
            {/* Recent movements — trend context so the chart isn't just a static snapshot. */}
            <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
              <div className="micro" style={{ marginBottom: 10 }}>Recent movements · last 6 months</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { icon: 'trending-up', color: 'var(--pos)', delta: '+5%', text: 'Tier‑2 spread of the book, as scores improved on renewals' },
                  { icon: 'trending-up', color: 'var(--warn)', delta: '+2', text: 'Tier‑4 placements — BrightLeaf & TerraWind harder to place this cycle' },
                  { icon: 'trending-down', color: 'var(--info)', delta: '−18 days', text: 'Avg time-to-bind, helped by pre-filled signal attestations' },
                ].map((m, i) => (
                  <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      width: 22, height: 22, borderRadius: 6, flexShrink: 0,
                      background: m.color + '1f', color: m.color,
                    }}>
                      <Icon name={m.icon} size={13} />
                    </span>
                    <div style={{ fontSize: 12.5, lineHeight: 1.4 }}>
                      <span style={{ fontWeight: 700, color: m.color, fontVariantNumeric: 'tabular-nums' }}>{m.delta}</span>
                      <span style={{ color: 'var(--ink-soft)' }}> {m.text}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow">Open queries</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Things waiting on you or your clients</h3>
              </div>
              <span className="chip chip-spot">{awaitingBroker} on you</span>
            </div>
            {/* Filters — this is the broker's central comms queue. */}
            <div style={{ display: 'flex', gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
              {queryTabs.map(tab => (
                <button
                  key={tab.key}
                  type="button"
                  className={`chip qfilter ${qFilter === tab.key ? 'qfilter-on' : ''}`}
                  onClick={() => setQFilter(tab.key)}
                >
                  {tab.label} <span style={{ opacity: 0.6 }}>({tab.n})</span>
                </button>
              ))}
            </div>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {queriesShown.length === 0 && (
                <div style={{ padding: '18px 0', textAlign: 'center' }} className="caption">Nothing here right now.</div>
              )}
              {queriesShown.slice(0, 4).map((qq) => (
                <div key={qq.refCode} style={{
                  display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 12, alignItems: 'center',
                  padding: '10px 14px',
                  background: 'var(--surface-elev)',
                  border: '1px solid var(--rule)',
                  borderRadius: 8,
                }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{qq.entity}</div>
                    <div className="micro" style={{
                      overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      maxWidth: 320, marginTop: 2,
                    }}>{qq.ask}</div>
                  </div>
                  <span className={`chip ${qq.awaiting === 'broker' ? 'chip-spot' : qq.awaiting === 'client' ? 'chip-info' : 'chip-pos'}`}>
                    {qq.awaiting === 'broker' ? 'on you' : qq.awaiting === 'client' ? 'on client' : 'resolved'}
                  </span>
                  <span className="micro">{qq.age}</span>
                </div>
              ))}
              {queriesShown.length > 4 && (
                <div className="caption" style={{ textAlign: 'center', marginTop: 2 }}>+ {queriesShown.length - 4} more</div>
              )}
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function KpiCard({ label, value, sub, tone }) {
  const color = tone === 'info' ? 'var(--info-deep)' : tone === 'spot' ? 'var(--spot-deep)' : 'var(--ink)';
  const cardCls = tone === 'info' ? 'card-info' : tone === 'spot' ? 'card-spot' : 'card';
  return (
    <div className={cardCls} style={{ padding: 22 }}>
      <div className="eyebrow" style={tone ? { color } : undefined}>{label}</div>
      <div className="num-xl" style={{ marginTop: 6, color, lineHeight: 1 }}>{value}</div>
      <div className="caption" style={{ marginTop: 6 }}>{sub}</div>
    </div>
  );
}

Object.assign(window, { ReimBrokerBook, KpiCard });
