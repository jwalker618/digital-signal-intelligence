/* global React, FrameReimag, Icon */

/* ============================================================
 * Communications — list + thread
 *
 * ReimCommsList — inbox of underwriter / broker queries
 * ReimCommsThread — single thread detail
 * ============================================================ */

const ENT_M = 'Eastward Robotics';

/* ============================================================ */
function ReimCommsList({ isDark }) {
  const threads = [
    {
      from: 'Hartford Mutual', role: 'UW', line: 'Cyber',
      ask: 'Confirm MFA enforced on privileged identities (NIST 800-63B AAL2)',
      evidence: 'mfa_admin_attestation.pdf',
      status: 'awaiting you',  statusTone: 'spot',
      age: '2h ago', open: true,
    },
    {
      from: 'Hartford Mutual', role: 'UW', line: 'Cyber',
      ask: 'Provide latest SOC 2 Type II report or equivalent audit',
      evidence: 'soc2_typeII_audit.pdf',
      status: 'awaiting you',  statusTone: 'spot',
      age: '1d ago', open: true,
    },
    {
      from: 'Chubb', role: 'UW', line: 'D&O',
      ask: 'Updated board roster + bios for current FY',
      evidence: null,
      status: 'in review',     statusTone: 'info',
      age: '3d ago', open: true,
    },
    {
      from: 'Beazley', role: 'UW', line: 'PI',
      ask: "Acknowledged — we'll close this thread when the indemnity rider is bound.",
      evidence: null,
      status: 'resolved',      statusTone: 'pos',
      age: '5d ago', open: false,
    },
  ];

  return (
    <FrameReimag menu="Communications" entity={ENT_M} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 18, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Communications</div>
            <h2 className="display" style={{ marginTop: 6 }}>Queries from your carriers + broker</h2>
          </div>
          <div style={{ display: 'flex', gap: 28 }}>
            <KpiPill label="Open threads"      value="3" />
            <KpiPill label="Awaiting you"      value="2" tone="spot" />
            <KpiPill label="In review"         value="1" />
            <KpiPill label="Resolved (30 d)"   value="4" tone="pos" />
          </div>
        </div>

        {/* filter pills */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="micro" style={{ marginRight: 4 }}>Filter:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>Open</span>
          <span className="chip">All</span>
          <span className="chip">Cyber</span>
          <span className="chip">PI</span>
          <span className="chip">D&O</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: most recent</span>
        </div>

        {/* threads */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {threads.map((t, i) => <ThreadRow key={i} {...t} first={i === 0} />)}
        </div>

      </div>
    </FrameReimag>
  );
}

function ThreadRow({ from, role, line, ask, evidence, status, statusTone, age, open, first }) {
  const accent = statusTone === 'spot' ? 'var(--spot)'
               : statusTone === 'info' ? 'var(--info)'
               : statusTone === 'pos'  ? 'var(--pos)'
               :                          'var(--ink-mute)';
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '4px 1fr auto 32px',
      gap: 18, alignItems: 'center',
      padding: '18px 20px 18px 16px',
      borderTop: first ? 0 : '1px solid var(--rule)',
      background: 'transparent',
    }}>
      <div style={{
        width: 4, height: 40, borderRadius: 2,
        background: open ? accent : 'transparent',
      }} />
      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 4 }}>
          <span style={{ fontSize: 14, fontWeight: 600 }}>{from}</span>
          <span className="micro">{role}</span>
          <span className="chip" style={{ padding: '2px 8px' }}>{line}</span>
        </div>
        <div style={{
          fontSize: 13.5, color: 'var(--ink)', lineHeight: 1.4,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>
          "{ask}"
        </div>
        {evidence && (
          <div style={{ marginTop: 4, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Icon name="paperclip" size={12} color="var(--ink-mute)" />
            <code style={{
              fontSize: 11,
              background: 'var(--surface-sunken)', padding: '2px 6px',
              borderRadius: 4,
              color: 'var(--ink-soft)',
              fontFamily: 'ui-monospace, monospace',
            }}>{evidence}</code>
            <span className="micro">evidence requested</span>
          </div>
        )}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
        <span className={`chip chip-${statusTone}`}>{status}</span>
        <span className="micro">{age}</span>
      </div>
      <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
    </div>
  );
}

/* ============================================================ */
function ReimCommsThread({ isDark }) {
  const messages = [
    { dir: 'uw',     who: 'Hartford Mutual', role: 'Underwriter', when: '2 days ago',
      body: "We'd like to confirm MFA is enforced on privileged identities before binding. NIST 800-63B AAL2 would satisfy us. Please share the attestation or equivalent SOC 2 control evidence." },
    { dir: 'broker', who: 'Sasha',           role: 'Marsh',       when: '2 days ago',
      body: "Eli — pulling this together. Can you forward the latest IdP exports and your AAL2 attestation? Will package and reply." },
    { dir: 'you',    who: 'Eli (you)',       role: 'Insured',     when: '1 day ago',
      body: "Forwarded the Okta MFA report + last quarter's privileged-access review. Working with IT on the AAL2 attestation — back to you by EOD tomorrow." },
  ];

  return (
    <FrameReimag menu="Communications" entity={ENT_M} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 18, height: '100%', alignContent: 'start' }}>

        {/* breadcrumb + header */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <a className="micro" style={{ display: 'flex', alignItems: 'center', gap: 4 }} href="#">
              <Icon name="arrow-left" size={12} /> All threads
            </a>
            <span className="micro">/</span>
            <span className="micro">REF-2026-04832</span>
          </div>
          <h2 className="display" style={{ marginTop: 10 }}>
            Hartford Mutual <span style={{ color: 'var(--ink-mute)', fontWeight: 400 }}>—</span> Cyber referral
          </h2>
          <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
            <span className="chip chip-spot">awaiting you</span>
            <span className="chip">Cyber · primary</span>
            <span className="chip">Opened Apr 26</span>
            <span className="chip"><Icon name="paperclip" size={11} /> evidence requested</span>
          </div>
        </div>

        {/* reasons + evidence panel */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Underwriter is asking about</div>
            <ul style={{ margin: '8px 0 0', paddingLeft: 18, fontSize: 13.5, lineHeight: 1.7, color: 'var(--ink)' }}>
              <li>Privileged-access MFA enforcement (NIST 800-63B AAL2)</li>
              <li>SOC 2 Type II or equivalent attestation, current FY</li>
            </ul>
          </div>
          <div className="card-spot" style={{ padding: 22 }}>
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Evidence requested</div>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {['mfa_admin_attestation.pdf', 'soc2_typeII_2025.pdf'].map((f) => (
                <div key={f} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '8px 12px',
                  background: 'var(--surface-elev)',
                  border: '1px solid var(--rule)',
                  borderRadius: 8,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                    <Icon name="file-text" size={14} color="var(--spot)" />
                    <span style={{ fontSize: 12.5, fontFamily: 'ui-monospace, monospace', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f}</span>
                  </div>
                  <span className="chip chip-spot" style={{ fontSize: 10, padding: '2px 7px' }}>missing</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* messages */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: 0 }}>Thread · 3 messages</h3>
            <span className="micro">Newest at bottom</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {messages.map((m, i) => <Message key={i} {...m} />)}
          </div>
        </div>

        {/* reply box */}
        <div className="card-spot" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Your reply</div>
            <span className="chip chip-spot">they're waiting</span>
          </div>
          <div style={{
            marginTop: 12, minHeight: 100,
            padding: '12px 14px', fontSize: 13.5, lineHeight: 1.5,
            background: 'var(--surface)',
            border: '1px solid var(--rule-strong)',
            borderRadius: 8,
            color: 'var(--ink-mute)',
          }}>
            Type your reply…
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button className="btn ghost" style={{ padding: '8px 12px' }}>
                <Icon name="paperclip" size={13} /> Attach evidence
              </button>
              <span className="micro">2 files requested</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn ghost">Save draft</button>
              <button className="btn spot">
                <Icon name="send" size={13} /> Send reply
              </button>
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function Message({ dir, who, role, when, body }) {
  const isYou = dir === 'you';
  const accent = dir === 'uw' ? 'var(--info)' : dir === 'broker' ? 'var(--aux)' : 'var(--spot)';
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '40px 1fr', gap: 12,
      marginLeft: isYou ? 60 : 0,
      marginRight: isYou ? 0 : 60,
    }}>
      <div style={{
        width: 40, height: 40, borderRadius: '50%',
        background: 'color-mix(in srgb, var(--surface) 80%, ' + accent + ' 20%)',
        border: '1.5px solid ' + accent,
        color: accent,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        font: '600 13px/1 IBM Plex Sans',
        flexShrink: 0,
      }}>
        {who.split(' ')[0].slice(0, 2).toUpperCase()}
      </div>
      <div style={{
        background: isYou ? 'color-mix(in srgb, var(--surface) 80%, var(--spot) 20%)' : 'var(--surface-elev)',
        border: '1px solid var(--rule)',
        borderRadius: 10,
        padding: '12px 14px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>{who}</span>
            <span className="micro">· {role}</span>
          </div>
          <span className="micro">{when}</span>
        </div>
        <div style={{ fontSize: 13.5, lineHeight: 1.5 }}>{body}</div>
      </div>
    </div>
  );
}

Object.assign(window, { ReimCommsList, ReimCommsThread });
