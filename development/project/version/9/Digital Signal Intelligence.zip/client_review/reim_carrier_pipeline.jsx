/* global React, FrameReimag, Icon, CARRIER_ORG, CARRIER_SUBMISSIONS */

/* ============================================================
 * Carrier · 01 Referral Pipeline — inbound submissions queue
 *
 * Layout
 *   row 1 — hero with pipeline KPIs
 *   row 2 — filter pills + sort
 *   row 3 — submissions table (entity, broker, line, score, tier,
 *           decision, premium, status, age)
 * ============================================================ */

function ReimCarrierPipeline({ isDark }) {
  const subs = CARRIER_SUBMISSIONS;
  const referrals = subs.filter(s => s.decision === 'refer').length;
  const approvals = subs.filter(s => s.decision === 'approve').length;
  const declines  = subs.filter(s => s.decision === 'decline').length;
  const totalPremium = subs.reduce((s, x) => s + x.premium, 0);
  const tierColor = (t) => t <= 2 ? 'var(--pos)' : t === 3 ? 'var(--info)' : t === 4 ? 'var(--warn)' : 'var(--neg)';
  const decisionTone = (d) => d === 'approve' ? 'pos' : d === 'refer' ? 'spot' : 'neg';

  return (
    <FrameReimag menu="Referral Pipeline" entity={CARRIER_ORG.shortName} persona="carrier" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* hero row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 22, display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{
              width: 56, height: 56, borderRadius: 12,
              background: 'var(--info-soft)', color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="user-star" size={28} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">Referral pipeline</div>
              <div className="num" style={{ fontSize: 32, lineHeight: 1, marginTop: 6, color: 'var(--info)', fontVariantNumeric: 'tabular-nums' }}>
                {subs.length}
              </div>
              <div className="caption" style={{ marginTop: 6 }}>
                submissions awaiting decision
              </div>
            </div>
          </div>
          <MiniKpi label="To refer"    value={referrals} tone="spot" />
          <MiniKpi label="To approve"  value={approvals} tone="pos" />
          <MiniKpi label="Declined"    value={declines}  tone="neg" />
          <MiniKpi label="Pipeline $"  value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} />
        </div>

        {/* filters */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="micro" style={{ marginRight: 4 }}>Decision:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
          <span className="chip">Refer ({referrals})</span>
          <span className="chip">Approve ({approvals})</span>
          <span className="chip">Decline ({declines})</span>
          <span style={{ width: 16 }} />
          <span className="micro" style={{ marginRight: 4 }}>Line:</span>
          <span className="chip">Cyber</span>
          <span className="chip">Property</span>
          <span className="chip">Casualty</span>
          <span className="chip">D&O</span>
          <span className="chip">Marine</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: oldest first</span>
        </div>

        {/* table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '2fr 1fr 1.4fr 80px 70px 100px 110px 130px 70px 28px',
            background: 'var(--surface-elev)',
            padding: '10px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Entity', 'Broker', 'Line', 'Score', 'Tier', 'Decision', 'Premium', 'Status', 'Age', ''].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 11, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {subs.map((s, i) => (
            <div key={s.code} style={{
              display: 'grid',
              gridTemplateColumns: '2fr 1fr 1.4fr 80px 70px 100px 110px 130px 70px 28px',
              gap: 0, alignItems: 'center',
              padding: '12px 20px',
              borderBottom: i < subs.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13,
            }}>
              <div>
                <div style={{ fontWeight: 600 }}>{s.entity}</div>
                <div className="micro">{s.industry}</div>
              </div>
              <span className="caption">{s.broker}</span>
              <span style={{ color: 'var(--ink)' }}>{s.line}</span>
              <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{s.score}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 24, height: 24, borderRadius: 6,
                background: tierColor(s.tier) + '22', color: tierColor(s.tier),
                fontWeight: 700, fontSize: 12,
              }}>{s.tier}</span>
              <span className={`chip chip-${decisionTone(s.decision)}`} style={{ justifySelf: 'flex-start' }}>{s.decision}</span>
              <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(s.premium / 1000).toFixed(0)}k</span>
              <span className={`chip chip-${s.statusTone}`} style={{ justifySelf: 'flex-start' }}>{s.status}</span>
              <span className="micro">{s.received}</span>
              <Icon name="chevron-right" size={16} color="var(--ink-mute)" />
            </div>
          ))}
        </div>

      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimCarrierPipeline });
