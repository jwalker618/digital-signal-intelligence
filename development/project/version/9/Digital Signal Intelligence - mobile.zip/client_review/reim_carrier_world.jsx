/* global React, FrameReimag, Icon, CARRIER_ORG, WE_ALERTS, WE_RELATIONSHIPS, WE_SCENARIOS, WE_MATURITY, CARRIER_SUBMISSIONS */

/* ============================================================
 * Carrier · 02 World Engine
 *
 * Sections:
 *   1. World Engine status (maturity, relationships, alerts, entities)
 *   2. Open drift alerts (table)
 *   3. Discovered relationships (table)
 *   4. Portfolio overview (KPIs + tier distribution + sector concentration)
 *   5. Emerging scenarios (list)
 *   6. Shock simulator + impact preview
 * ============================================================ */

function ReimCarrierWorldEngine({ isDark }) {
  const m = WE_MATURITY;
  const alerts = WE_ALERTS;
  const rels = WE_RELATIONSHIPS;
  const scenarios = WE_SCENARIOS;
  const subs = CARRIER_SUBMISSIONS;
  const totalPremium = subs.reduce((s, x) => s + x.premium, 0);
  const avgScore = Math.round(subs.reduce((s, x) => s + x.score, 0) / subs.length);
  const approvalRate = subs.filter(s => s.decision === 'approve').length / subs.length * 100;

  // tier distribution
  const tierCounts = [1, 2, 3, 4, 5].map(t => ({ t, n: subs.filter(s => s.tier === t).length }));
  const maxTier = Math.max(...tierCounts.map(b => b.n), 1);

  // sector concentration
  const bySector = {};
  for (const s of subs) bySector[s.industry] = (bySector[s.industry] || 0) + 1;
  const sectors = Object.entries(bySector).map(([name, n]) => ({ name, n, pct: n / subs.length * 100 })).sort((a, b) => b.n - a.n);

  const sevColor = (s) => s === 'high' ? 'var(--neg)' : s === 'medium' ? 'var(--warn)' : 'var(--info)';
  const lifecycleTone = (l) => l === 'active' ? 'pos' : l === 'provisional' ? 'info' : 'spot';
  const likelihoodTone = (l) => l === 'High' ? 'neg' : l === 'Elevated' ? 'warn' : 'info';

  return (
    <FrameReimag menu="World Engine" entity={CARRIER_ORG.shortName} persona="carrier" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* World Engine Status */}
        <div className="card-info" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>World Engine</div>
              <h2 className="display" style={{ marginTop: 6 }}>Status of the assessing model</h2>
            </div>
            <span className="chip chip-info">{m.assessedEntities.toLocaleString()} entities</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            <StatCell label="Maturity stage" value={m.stage} sub={`${m.timeDepthMonths.toFixed(1)} months of data`} color="var(--info-deep)" />
            <StatCell label="Active relationships" value={m.activeRelationships} sub={`${m.provisional} provisional · ${m.candidate} candidate`} />
            <StatCell label="Open drift alerts" value={alerts.length} sub="Unacknowledged" tone={alerts.length > 0 ? 'neg' : 'pos'} />
            <StatCell label="Assessed entities" value={m.assessedEntities.toLocaleString()} sub={`${m.entitiesWithTemporalData.toLocaleString()} with temporal data`} />
          </div>
        </div>

        {/* Drift alerts */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 20px', background: 'var(--surface-elev)',
            borderBottom: '1px solid var(--rule)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name="eye" size={16} />
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Open drift alerts</h3>
              <span className="chip chip-spot">{alerts.length} open</span>
            </div>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1.6fr 100px 1.4fr 80px 2.4fr 110px',
            background: 'var(--surface-sunken)',
            padding: '8px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Signal', 'Severity', 'Type', 'Detected', 'Summary', ''].map((h) => <span key={h} className="micro" style={{ fontSize: 11 }}>{h}</span>)}
          </div>
          {alerts.map((a, i) => (
            <div key={a.id} style={{
              display: 'grid',
              gridTemplateColumns: '1.6fr 100px 1.4fr 80px 2.4fr 110px',
              gap: 0, alignItems: 'center',
              padding: '12px 20px',
              borderBottom: i < alerts.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13,
            }}>
              <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}>{a.signal}</span>
              <span style={{ color: sevColor(a.severity), fontWeight: 700, textTransform: 'capitalize' }}>{a.severity}</span>
              <span style={{ color: 'var(--ink-soft)', textTransform: 'capitalize' }}>{a.type}</span>
              <span className="micro">{a.detected}</span>
              <span style={{ color: 'var(--ink)' }}>{a.description}</span>
              <button className="btn ghost" style={{ padding: '6px 10px', fontSize: 12 }}>Acknowledge</button>
            </div>
          ))}
        </div>

        {/* Discovered relationships */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 20px', background: 'var(--surface-elev)',
            borderBottom: '1px solid var(--rule)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name="link" size={16} />
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Discovered relationships</h3>
              <span className="chip">{rels.length} recent</span>
            </div>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1.4fr 1.4fr 1fr 80px 80px 80px 100px 90px',
            background: 'var(--surface-sunken)',
            padding: '8px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Source', 'Target', 'Direction', 'Rho', 'Influence', 'Population', 'Lifecycle', 'Discovered'].map((h) => <span key={h} className="micro" style={{ fontSize: 11 }}>{h}</span>)}
          </div>
          {rels.map((r, i) => (
            <div key={r.id} style={{
              display: 'grid',
              gridTemplateColumns: '1.4fr 1.4fr 1fr 80px 80px 80px 100px 90px',
              gap: 0, alignItems: 'center',
              padding: '10px 20px',
              borderBottom: i < rels.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 12.5,
            }}>
              <span style={{ fontFamily: 'ui-monospace, monospace' }}>{r.source}</span>
              <span style={{ fontFamily: 'ui-monospace, monospace' }}>{r.target}</span>
              <span className="caption">{r.direction}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>{r.rho.toFixed(2)}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{Math.round(r.influence * 100)}%</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{r.population}</span>
              <span className={`chip chip-${lifecycleTone(r.lifecycle)}`} style={{ justifySelf: 'flex-start' }}>{r.lifecycle}</span>
              <span className="micro">{r.discovered}</span>
            </div>
          ))}
        </div>

        {/* Portfolio overview */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow">Portfolio overview</div>
              <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>{subs.length} submissions in flight</h3>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 18 }}>
            <StatCell label="Submissions" value={subs.length} />
            <StatCell label="Aggregate premium" value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} />
            <StatCell label="Avg score" value={avgScore} color="var(--info)" />
            <StatCell label="Approval rate" value={`${Math.round(approvalRate)}%`} tone="pos" />
            <StatCell label="Referral rate" value={`${Math.round(subs.filter(s => s.decision === 'refer').length / subs.length * 100)}%`} tone="spot" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <div>
              <div className="micro" style={{ marginBottom: 8 }}>Tier distribution</div>
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 110 }}>
                {tierCounts.map(({ t, n }) => (
                  <div key={t} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                    <span className="num-sm" style={{ fontSize: 14, color: tierColor(t) }}>{n}</span>
                    <div style={{
                      width: '100%', height: `${(n / maxTier) * 78}px`, minHeight: 4,
                      background: tierColor(t), borderRadius: '4px 4px 0 0',
                    }} />
                    <span className="micro">T{t}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="micro" style={{ marginBottom: 8 }}>Sector concentration</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {sectors.slice(0, 6).map((s) => (
                  <div key={s.name}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 2 }}>
                      <span>{s.name}</span>
                      <span style={{ fontVariantNumeric: 'tabular-nums' }}>{s.n} ({Math.round(s.pct)}%)</span>
                    </div>
                    <div style={{ height: 5, background: 'var(--surface-sunken)', borderRadius: 2, overflow: 'hidden' }}>
                      <div style={{ width: `${s.pct}%`, height: '100%', background: 'var(--info)' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Emerging scenarios + simulator */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
              <div>
                <div className="eyebrow">Emerging scenarios</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Continuously monitored</h3>
              </div>
              <span className="caption">Generated from portfolio + signals</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {scenarios.map((sc) => (
                <div key={sc.id} style={{
                  display: 'grid', gridTemplateColumns: '1fr 100px', gap: 16, alignItems: 'center',
                  padding: '12px 14px',
                  background: 'var(--surface-elev)',
                  border: '1px solid var(--rule)',
                  borderRadius: 8,
                }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontSize: 13, fontWeight: 700 }}>{sc.name}</span>
                      <span className={`chip chip-${likelihoodTone(sc.likelihoodLabel)}`}>{Math.round(sc.likelihood * 100)}% · {sc.likelihoodLabel}</span>
                    </div>
                    <div className="caption" style={{ fontSize: 12 }}>
                      Scope: <strong>{sc.scope}</strong> · Magnitude: <strong>{sc.magnitude} pts</strong> · Horizon: {sc.horizon} · Source: {sc.source}
                    </div>
                  </div>
                  <button className="btn spot" style={{ padding: '8px 12px', fontSize: 12 }}>
                    <Icon name="zap" size={13} /> Simulate
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Shock simulator */}
          <div className="card-spot" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow" style={{ color: 'var(--spot)' }}>Shock simulator</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Stress-test the portfolio</h3>
              </div>
              <span className="chip chip-spot">1 active</span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14 }}>
              <div>
                <div className="micro" style={{ marginBottom: 4 }}>Active shocks</div>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 8,
                  padding: '8px 10px',
                  background: 'var(--surface-elev)', borderRadius: 6,
                  fontSize: 12,
                }}>
                  <Icon name="zap" size={12} color="var(--spot)" />
                  <span style={{ fontWeight: 600 }}>Hurricane Wendell</span>
                  <span className="caption">property · −32 pts</span>
                  <Icon name="x" size={12} color="var(--ink-mute)" style={{ marginLeft: 'auto' }} />
                </div>
              </div>

              <div style={{ paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
                <div className="micro" style={{ marginBottom: 8 }}>Impact preview</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div>
                    <div className="micro">Affected</div>
                    <div className="num" style={{ fontSize: 22, color: 'var(--spot)' }}>3</div>
                  </div>
                  <div>
                    <div className="micro">Tier migrations</div>
                    <div className="num" style={{ fontSize: 22, color: 'var(--warn)' }}>2</div>
                  </div>
                  <div>
                    <div className="micro">Decision changes</div>
                    <div className="num" style={{ fontSize: 22 }}>1</div>
                  </div>
                  <div>
                    <div className="micro">Premium impact</div>
                    <div className="num" style={{ fontSize: 22, color: 'var(--neg)' }}>+$84k</div>
                  </div>
                </div>
              </div>

              <button className="btn spot" style={{ marginTop: 4 }}>
                <Icon name="zap" size={13} /> Open full analysis →
              </button>
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function StatCell({ label, value, sub, tone, color }) {
  const valueColor = color || (tone === 'pos' ? 'var(--pos)' : tone === 'spot' ? 'var(--spot)' : tone === 'neg' ? 'var(--neg)' : 'var(--ink)');
  return (
    <div style={{ padding: 14, background: 'var(--surface-elev)', border: '1px solid var(--rule)', borderRadius: 10 }}>
      <div className="micro">{label}</div>
      <div className="num" style={{ fontSize: 22, color: valueColor, marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
      {sub && <div className="caption" style={{ marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

Object.assign(window, { ReimCarrierWorldEngine, StatCell });
