/* global React, FrameReimag, Icon, Kpi, CohortBar, LossOutlookCard, ExposureCard,
   StatusChip, CLIENT_LINES, lineByKey, kMoney */

/* ============================================================
 * Coverages — the client's active book, with an in-place
 * master → detail drill-through.
 *
 *   master  → every policy, grouped by line (click a row to open)
 *   detail  → ReimCoverageDetail: the full, client-flavoured policy
 *             record for ONE line — terms, sub-limits, placement
 *             timeline, signal, premium build-up, loss/exposure,
 *             open requests, documents and contacts.
 *
 * This replaces the old jump into the carrier Submission Workbench:
 * the client never leaves their own visual language.
 * ============================================================ */

const ENT_C = 'Eastward Robotics';

/* Per-policy operational detail, keyed by line. Analytical fields
 * (score, premium, cohort, loss, exposure) come from CLIENT_LINES;
 * this is the contract / placement record that lives only here. */
const COV_DETAIL = {
  cyber: {
    code: 'SUB-26-0118', aggregate: '$10M', territory: 'Worldwide excl. sanctioned',
    waiting: '8 hours · business interruption', underwriter: 'Marco Reyes',
    subLimits: [
      ['Ransomware & extortion', '$5M'],
      ['Business interruption', '$10M'],
      ['Data restoration', '$3M'],
      ['Regulatory defense & fines', '$2M'],
      ['Social engineering', '$250k'],
    ],
    endorsements: ['Dependent business interruption', 'Bricking coverage', 'Reputational harm'],
    timeline: [
      { label: 'Submitted', date: 'Feb 3', state: 'done' },
      { label: 'Quoted', date: 'Feb 18', state: 'done' },
      { label: 'Referred to underwriter', date: 'Mar 1', state: 'done' },
      { label: 'In review', date: 'now', state: 'current' },
      { label: 'Bound', date: 'by Apr 15', state: 'todo' },
    ],
    documents: [
      { name: 'Quote schedule', meta: 'PDF · Feb 18', ready: true },
      { name: 'Policy wording', meta: 'PDF · Feb 18', ready: true },
      { name: 'SOC 2 Type II', meta: 'requested from you', ready: false },
      { name: 'Certificate of insurance', meta: 'available at bind', ready: false },
    ],
    awaiting: [
      'Hartford needs MFA attestation to finish the bind',
      'Provide latest SOC 2 Type II report or equivalent',
    ],
  },
  pi: {
    code: 'SUB-26-0119', aggregate: '$5M', territory: 'USA & Canada',
    waiting: 'None', underwriter: 'Priya Anand',
    subLimits: [
      ['Defense costs', 'In addition to limit'],
      ['Loss of documents', '$500k'],
      ['Mitigation costs', '$1M'],
      ['Court attendance', '$100k / day'],
    ],
    endorsements: ['84-month run-off', 'Aggregation clause', 'Choice of senior counsel'],
    timeline: [
      { label: 'Submitted', date: 'Jul 2', state: 'done' },
      { label: 'Quoted', date: 'Jul 20', state: 'done' },
      { label: 'Bound', date: 'Aug 28', state: 'done' },
      { label: 'Active · preferred', date: 'now', state: 'current' },
      { label: 'Renews', date: 'Sep 1 2026', state: 'todo' },
    ],
    documents: [
      { name: 'Policy schedule', meta: 'PDF · Aug 28', ready: true },
      { name: 'Policy wording', meta: 'PDF · Aug 28', ready: true },
      { name: 'Certificate of insurance', meta: 'PDF · Aug 28', ready: true },
      { name: 'Renewal questionnaire', meta: 'due Jul 2026', ready: false },
    ],
    awaiting: [],
  },
  do: {
    code: 'SUB-26-0120', aggregate: '$15M', territory: 'Worldwide',
    waiting: 'None', underwriter: 'David Kohl',
    subLimits: [
      ['Side A difference-in-conditions', '$5M'],
      ['Investigation costs', '$2M'],
      ['Derivative demand', '$1M'],
      ['Outside directorship liability', '$5M'],
    ],
    endorsements: ['Entity investigation cover', 'Major-shareholder exclusion (>15%)', 'Run-off — not yet placed'],
    timeline: [
      { label: 'Submitted', date: 'May 5', state: 'done' },
      { label: 'Quoted', date: 'May 22', state: 'done' },
      { label: 'Referred to underwriter', date: 'Jun 1', state: 'done' },
      { label: 'Awaiting documents', date: 'now', state: 'current' },
      { label: 'Bound', date: 'by Jun 30', state: 'todo' },
    ],
    documents: [
      { name: 'Quote schedule', meta: 'PDF · May 22', ready: true },
      { name: 'Policy wording', meta: 'PDF · May 22', ready: true },
      { name: 'Ratified board minutes', meta: 'requested from you', ready: false },
      { name: 'Related-party disclosure', meta: 'requested from you', ready: false },
    ],
    awaiting: [
      'Chubb requests completed, ratified board minutes (8 quarters)',
      'Confirm related-party disclosure schedule before terms release',
    ],
  },
};

function ReimCoverages({ isDark, initialOpen = null }) {
  const [open, setOpen] = React.useState(initialOpen); // line key or null

  return (
    <FrameReimag menu="Coverages" entity={ENT_C} isDark={isDark}>
      {open
        ? <ReimCoverageDetail line={lineByKey(open)} onBack={() => setOpen(null)} />
        : <CoveragesList onOpen={setOpen} />}
    </FrameReimag>
  );
}

/* ════════════════════════ MASTER — list ════════════════════════ */
function CoveragesList({ onOpen }) {
  const totalPremium = CLIENT_LINES.reduce((s, l) => s + l.premium, 0);
  const awaitingCount = CLIENT_LINES.filter((l) => (COV_DETAIL[l.key].awaiting || []).length > 0).length;

  return (
    <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 18, height: '100%', alignContent: 'start' }}>
      {/* title + KPIs */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
        <div>
          <div className="eyebrow">Coverages</div>
          <h2 className="display" style={{ marginTop: 6 }}>Your active book at a glance</h2>
          <div className="caption" style={{ marginTop: 6 }}>
            All policies in force, grouped by line. Open any line for its full policy record — terms, documents, placement status and contacts.
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 28 }}>
          <Kpi label="Policies" value={String(CLIENT_LINES.length)} />
          <Kpi label="Lines" value={String(CLIENT_LINES.length)} />
          <Kpi label="Annual premium" value={`$${(totalPremium / 1000).toFixed(0)}k`} />
          <Kpi label="Awaiting you" value={String(awaitingCount)} tone="spot" />
        </div>
      </div>

      {/* filter bar */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <span className="micro" style={{ marginRight: 4 }}>Filter:</span>
        <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All lines</span>
        {CLIENT_LINES.map((l) => <span key={l.key} className="chip">{l.short}</span>)}
        <span style={{ flex: 1 }} />
        <span className="caption">Sort: by premium ↓</span>
      </div>

      {/* per-line cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {CLIENT_LINES.map((l) => {
          const d = COV_DETAIL[l.key];
          const awaiting = (d.awaiting || []).length;
          return (
            <div key={l.key} className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 20px', borderBottom: '1px solid var(--rule)', background: 'var(--surface-elev)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={l.icon} size={16} color="var(--ink)" />
                  </div>
                  <h3 style={{ font: '600 17px/1 IBM Plex Sans', margin: 0 }}>{l.line}</h3>
                  <span className="chip">1 policy</span>
                  {awaiting > 0 && <span className="chip chip-spot"><Icon name="bell-ring" size={11} /> {awaiting} awaiting you</span>}
                </div>
                <span className="caption">{d.code} · ${l.premium.toLocaleString()}</span>
              </div>

              <button
                onClick={() => onOpen(l.key)}
                style={{
                  display: 'grid', gridTemplateColumns: '1.4fr 1fr 0.8fr 1fr 0.9fr 1fr 32px',
                  alignItems: 'center', gap: 16, padding: '16px 20px', width: '100%',
                  background: 'transparent', border: 0, borderTop: '1px solid var(--rule)',
                  textAlign: 'left', cursor: 'pointer', fontFamily: 'IBM Plex Sans, sans-serif',
                }}
                className="cov-row"
              >
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{l.carrier}</div>
                  <div className="micro">renews {l.expires}</div>
                </div>
                <div>
                  <div className="micro">Limit / Aggregate</div>
                  <div className="num-sm" style={{ fontSize: 13 }}>{l.limit}</div>
                </div>
                <div>
                  <div className="micro">Retention</div>
                  <div className="num-sm" style={{ fontSize: 13 }}>{l.retention}</div>
                </div>
                <div>
                  <div className="micro">Signal score</div>
                  <div className="num-sm" style={{ fontSize: 18, color: l.score >= l.median ? 'var(--info-deep)' : 'var(--warn)' }}>{l.score}</div>
                  <div className="micro">{l.percentile}th percentile</div>
                </div>
                <div>
                  <StatusChip tone={l.statusTone}>{l.status}</StatusChip>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="micro">Premium</div>
                  <div className="num-sm" style={{ fontSize: 16, fontWeight: 700 }}>${(l.premium / 1000).toFixed(0)}k</div>
                </div>
                <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ════════════════════════ DETAIL — one policy ════════════════════════ */
function ReimCoverageDetail({ line, onBack }) {
  const d = COV_DETAIL[line.key];
  const aboveMedian = line.score >= line.median;
  const scoreColor = aboveMedian ? 'var(--info-deep)' : 'var(--warn)';
  const strengths = line.helping.reduce((s, h) => s + h[1], 0);
  const opp = line.opportunity.reduce((s, o) => s + o[1], 0);
  const base = line.premium + strengths - opp;
  const worsening = /wors/i.test(line.loss.trend);

  return (
    <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 16, height: '100%', alignContent: 'start' }}>
      {/* back + breadcrumb */}
      <button onClick={onBack} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 0, cursor: 'pointer', color: 'var(--ink-soft)', fontSize: 13, fontWeight: 600, padding: 0, alignSelf: 'flex-start', fontFamily: 'IBM Plex Sans, sans-serif' }}>
        <Icon name="arrow-left" size={15} /> All coverages
      </button>

      {/* header band */}
      <div className="card-info" style={{ padding: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 24, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18, minWidth: 0 }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: 'var(--surface)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Icon name={line.icon} size={28} color="var(--info-deep)" />
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <h2 className="display" style={{ margin: 0 }}>{line.line}</h2>
              <StatusChip tone={line.statusTone}>{line.status}</StatusChip>
            </div>
            <div className="caption" style={{ marginTop: 4 }}>
              {line.carrier} · policy {d.code} · renews {line.expires}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          <div style={{ textAlign: 'right' }}>
            <div className="micro">Signal score</div>
            <div className="num-xl" style={{ color: scoreColor, lineHeight: 1 }}>{line.score}</div>
            <div className="micro">{line.percentile}th percentile</div>
          </div>
          <div className="divider" />
          <div style={{ textAlign: 'right' }}>
            <div className="micro">Annual premium</div>
            <div className="num-xl" style={{ lineHeight: 1 }}>${(line.premium / 1000).toFixed(0)}k</div>
            <div className="micro">${line.premium.toLocaleString()}</div>
          </div>
        </div>
      </div>

      {/* KPI strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
        <Kpi surface="card" label="Limit / Aggregate" value={line.limit} />
        <Kpi surface="card" label="Retention" value={line.retention} />
        <Kpi surface="card" label="Territory" value={d.territory} valueSize={15} />
        <Kpi surface="card" label="Waiting period" value={d.waiting} valueSize={15} />
        <Kpi surface="card" label="Underwriter" value={d.underwriter} valueSize={15} />
      </div>

      {/* two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 16, alignItems: 'start' }}>
        {/* LEFT */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* policy terms */}
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Policy terms</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>What this policy covers</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 28px' }}>
              {d.subLimits.map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '9px 0', borderBottom: '1px solid var(--rule)', gap: 12 }}>
                  <span className="micro">{k}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, textAlign: 'right', whiteSpace: 'nowrap' }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14 }}>
              <div className="micro" style={{ marginBottom: 8 }}>Key endorsements</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {d.endorsements.map((e) => (
                  <span key={e} className="chip" style={{ padding: '4px 9px' }}><Icon name="file-badge" size={11} /> {e}</span>
                ))}
              </div>
            </div>
          </div>

          {/* premium snapshot */}
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div>
                <div className="eyebrow">Premium snapshot</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>How it builds up</h3>
              </div>
              <span className="link-tease caption" style={{ color: 'var(--info-deep)' }}>Full build-up in Risk Insights →</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              <SnapCell label="Base" value={`$${(base / 1000).toFixed(0)}k`} />
              <SnapCell label="Strengths" value={`−${kMoney(strengths)}`} tone="pos" />
              <SnapCell label="Opportunity" value={opp > 0 ? `+${kMoney(opp)}` : '—'} tone="spot" />
              <SnapCell label="Bound" value={`$${(line.premium / 1000).toFixed(0)}k`} tone="info" bold />
            </div>
          </div>

          {/* loss + exposure */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <LossOutlookCard
              band={line.loss.band} trend={line.loss.trend}
              quarters={line.loss.quarters} quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
              frequency={line.loss.frequency} severity={line.loss.severity}
            />
            <ExposureCard value={line.exposure.value} yoy={line.exposure.yoy} band={line.exposure.band} sub={line.exposure.sub} />
          </div>
        </div>

        {/* RIGHT */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* placement timeline */}
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Placement status</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>Where this policy is</h3>
            <Timeline steps={d.timeline} />
          </div>

          {/* open requests */}
          {d.awaiting.length > 0 ? (
            <div className="card-spot" style={{ padding: 22 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div className="eyebrow" style={{ color: 'var(--spot)' }}>Awaiting you</div>
                <span className="chip chip-spot">{d.awaiting.length}</span>
              </div>
              <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {d.awaiting.map((a, i) => (
                  <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <Icon name="circle-dot" size={15} color="var(--spot)" style={{ marginTop: 2, flexShrink: 0 }} />
                    <span style={{ fontSize: 13.5, lineHeight: 1.4 }}>{a}</span>
                  </div>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <button className="btn spot">Respond</button>
                <button className="btn ghost">Message broker</button>
              </div>
            </div>
          ) : (
            <div className="card-pos" style={{ padding: 22, display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: 'var(--pos-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon name="check" size={20} color="var(--pos)" />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>Nothing awaiting you</div>
                <div className="caption" style={{ marginTop: 2 }}>This policy is bound at preferred terms.</div>
              </div>
            </div>
          )}

          {/* documents */}
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>Documents</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {d.documents.map((doc) => (
                <div key={doc.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--rule)' }}>
                  <Icon name={doc.ready ? 'file-text' : 'file-clock'} size={18} color={doc.ready ? 'var(--ink-soft)' : 'var(--spot)'} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600 }}>{doc.name}</div>
                    <div className="micro">{doc.meta}</div>
                  </div>
                  {doc.ready
                    ? <Icon name="download" size={16} color="var(--info-deep)" />
                    : <span className="chip chip-spot" style={{ fontSize: 10 }}>pending</span>}
                </div>
              ))}
            </div>
          </div>

          {/* contacts */}
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>Your contacts</div>
            <Contact icon="briefcase" role="Broker · Marsh" name="Sasha Alvarez" meta="sasha.alvarez@marsh.com" />
            <div style={{ height: 1, background: 'var(--rule)', margin: '12px 0' }} />
            <Contact icon="building-2" role={`Underwriter · ${line.carrier}`} name={d.underwriter} meta={`policy ${d.code}`} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── detail helpers ─────────────────────────────────────────── */
function SnapCell({ label, value, tone, bold }) {
  return (
    <div style={{ padding: '10px 12px', background: 'var(--surface-sunken)', borderRadius: 10 }}>
      <div className="micro">{label}</div>
      <div className="num-sm" style={{ fontSize: bold ? 18 : 15, marginTop: 3, fontWeight: bold ? 700 : 600, color: tone ? `var(--${tone === 'info' ? 'info-deep' : tone === 'spot' ? 'spot-deep' : tone}` + ')' : 'var(--ink)' }}>{value}</div>
    </div>
  );
}

function Timeline({ steps }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {steps.map((s, i) => {
        const last = i === steps.length - 1;
        const color = s.state === 'done' ? 'var(--pos)' : s.state === 'current' ? 'var(--spot)' : 'var(--ink-mute)';
        return (
          <div key={i} style={{ display: 'flex', gap: 12 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                background: s.state === 'todo' ? 'transparent' : color,
                border: `2px solid ${color}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {s.state === 'done' && <Icon name="check" size={12} color="#fff" />}
                {s.state === 'current' && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#fff' }} />}
              </div>
              {!last && <div style={{ width: 2, flex: 1, minHeight: 18, background: s.state === 'done' ? 'var(--pos)' : 'var(--rule)' }} />}
            </div>
            <div style={{ paddingBottom: last ? 0 : 14, marginTop: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: s.state === 'current' ? 700 : 600, color: s.state === 'todo' ? 'var(--ink-mute)' : 'var(--ink)' }}>{s.label}</div>
              <div className="micro">{s.date}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Contact({ icon, role, name, meta }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--surface-elev)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon name={icon} size={17} color="var(--ink)" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="micro">{role}</div>
        <div style={{ fontSize: 14, fontWeight: 600 }}>{name}</div>
        <div className="micro">{meta}</div>
      </div>
      <Icon name="message-square" size={16} color="var(--info-deep)" />
    </div>
  );
}

/* Thin wrapper kept for any external imports. */
function KpiPill(props) { return <Kpi {...props} />; }

Object.assign(window, { ReimCoverages, ReimCoverageDetail, KpiPill });
