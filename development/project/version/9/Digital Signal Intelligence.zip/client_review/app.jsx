/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard,
   ReimOverview, ReimDrivers, ReimActions, ReimPeers,
   ReimProfile, ReimCoverages, ReimScenarios, ReimRequest,
   ReimCommsList, ReimCommsThread,
   ReimBrokerBook, ReimBrokerClients, ReimBrokerCoverages,
   ReimBrokerPlacement, ReimBrokerCarriers, ReimBrokerRecs,
   ReimBrokerComms, ReimBrokerMarket, ReimBrokerAggregation,
   ReimBrokerHealth,
   ReimCarrierPipeline, ReimCarrierWorldEngine,
   WbSummary, WbPricing, WbRisk, WbLoss, WbPremium, WbCoverage,
   WbReferral, WbVersions, WbExposure, WbScenarios, WbDistribution,
   WbCommercial, WbDeductible, WbSir, WbAggregate,
   ReimLogin, ReimLoginSSO, ReimLoginMFA, ReimReset, ReimResetSet,
   ReimUserProfile,
   ReimAdminHealth, ReimAdminUsers, ReimAdminConfigs,
   ReimAdminAudit, ReimAdminLosses,
   ReimAdminRecalibration, ReimAdminRecalDetail */

/* ============================================================
 * Reimagined portal — full sweep across all personas
 * ============================================================ */

const AW = 1440;

function App() {
  return (
    <DesignCanvas>

      <DCSection
        id="client-pages"
        title="Client portal"
        subtitle="The insured's view. Single entity (Eastward Robotics). Warm canvas · navy ink · teal facts · coral actions · green strengths."
      >
        <DCArtboard id="c-overview"   label="01 · Overview"            width={AW} height={970}><ReimOverview /></DCArtboard>
        <DCArtboard id="c-profile"    label="02 · Profile"             width={AW} height={1020}><ReimProfile /></DCArtboard>
        <DCArtboard id="c-coverages"  label="03 · Coverages"           width={AW} height={840}><ReimCoverages /></DCArtboard>
        <DCArtboard id="c-drivers"    label="04 · Risk Insights"       width={AW} height={950}><ReimDrivers /></DCArtboard>
        <DCArtboard id="c-peers"      label="05 · Industry Benchmarks" width={AW} height={900}><ReimPeers /></DCArtboard>
        <DCArtboard id="c-scenarios"  label="06 · Scenarios"           width={AW} height={1000}><ReimScenarios /></DCArtboard>
        <DCArtboard id="c-actions"    label="07 · Action Plan"         width={AW} height={900}><ReimActions /></DCArtboard>
        <DCArtboard id="c-request"    label="08 · Request Coverage"    width={AW} height={900}><ReimRequest /></DCArtboard>
        <DCArtboard id="c-comms"      label="09 · Communications"      width={AW} height={760}><ReimCommsList /></DCArtboard>
        <DCArtboard id="c-thread"     label="10 · Communications · thread" width={AW} height={1000}><ReimCommsThread /></DCArtboard>
      </DCSection>

      <DCSection
        id="broker-pages"
        title="Broker portal"
        subtitle="Book of clients, not a single insured. Marsh — Northeast Specialty, 12 policies across 5 industries."
      >
        <DCArtboard id="b-book"          label="01 · Book of Clients"      width={AW} height={1020}><ReimBrokerBook /></DCArtboard>
        <DCArtboard id="b-clients"       label="02 · Client Health"        width={AW} height={1180}><ReimBrokerClients /></DCArtboard>
        <DCArtboard id="b-coverages"     label="03 · Coverages"            width={AW} height={1020}><ReimBrokerCoverages /></DCArtboard>
        <DCArtboard id="b-placement"     label="04 · Placement Strategy"   width={AW} height={970}><ReimBrokerPlacement /></DCArtboard>
        <DCArtboard id="b-carriers"      label="05 · Carrier Intelligence" width={AW} height={1020}><ReimBrokerCarriers /></DCArtboard>
        <DCArtboard id="b-recs"          label="06 · Recommendations"      width={AW} height={920}><ReimBrokerRecs /></DCArtboard>
        <DCArtboard id="b-comms"         label="07 · Communications"       width={AW} height={760}><ReimBrokerComms /></DCArtboard>
        <DCArtboard id="b-market"        label="08 · Market Pulse"         width={AW} height={1060}><ReimBrokerMarket /></DCArtboard>
        <DCArtboard id="b-aggregation"   label="09 · Risk Aggregation"     width={AW} height={1050}><ReimBrokerAggregation /></DCArtboard>
        <DCArtboard id="b-health"        label="10 · Book Health"          width={AW} height={1050}><ReimBrokerHealth /></DCArtboard>
      </DCSection>

      <DCSection
        id="carrier-pages"
        title="Carrier portal"
        subtitle="The underwriter's view. Hartford Mutual — inbound submissions queue plus the World Engine that scores them."
      >
        <DCArtboard id="ca-pipeline" label="01 · Referral Pipeline" width={AW} height={830}><ReimCarrierPipeline /></DCArtboard>
        <DCArtboard id="ca-world"    label="02 · World Engine"      width={AW} height={1700}><ReimCarrierWorldEngine /></DCArtboard>
      </DCSection>

      <DCSection
        id="carrier-workbench"
        title="Carrier · Submission Workbench"
        subtitle="Drill-down into a single inbound submission — SUB-26-0118 (Eastward Robotics · Cyber). Sidebar switches to the drill-down tab tree; topbar carries submission context. Tabs cover Summary, Commercial Terms, Risk Terms, and Technical Assessment."
      >
        <DCArtboard id="wb-summary"     label="01 · Summary"                   width={AW} height={960}><WbSummary /></DCArtboard>
        <DCArtboard id="wb-pricing"     label="02 · Pricing Anatomy"          width={AW} height={1180}><WbPricing /></DCArtboard>
        <DCArtboard id="wb-risk"        label="03 · Risk Assessment"          width={AW} height={1080}><WbRisk /></DCArtboard>
        <DCArtboard id="wb-loss"        label="04 · Loss Assessment"          width={AW} height={1100}><WbLoss /></DCArtboard>
        <DCArtboard id="wb-exposure"    label="05 · Exposure Assessment"      width={AW} height={1020}><WbExposure /></DCArtboard>
        <DCArtboard id="wb-scenarios"   label="06 · Scenarios"                width={AW} height={1320}><WbScenarios /></DCArtboard>
        <DCArtboard id="wb-referral"    label="07 · Referral Actions"         width={AW} height={1080}><WbReferral /></DCArtboard>
        <DCArtboard id="wb-versions"    label="08 · Model Versions"           width={AW} height={950}><WbVersions /></DCArtboard>
        <DCArtboard id="wb-commercial"  label="09 · Terms Overview"            width={AW} height={1080}><WbCommercial /></DCArtboard>
        <DCArtboard id="wb-premium"     label="10 · Premium Assembly"         width={AW} height={1080}><WbPremium /></DCArtboard>
        <DCArtboard id="wb-distrib"     label="11 · Distribution"             width={AW} height={730}><WbDistribution /></DCArtboard>
        <DCArtboard id="wb-coverage"    label="12 · Coverage Terms"           width={AW} height={920}><WbCoverage /></DCArtboard>
        <DCArtboard id="wb-deductible"  label="13 · Deductible Structure"     width={AW} height={680}><WbDeductible /></DCArtboard>
        <DCArtboard id="wb-sir"         label="14 · SIR & Waiting Periods"    width={AW} height={720}><WbSir /></DCArtboard>
        <DCArtboard id="wb-aggregate"   label="15 · Aggregate & Reinstatement" width={AW} height={760}><WbAggregate /></DCArtboard>
      </DCSection>

      <DCSection
        id="auth-pages"
        title="Authentication"
        subtitle="Pre-app surfaces — full-screen split with brand panel + clean form."
      >
        <DCArtboard id="au-login"     label="01 · Sign in"          width={AW} height={820}><ReimLogin /></DCArtboard>
        <DCArtboard id="au-sso"       label="02 · Sign in · SSO"    width={AW} height={820}><ReimLoginSSO /></DCArtboard>
        <DCArtboard id="au-mfa"       label="03 · MFA challenge"    width={AW} height={820}><ReimLoginMFA /></DCArtboard>
        <DCArtboard id="au-reset"     label="04 · Reset · request"  width={AW} height={820}><ReimReset /></DCArtboard>
        <DCArtboard id="au-reset-set" label="05 · Reset · set new"  width={AW} height={820}><ReimResetSet /></DCArtboard>
      </DCSection>

      <DCSection
        id="account"
        title="Account"
        subtitle="User profile — identity, permissions, security."
      >
        <DCArtboard id="ac-profile" label="01 · Your Account" width={AW} height={830}><ReimUserProfile /></DCArtboard>
      </DCSection>

      <DCSection
        id="admin-pages"
        title="Admin console"
        subtitle="System operators only. Same design system, denser tooling vibe — observability, governance, and the recalibration loop."
      >
        <DCArtboard id="ad-health"    label="01 · System Health"            width={AW} height={840}><ReimAdminHealth /></DCArtboard>
        <DCArtboard id="ad-users"     label="02 · Users & Roles"            width={AW} height={970}><ReimAdminUsers /></DCArtboard>
        <DCArtboard id="ad-configs"   label="03 · Configs"                  width={AW} height={830}><ReimAdminConfigs /></DCArtboard>
        <DCArtboard id="ad-audit"     label="04 · Audit Log"                width={AW} height={900}><ReimAdminAudit /></DCArtboard>
        <DCArtboard id="ad-losses"    label="05 · Loss Register"            width={AW} height={870}><ReimAdminLosses /></DCArtboard>
        <DCArtboard id="ad-recal"     label="06 · Recalibration"            width={AW} height={830}><ReimAdminRecalibration /></DCArtboard>
        <DCArtboard id="ad-recal-d"   label="07 · Recalibration · detail"   width={AW} height={1080}><ReimAdminRecalDetail /></DCArtboard>
      </DCSection>

    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
