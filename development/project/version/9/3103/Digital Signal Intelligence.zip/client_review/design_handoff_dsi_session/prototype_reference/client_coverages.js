/* global window */

/* ============================================================
 * client_coverages.js — the Client Portal's multi-coverage model.
 *
 * Eastward Robotics holds THREE lines, each with its own score,
 * cohort, loss outlook, exposure, signals and actions. The four
 * intelligence pages (Summary, Industry Benchmarks, Scenarios,
 * Action Plan) all read from here and switch on the selected line,
 * with an "All" portfolio roll-up computed at the bottom.
 *
 * Plain JS (no React) so it loads before the babel components.
 * ============================================================ */

const CLIENT_LINES = [
  /* ───────────────────────────── Cyber — primary, mid-pack, improving ── */
  {
    key: 'cyber', line: 'Cyber', short: 'Cyber', icon: 'shield-check',
    carrier: 'Hartford Mutual', status: 'In review', statusTone: 'spot',
    limit: '$10M / $10M', retention: '$50k', expires: '2026-04-15',
    color: 'var(--info)',
    premium: 185200,
    score: 724, prev: 706, median: 714, topDecile: 784,
    range: [600, 880], cohortMean: 720, sd: 50,
    percentile: 64, peers: 38, peersAbove: 14,
    cohortLabel: 'USA · Industrial machinery (NAICS 333) · rev $50–250M · Cyber',
    scoreHist: [
      { label: 'Q1 ’25', value: 692 },
      { label: 'Q2 ’25', value: 705 },
      { label: 'Q3 ’25', value: 712 },
      { label: 'last quote', value: 706, marker: 'prev' },
      { label: 'now', value: 724 },
    ],
    helping: [
      ['MFA on admins', 12100],
      ['No prior claims (5y)', 9300],
      ['EDR coverage 95%+', 6700],
    ],
    opportunity: [
      ['SOC 2 Type II', 18200],
      ['Backup encryption', 11400],
      ['Public RDP exposed', 6200],
      ['IR playbook', 4900],
    ],
    loss: {
      band: 'Low', trend: 'Improving',
      quarters: [0, 0, 0, 0, 0, 0.4, 0, 0, 0, 0, 0.7, 0],
      frequency: { value: 32, cohort: 48 },
      severity: { value: 41, cohort: 44 },
    },
    exposure: { value: '$118M', yoy: '+12%', band: 'mid', sub: '2 states · diversified' },
    practices: [
      { name: 'SOC 2 Type II audit', you: false, pct: 78 },
      { name: '24/7 SOC monitoring', you: false, pct: 72 },
      { name: 'Documented IR playbook', you: false, pct: 68 },
      { name: 'Verified backup encryption', you: false, pct: 65 },
      { name: 'MFA on admin accounts', you: true, pct: 88 },
      { name: 'EDR coverage > 95%', you: true, pct: 79 },
    ],
    actions: [
      {
        headline: 'Commission a SOC 2 Type II audit', signal: 'No SOC 2 Type II on file',
        delta: 18200, pct: 9.8, effort: 'HIGH', duration: '4–6 months', cost: '$45k–90k', leverage: 47,
        why: 'Carriers in your tier weight third-party attestation heavily. Roughly 78% of top-decile peers in your cohort hold a current SOC 2 Type II.',
        evidence: 'Final report or bridge letter from a Big-4 / qualified auditor.',
      },
      {
        headline: 'Verify backup encryption end-to-end', signal: 'Backup encryption unverified',
        delta: 11400, effort: 'LOW', duration: '2–4 weeks', cost: '$5k–12k', leverage: 132,
        why: 'Demonstrable at-rest + in-transit encryption of backups is a fast, high-leverage control most carriers credit immediately.',
        evidence: 'Config export or attestation from your backup provider.',
      },
      {
        headline: 'Eliminate public-facing RDP', signal: 'Public-facing RDP detected',
        delta: 6200, effort: 'MEDIUM', duration: '4–8 weeks', cost: '$8k–20k', leverage: 78,
        why: 'Exposed RDP is a top initial-access vector. Closing it removes a recurring scan finding.',
        evidence: 'External scan showing no open 3389, or VPN/bastion architecture.',
      },
      {
        headline: 'Author + tabletop an IR playbook', signal: 'IR playbook not documented',
        delta: 4900, effort: 'MEDIUM', duration: '6–10 weeks', cost: '$10k–25k', leverage: 62,
        why: 'A documented, exercised incident-response plan shortens assumed dwell time in carrier models.',
        evidence: 'Playbook document + dated tabletop exercise notes.',
      },
    ],
    note: null,
  },

  /* ───────────────────────────── Professional Indemnity — strong, top quartile ── */
  {
    key: 'pi', line: 'Professional Indemnity', short: 'PI', icon: 'file-check',
    carrier: 'Beazley', status: 'Preferred', statusTone: 'pos',
    limit: '$5M / $5M', retention: '$25k', expires: '2026-09-01',
    color: 'var(--aux)',
    premium: 162000,
    score: 758, prev: 749, median: 731, topDecile: 792,
    range: [600, 860], cohortMean: 731, sd: 42,
    percentile: 81, peers: 26, peersAbove: 5,
    cohortLabel: 'USA · Professional & technical services · rev $50–250M · Professional Indemnity',
    scoreHist: [
      { label: 'Q1 ’25', value: 738 },
      { label: 'Q2 ’25', value: 744 },
      { label: 'Q3 ’25', value: 751 },
      { label: 'last quote', value: 749, marker: 'prev' },
      { label: 'now', value: 758 },
    ],
    helping: [
      ['Clean claims history (5y)', 14200],
      ['Defined scope-of-work contracts', 8100],
      ['Senior technical review', 5400],
    ],
    opportunity: [
      ['Subcontractor vetting', 6800],
      ['Standardised engagement letters', 3200],
    ],
    loss: {
      band: 'Very low', trend: 'Stable',
      quarters: [0, 0, 0, 0, 0, 0, 0.3, 0, 0, 0, 0, 0],
      frequency: { value: 21, cohort: 39 },
      severity: { value: 30, cohort: 47 },
    },
    exposure: { value: '$94M', yoy: '+6%', band: 'mid', sub: 'single jurisdiction · concentrated' },
    practices: [
      { name: 'Defined scope-of-work contracts', you: true, pct: 84 },
      { name: 'Senior technical sign-off', you: true, pct: 80 },
      { name: 'Clean claims history (5y)', you: true, pct: 76 },
      { name: 'Adequate tower limit', you: true, pct: 71 },
      { name: 'Subcontractor vetting process', you: false, pct: 58 },
      { name: 'Standardised engagement letters', you: false, pct: 52 },
    ],
    actions: [
      {
        headline: 'Stand up a subcontractor vetting process', signal: 'No formal subcontractor vetting',
        delta: 6800, effort: 'MEDIUM', duration: '4–6 weeks', cost: '$6k–15k', leverage: 70,
        why: 'PI carriers credit documented vetting of downstream parties — it caps vicarious-liability tails.',
        evidence: 'Vetting checklist + sample completed records.',
      },
      {
        headline: 'Standardise engagement letters', signal: 'Engagement terms vary by project',
        delta: 3200, effort: 'LOW', duration: '2–3 weeks', cost: '$3k–8k', leverage: 96,
        why: 'Consistent limitation-of-liability and scope clauses reduce ambiguity carriers price for.',
        evidence: 'Approved master engagement-letter template.',
      },
    ],
    note: 'Already top quartile — limited premium upside. The goal here is holding position, not chasing points.',
  },

  /* ───────────────────────────── Directors & Officers — weak, drags the book ── */
  {
    key: 'do', line: 'Directors & Officers', short: 'D&O', icon: 'users',
    carrier: 'Chubb', status: 'Awaiting reply', statusTone: 'spot',
    limit: '$15M / $15M', retention: '$100k', expires: '2026-06-30',
    color: 'var(--warn)',
    premium: 140500,
    score: 648, prev: 661, median: 689, topDecile: 762,
    range: [560, 840], cohortMean: 689, sd: 47,
    percentile: 28, peers: 31, peersAbove: 22,
    cohortLabel: 'USA · Private-company D&O · rev $50–250M · Directors & Officers',
    scoreHist: [
      { label: 'Q1 ’25', value: 678 },
      { label: 'Q2 ’25', value: 669 },
      { label: 'Q3 ’25', value: 663 },
      { label: 'last quote', value: 661, marker: 'prev' },
      { label: 'now', value: 648 },
    ],
    helping: [
      ['Independent board seats', 7200],
      ['Audit committee in place', 5100],
    ],
    opportunity: [
      ['Financial restatement exposure', 21400],
      ['Incomplete board minutes', 9800],
      ['No run-off provision', 7300],
      ['Related-party disclosure gaps', 5600],
    ],
    loss: {
      band: 'Elevated', trend: 'Worsening',
      quarters: [0, 0, 0.5, 0, 0, 0.6, 0, 0.8, 0, 0.4, 0, 0.7],
      frequency: { value: 58, cohort: 44 },
      severity: { value: 61, cohort: 50 },
    },
    exposure: { value: '$132M', yoy: '+18%', band: 'large', sub: 'multi-entity · recent funding round' },
    practices: [
      { name: 'Restatement-risk controls', you: false, pct: 74 },
      { name: 'Complete, ratified board minutes', you: false, pct: 69 },
      { name: 'Related-party disclosure process', you: false, pct: 61 },
      { name: 'D&O run-off provision', you: false, pct: 58 },
      { name: 'Independent board seats', you: true, pct: 71 },
      { name: 'Standing audit committee', you: true, pct: 66 },
    ],
    actions: [
      {
        headline: 'Strengthen financial-restatement controls', signal: 'Restatement exposure flagged',
        delta: 21400, pct: 15.2, effort: 'HIGH', duration: '3–5 months', cost: '$30k–60k', leverage: 58,
        why: 'D&O models weight financial-reporting integrity heavily after recent funding. This is the single biggest lever in your whole book.',
        evidence: 'Documented close process + external review memo.',
      },
      {
        headline: 'Complete & ratify board minutes', signal: 'Board minutes incomplete',
        delta: 9800, effort: 'LOW', duration: '3–5 weeks', cost: '$4k–10k', leverage: 110,
        why: 'Gaps in the minute book are an easily-closed governance finding carriers penalise.',
        evidence: 'Ratified minutes for the trailing 8 quarters.',
      },
      {
        headline: 'Add a D&O run-off provision', signal: 'No run-off provision in place',
        delta: 7300, effort: 'MEDIUM', duration: '4–6 weeks', cost: 'Negotiated at bind', leverage: 74,
        why: 'A run-off / tail provision protects departing directors and is expected at your funding stage.',
        evidence: 'Endorsement request to your carrier.',
      },
      {
        headline: 'Close related-party disclosure gaps', signal: 'Related-party disclosures incomplete',
        delta: 5600, effort: 'MEDIUM', duration: '4–8 weeks', cost: '$6k–14k', leverage: 60,
        why: 'Complete related-party disclosure reduces the conflict-of-interest tail carriers reserve against.',
        evidence: 'Updated disclosure schedule signed by the board.',
      },
    ],
    note: 'Below cohort median and slipping — down 13 points since last quote. This line holds the book’s largest opportunity.',
  },
];

/* effort → leverage weighting helpers used by the Action Plan ranking. */
function effortRank(e) { return e === 'LOW' ? 0 : e === 'MEDIUM' ? 1 : 2; }

/* Build the portfolio roll-up from the per-line model. */
function buildPortfolio(lines) {
  const totalPremium = lines.reduce((s, l) => s + l.premium, 0);
  const wScore = Math.round(lines.reduce((s, l) => s + l.score * l.premium, 0) / totalPremium);
  const wPrev = Math.round(lines.reduce((s, l) => s + l.prev * l.premium, 0) / totalPremium);
  const totalOpp = lines.reduce((s, l) => s + l.opportunity.reduce((a, o) => a + o[1], 0), 0);
  const lowEffortWins = lines.reduce((s, l) => s + l.actions.filter((a) => a.effort === 'LOW').length, 0);
  const totalActions = lines.reduce((s, l) => s + l.actions.length, 0);

  // every action, tagged with its line, ranked by leverage then $.
  const allActions = lines
    .flatMap((l) => l.actions.map((a) => ({ ...a, lineKey: l.key, lineShort: l.short, lineName: l.line })))
    .sort((a, b) => (b.leverage - a.leverage) || (b.delta - a.delta));

  // premium segments for the PremiumBreakdown bar.
  const premiumPolicies = lines.map((l) => ({ name: l.short, amount: l.premium, color: l.color }));

  // per-line opportunity totals (where the upside is).
  const oppByLine = lines.map((l) => ({
    key: l.key, short: l.short, name: l.line, color: l.color,
    amount: l.opportunity.reduce((a, o) => a + o[1], 0),
  }));

  return {
    key: 'all', label: 'All coverages',
    lineCount: lines.length,
    totalPremium, score: wScore, prev: wPrev, delta: wScore - wPrev,
    totalOpp, lowEffortWins, totalActions,
    bestLine: [...lines].sort((a, b) => b.percentile - a.percentile)[0],
    weakLine: [...lines].sort((a, b) => a.percentile - b.percentile)[0],
    aggExposure: '$344M',
    lossBand: 'Moderate',
    scoreHist: [
      { label: 'Q1 ’25', value: 699 },
      { label: 'Q2 ’25', value: 704 },
      { label: 'Q3 ’25', value: 709 },
      { label: 'last quote', value: 707, marker: 'prev' },
      { label: 'now', value: wScore },
    ],
    allActions, premiumPolicies, oppByLine,
  };
}

const CLIENT_PORTFOLIO = buildPortfolio(CLIENT_LINES);

/* Coverage lookup by key, plus the switcher option list (All first). */
function lineByKey(k) { return CLIENT_LINES.find((l) => l.key === k) || null; }
const COVERAGE_OPTIONS = [
  { key: 'all', short: 'All', icon: 'layers' },
  ...CLIENT_LINES.map((l) => ({ key: l.key, short: l.short, icon: l.icon, statusTone: l.statusTone })),
];

/* tiny money formatter shared by the pages. */
function kMoney(n, dp = 1) {
  const v = n / 1000;
  return '$' + (Number.isInteger(v) || dp === 0 ? v.toFixed(0) : v.toFixed(dp)) + 'k';
}

Object.assign(window, {
  CLIENT_LINES, CLIENT_PORTFOLIO, COVERAGE_OPTIONS,
  lineByKey, kMoney, effortRank,
});
