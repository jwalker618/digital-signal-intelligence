/* global React */

/* ============================================================
 * widgets.jsx — building blocks of the DSI mobile feed.
 *
 * Everything is glanceable, tuned for a ~402px phone column, and
 * speaks the reimagined desktop language: white/elevated surfaces on
 * warm canvas, navy ink, teal = info, coral = "awaiting you",
 * green/red/amber semantic, blue = aux.
 *
 * Exports to window: Icon, MOBILE_CSS, Section, SignalHero, AwaitingRail,
 *   GlanceGrid, ThreadList, SignalFeed, Chip.
 * ============================================================ */

// Icon — iconify-icon (lucide set), loaded in <head>.
function Icon({ name, size = 18, color, style = {} }) {
  return (
    <iconify-icon
      icon={`lucide:${name}`}
      width={size} height={size}
      style={{ color: color || 'inherit', display: 'inline-flex', ...style }}
    />
  );
}

// tone → {base, soft, deep} CSS vars.
function toneVars(tone) {
  if (!tone || tone === 'ink') return { base: 'var(--ink)', soft: 'var(--surface-sunken)', deep: 'var(--ink)' };
  const deep = (tone === 'info' || tone === 'spot') ? `var(--${tone}-deep)` : `var(--${tone})`;
  return { base: `var(--${tone})`, soft: `var(--${tone}-soft)`, deep };
}

const MOBILE_CSS = `
  .dsi-app{
    font-family:'IBM Plex Sans',system-ui,sans-serif;
    color:var(--ink); background:var(--canvas);
    height:100%; position:relative;
    -webkit-font-smoothing:antialiased;
    transition:background .45s ease, color .45s ease;
  }
  .dsi-scroll{
    height:100%; overflow-y:auto; overflow-x:hidden;
    -webkit-overflow-scrolling:touch;
    scrollbar-width:none;
  }
  .dsi-scroll::-webkit-scrollbar{display:none}
  .dsi-pad{ padding:0 20px; }

  .dsi-eyebrow{
    font-size:11px; font-weight:700; letter-spacing:.13em; text-transform:uppercase;
    color:var(--ink-mute);
  }
  .dsi-sect{ display:flex; align-items:flex-end; justify-content:space-between; padding:0 2px 13px; margin-top:34px; }
  .dsi-sect h3{ font-size:21px; font-weight:600; letter-spacing:-.015em; margin:0; line-height:1; }
  .dsi-sect-link{ font-size:13px; font-weight:600; color:var(--info-deep); display:flex; align-items:center; gap:1px; white-space:nowrap; }

  .dsi-card{
    background:var(--surface); border:1px solid var(--rule); border-radius:22px;
    box-shadow:0 1px 2px rgba(11,34,55,.04), 0 8px 24px rgba(11,34,55,.05);
    transition:background .45s ease, border-color .45s ease, transform .18s cubic-bezier(.3,.7,.4,1);
  }
  .dsi-app.is-dark .dsi-card{ box-shadow:0 1px 2px rgba(0,0,0,.25), 0 10px 30px rgba(0,0,0,.32); }
  .dsi-press{ cursor:default; }
  .dsi-press:active{ transform:scale(.975); }

  /* briefing */
  .dsi-brief{ font-size:17px; line-height:1.5; color:var(--ink-soft); letter-spacing:-.006em; }
  .dsi-brief b{ color:var(--ink); font-weight:600; }

  /* signal hero */
  .dsi-hero{ padding:22px 22px 20px; }
  .dsi-ring-num{ font-size:34px; font-weight:300; line-height:.9; letter-spacing:-.02em; font-variant-numeric:tabular-nums; color:var(--ink); }
  .dsi-ring-cap{ font-size:9.5px; font-weight:700; letter-spacing:.1em; text-transform:uppercase; color:var(--ink-mute); margin-top:3px; }
  .dsi-delta{ display:inline-flex; align-items:center; gap:2px; padding:4px 10px 4px 7px; border-radius:999px;
    font-size:13px; font-weight:700; font-variant-numeric:tabular-nums; }

  .dsi-mover{ display:flex; align-items:center; gap:11px; padding:11px 0; }
  .dsi-mover + .dsi-mover{ border-top:1px solid var(--rule); }
  .dsi-mover-dot{ width:30px; height:30px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
  .dsi-mover-tx{ flex:1; font-size:13.5px; line-height:1.35; color:var(--ink-soft); }

  /* awaiting rail */
  .dsi-await-rail{ display:flex; gap:13px; overflow-x:auto; padding:2px 20px 6px; margin:0 -20px;
    scroll-snap-type:x mandatory; scrollbar-width:none; }
  .dsi-await-rail::-webkit-scrollbar{display:none}
  .dsi-await{ scroll-snap-align:start; flex:0 0 79%; max-width:300px; border-radius:20px; padding:17px 18px 15px;
    position:relative; background:var(--surface); border:1px solid var(--rule);
    box-shadow:0 1px 2px rgba(11,34,55,.04), 0 8px 24px rgba(11,34,55,.06);
    display:flex; flex-direction:column; min-height:178px; }
  .dsi-app.is-dark .dsi-await{ box-shadow:0 1px 2px rgba(0,0,0,.25), 0 10px 26px rgba(0,0,0,.3); }
  .dsi-await::before{ content:''; position:absolute; left:0; top:18px; bottom:18px; width:3px; border-radius:0 3px 3px 0; background:var(--spot); }
  .dsi-await-act{ margin-top:auto; display:flex; align-items:center; justify-content:center; gap:6px;
    height:40px; border-radius:13px; background:var(--spot); color:#fff; font-weight:700; font-size:14px; letter-spacing:-.01em; }
  .dsi-app.is-dark .dsi-await-act{ color:var(--spot-deep); }

  /* glance grid */
  .dsi-glance{ display:grid; grid-template-columns:1fr 1fr; gap:13px; }
  .dsi-tile{ border-radius:20px; padding:16px 16px 15px; min-height:122px; display:flex; flex-direction:column; justify-content:space-between;
    background:var(--surface); border:1px solid var(--rule); box-shadow:0 1px 2px rgba(11,34,55,.04), 0 6px 18px rgba(11,34,55,.05); }
  .dsi-app.is-dark .dsi-tile{ box-shadow:0 1px 2px rgba(0,0,0,.25), 0 8px 22px rgba(0,0,0,.3); }
  .dsi-tile-val{ font-size:30px; font-weight:600; letter-spacing:-.025em; line-height:1; font-variant-numeric:tabular-nums; }
  .dsi-tile-lbl{ font-size:12.5px; font-weight:600; color:var(--ink); }
  .dsi-tile-sub{ font-size:11px; color:var(--ink-mute); margin-top:3px; line-height:1.3;
    overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; }
  .dsi-tile-ic{ width:30px; height:30px; border-radius:9px; display:flex; align-items:center; justify-content:center; }

  /* threads */
  .dsi-thread{ display:flex; align-items:center; gap:13px; padding:15px 17px; cursor:default; }
  .dsi-thread + .dsi-thread{ border-top:1px solid var(--rule); }
  .dsi-thread:active{ background:var(--surface-sunken); }
  .dsi-thread-av{ width:42px; height:42px; border-radius:13px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:14px; }
  .dsi-thread-who{ font-size:15px; font-weight:600; letter-spacing:-.01em; line-height:1.15; }
  .dsi-thread-sub{ font-size:12px; color:var(--ink-mute); margin-top:1px; }
  .dsi-thread-ask{ font-size:13px; color:var(--ink-soft); margin-top:4px; line-height:1.35;
    overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; }
  .dsi-chip{ display:inline-flex; align-items:center; gap:4px; padding:3px 9px; border-radius:999px; font-size:10.5px; font-weight:700; letter-spacing:.01em; white-space:nowrap; }

  /* signal feed timeline */
  .dsi-evt{ display:flex; gap:14px; }
  .dsi-evt-rail{ display:flex; flex-direction:column; align-items:center; flex-shrink:0; }
  .dsi-evt-ic{ width:38px; height:38px; border-radius:12px; display:flex; align-items:center; justify-content:center; z-index:1; }
  .dsi-evt-line{ width:2px; flex:1; background:var(--rule); margin:5px 0; border-radius:2px; }
  .dsi-evt-body{ flex:1; padding-bottom:22px; }
  .dsi-evt-top{ display:flex; align-items:baseline; justify-content:space-between; gap:10px; }
  .dsi-evt-title{ font-size:14px; font-weight:700; letter-spacing:-.005em; }
  .dsi-evt-text{ font-size:13.5px; line-height:1.45; color:var(--ink-soft); margin-top:3px; }
  .dsi-evt-time{ font-size:11.5px; color:var(--ink-mute); font-weight:600; white-space:nowrap; }

  @keyframes dsi-rise{ from{ opacity:0; transform:translateY(16px); } to{ opacity:1; transform:none; } }
  .dsi-rise{ animation:dsi-rise .55s cubic-bezier(.2,.7,.3,1) both; }
`;

// ── Section header ───────────────────────────────────────────
function Section({ title, link, onLink, style }) {
  return (
    <div className="dsi-sect" style={style}>
      <h3>{title}</h3>
      {link && (
        <div className="dsi-sect-link dsi-press" onClick={onLink}>
          {link}<Icon name="chevron-right" size={15} />
        </div>
      )}
    </div>
  );
}

// ── Sparkline ────────────────────────────────────────────────
function Sparkline({ data, stroke, w = 132, h = 40 }) {
  const min = Math.min(...data), max = Math.max(...data);
  const span = max - min || 1;
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => [i * step, h - 4 - ((v - min) / span) * (h - 8)]);
  const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = line + ` L${w} ${h} L0 ${h} Z`;
  const gid = 'sg' + Math.round(data[0]) + data.length + Math.round(w);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block', overflow: 'visible' }}>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={stroke} stopOpacity="0.18" />
          <stop offset="1" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${gid})`} />
      <path d={line} fill="none" stroke={stroke} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3.2" fill={stroke} />
    </svg>
  );
}

// ── Signal ring (SVG arc) ────────────────────────────────────
function SignalRing({ frac, value, caption, tone = 'info' }) {
  const R = 52, C = 2 * Math.PI * R;
  const dash = Math.max(0.02, frac) * C;
  const col = toneVars(tone).base;
  return (
    <div style={{ position: 'relative', width: 124, height: 124, flexShrink: 0 }}>
      <svg width="124" height="124" viewBox="0 0 124 124" style={{ transform: 'rotate(-90deg)' }}>
        <circle cx="62" cy="62" r={R} fill="none" stroke="var(--surface-sunken)" strokeWidth="9" />
        <circle cx="62" cy="62" r={R} fill="none" stroke={col} strokeWidth="9" strokeLinecap="round"
          strokeDasharray={`${dash} ${C}`} style={{ transition: 'stroke-dasharray .9s cubic-bezier(.3,.7,.3,1)' }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <div className="dsi-ring-num">{value}</div>
        <div className="dsi-ring-cap">{caption}</div>
      </div>
    </div>
  );
}

// ── Signal hero card ─────────────────────────────────────────
function SignalHero({ score, accentRing = 'info' }) {
  const dirIcon = score.dir === 'up' ? 'trending-up' : score.dir === 'down' ? 'trending-down' : 'minus';
  const dv = toneVars(score.tone);
  const av = toneVars(accentRing);
  return (
    <div className="dsi-card dsi-hero">
      <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
        <SignalRing frac={score.frac} value={score.value} caption="/ 800" tone={accentRing} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="dsi-eyebrow">{score.label}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
            <span className="dsi-delta" style={{ background: dv.soft, color: dv.deep }}>
              <Icon name={dirIcon} size={14} /> {score.delta}
            </span>
            <span style={{ fontSize: 12.5, color: 'var(--ink-mute)', fontWeight: 600 }}>this week</span>
          </div>
          <div style={{ marginTop: 12 }}>
            <Sparkline data={score.spark} stroke={dv.base} w={150} h={42} />
          </div>
        </div>
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-mute)', marginTop: 4, marginBottom: 4 }}>{score.caption}</div>
      <div style={{ marginTop: 10, paddingTop: 4, borderTop: '1px solid var(--rule)' }}>
        {score.movers.map((m, i) => {
          const mt = toneVars(m.tone);
          const mi = m.dir === 'up' ? 'arrow-up-right' : m.dir === 'down' ? 'arrow-down-right' : 'minus';
          return (
            <div className="dsi-mover" key={i}>
              <div className="dsi-mover-dot" style={{ background: mt.soft, color: mt.deep }}>
                <Icon name={mi} size={16} />
              </div>
              <div className="dsi-mover-tx">{m.text}</div>
              <div style={{ fontWeight: 700, fontSize: 13.5, color: mt.deep, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{m.delta}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Awaiting rail (coral, horizontal snap) ───────────────────
function AwaitingRail({ items, onAct }) {
  return (
    <div className="dsi-await-rail">
      {items.map((it) => (
        <div className="dsi-await" key={it.id}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span className="dsi-chip" style={{ background: 'var(--spot-soft)', color: 'var(--spot-deep)' }}>
              <Icon name="bell-ring" size={12} /> awaiting you
            </span>
            <span style={{ fontSize: 11.5, color: 'var(--ink-mute)', fontWeight: 600 }}>{it.age}</span>
          </div>
          <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: '-.01em', marginTop: 11, lineHeight: 1.2 }}>{it.title}</div>
          <div style={{ fontSize: 12, color: 'var(--ink-mute)', marginTop: 2 }}>{it.line} · {it.carrier}</div>
          <div style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 8, lineHeight: 1.35, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{it.sub}</div>
          <div className="dsi-await-act dsi-press" onClick={() => onAct && onAct(it)}>
            <Icon name="arrow-up-right" size={16} /> {it.cta}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Glance grid (iOS-widget tiles) ───────────────────────────
function GlanceGrid({ tiles }) {
  return (
    <div className="dsi-glance">
      {tiles.map((t) => {
        const tv = toneVars(t.tone);
        return (
          <div className="dsi-tile dsi-press" key={t.key}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="dsi-tile-ic" style={{ background: tv.soft, color: tv.deep }}>
                <Icon name={t.icon} size={17} />
              </div>
            </div>
            <div>
              {t.kind === 'tiermix'
                ? <TierMix bars={t.bars} />
                : <div className="dsi-tile-val" style={{ color: tv.deep }}>{t.value}</div>}
              <div className="dsi-tile-lbl" style={{ marginTop: 7 }}>{t.label}</div>
              <div className="dsi-tile-sub">{t.sub}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Tier mix mini bar chart (tiers 1..5; lower = better = greener).
function TierMix({ bars }) {
  const max = Math.max(...bars, 1);
  const cols = ['var(--pos)', 'var(--pos)', 'var(--warn)', 'var(--neg)', 'var(--neg)'];
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 34 }}>
      {bars.map((b, i) => (
        <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
          <div style={{ width: '100%', height: Math.max(4, (b / max) * 30), background: cols[i], borderRadius: 3, opacity: b ? 1 : 0.25 }} />
          <span style={{ fontSize: 8.5, color: 'var(--ink-mute)', fontWeight: 700 }}>{i + 1}</span>
        </div>
      ))}
    </div>
  );
}

// ── Threads list ─────────────────────────────────────────────
function Chip({ tone, children, icon }) {
  const tv = toneVars(tone);
  return (
    <span className="dsi-chip" style={{ background: tv.soft, color: tv.deep }}>
      {icon && <Icon name={icon} size={11} />}{children}
    </span>
  );
}

function avatarColor(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return h;
}

function ThreadList({ threads, onOpen }) {
  return (
    <div className="dsi-card" style={{ overflow: 'hidden' }}>
      {threads.map((t) => {
        const h = avatarColor(t.who);
        return (
          <div className="dsi-thread" key={t.id} onClick={() => onOpen && onOpen(t)}>
            <div className="dsi-thread-av" style={{ background: `oklch(0.92 0.05 ${h})`, color: `oklch(0.42 0.11 ${h})` }}>
              {t.who.split(/[\s·]+/).slice(0, 2).map((w) => w[0]).join('')}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <span className="dsi-thread-who">{t.who}</span>
                <Chip tone={t.tone}>{t.label}</Chip>
              </div>
              <div className="dsi-thread-sub">{t.sub}</div>
              <div className="dsi-thread-ask">{t.ask}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Signal feed (timeline) ───────────────────────────────────
function SignalFeed({ events }) {
  return (
    <div style={{ padding: '2px 4px 0' }}>
      {events.map((e, i) => {
        const tv = toneVars(e.tone);
        const last = i === events.length - 1;
        return (
          <div className="dsi-evt" key={e.id}>
            <div className="dsi-evt-rail">
              <div className="dsi-evt-ic" style={{ background: tv.soft, color: tv.deep }}>
                <Icon name={e.icon} size={18} />
              </div>
              {!last && <div className="dsi-evt-line" />}
            </div>
            <div className="dsi-evt-body">
              <div className="dsi-evt-top">
                <span className="dsi-evt-title">{e.title}</span>
                <span className="dsi-evt-time">{e.time}</span>
              </div>
              <div className="dsi-evt-text">{e.text}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, {
  Icon, toneVars, MOBILE_CSS, Section, SignalHero, SignalRing, Sparkline,
  AwaitingRail, GlanceGrid, ThreadList, SignalFeed, Chip,
});
