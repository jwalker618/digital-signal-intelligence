/* global React, FrameReimag, Icon */

/* ============================================================
 * Coverages — All active policies grouped by line
 *
 * Layout
 *   row 1 — title + KPI strip
 *   row 2 — filter bar
 *   row 3 — per-line policy cards (one card per coverage line)
 * ============================================================ */

const ENT_C = 'Eastward Robotics';

function ReimCoverages({ isDark }) {
  const groups = [
    {
      line: 'Cyber', icon: 'shield-check',
      policies: [
        { carrier: 'Hartford Mutual', limit: '$10M / $10M',  retention: '$50k', score: 724, status: 'In review',     statusTone: 'spot',  premium: 185200, peer: '64th percentile', expires: '2026-04-15' },
      ],
    },
    {
      line: 'Professional Indemnity', icon: 'file-check',
      policies: [
        { carrier: 'Beazley',         limit: '$5M / $5M',    retention: '$25k', score: 758, status: 'Preferred',     statusTone: 'pos',   premium: 162000, peer: 'Top quartile',     expires: '2026-09-01' },
      ],
    },
    {
      line: 'Directors & Officers', icon: 'users',
      policies: [
        { carrier: 'Chubb',           limit: '$15M / $15M',  retention: '$100k', score: 648, status: 'Awaiting reply', statusTone: 'spot', premium: 140500, peer: 'Tracking peer cohort', expires: '2026-06-30' },
      ],
    },
  ];
  const totalPremium = groups.flatMap(g => g.policies).reduce((s, p) => s + p.premium, 0);

  return (
    <FrameReimag menu="Coverages" entity={ENT_C} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 18, height: '100%', alignContent: 'start' }}>

        {/* ROW 1 — title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Coverages</div>
            <h2 className="display" style={{ marginTop: 6 }}>Your active book at a glance</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              All policies currently in force, grouped by line. Status, peer standing, and the next action are surfaced for each.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, auto)', gap: 28 }}>
            <KpiPill label="Policies"        value="3" />
            <KpiPill label="Lines"           value="3" />
            <KpiPill label="Annual premium"  value={`$${(totalPremium / 1000).toFixed(0)}k`} />
            <KpiPill label="Awaiting you"    value="2" tone="spot" />
          </div>
        </div>

        {/* ROW 2 — filter bar */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className="micro" style={{ marginRight: 4 }}>Filter:</span>
          <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All lines</span>
          <span className="chip">Cyber</span>
          <span className="chip">PI</span>
          <span className="chip">D&O</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: by premium ↓</span>
        </div>

        {/* ROW 3 — per-line cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {groups.map((g) => (
            <div key={g.line} className="card" style={{ padding: 0, overflow: 'hidden' }}>
              {/* card header */}
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '14px 20px',
                borderBottom: '1px solid var(--rule)',
                background: 'var(--surface-elev)',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8,
                    background: 'var(--surface)', border: '1px solid var(--rule)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Icon name={g.icon} size={16} color="var(--ink)" />
                  </div>
                  <h3 style={{ font: '600 17px/1 IBM Plex Sans', margin: 0 }}>{g.line}</h3>
                  <span className="chip">{g.policies.length} polic{g.policies.length === 1 ? 'y' : 'ies'}</span>
                </div>
                <span className="caption">Total ${g.policies.reduce((s, p) => s + p.premium, 0).toLocaleString()}</span>
              </div>

              {/* policy rows */}
              {g.policies.map((p) => (
                <div key={p.carrier} style={{
                  display: 'grid',
                  gridTemplateColumns: '1.4fr 1fr 0.8fr 1fr 0.9fr 1fr 32px',
                  alignItems: 'center', gap: 16,
                  padding: '16px 20px',
                  borderTop: '1px solid var(--rule)',
                }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{p.carrier}</div>
                    <div className="micro">expires {p.expires}</div>
                  </div>
                  <div>
                    <div className="micro">Limit / Aggregate</div>
                    <div className="num-sm" style={{ fontSize: 13 }}>{p.limit}</div>
                  </div>
                  <div>
                    <div className="micro">Retention</div>
                    <div className="num-sm" style={{ fontSize: 13 }}>{p.retention}</div>
                  </div>
                  <div>
                    <div className="micro">Signal score</div>
                    <div className="num-sm info" style={{ fontSize: 18 }}>{p.score}</div>
                    <div className="micro">{p.peer}</div>
                  </div>
                  <div>
                    <span className={`chip chip-${p.statusTone}`}>{p.status}</span>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div className="micro">Premium</div>
                    <div className="num-sm" style={{ fontSize: 16, fontWeight: 700 }}>
                      ${(p.premium / 1000).toFixed(0)}k
                    </div>
                  </div>
                  <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
                </div>
              ))}
            </div>
          ))}
        </div>

      </div>
    </FrameReimag>
  );
}

function KpiPill({ label, value, tone = 'default' }) {
  const color = tone === 'spot' ? 'var(--spot)' : tone === 'pos' ? 'var(--pos)' : 'var(--ink)';
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num" style={{ fontSize: 22, color, fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>{value}</div>
    </div>
  );
}

Object.assign(window, { ReimCoverages, KpiPill });
