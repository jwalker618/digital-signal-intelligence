/* global React, Icon, WorkbenchShell */

/* ============================================================
 * Broker · Client Workbench — drill-down into a single client
 * from the Book of Clients. Mirrors the Carrier Submission
 * Workbench chrome (collapsed rail + 50% expand overlay,
 * drill-down tab tree, client-context topbar).
 *
 * Storyline client: Eastward Robotics, Inc. — the shared insured
 * across all personas. Three coverages (Cyber / PI / D&O) so the
 * per-client aggregation has something to chew on.
 * ============================================================ */

const CW = {
  entity:      'Eastward Robotics, Inc.',
  shortEntity: 'Eastward Robotics',
  industry:    'Industrial Robotics',
  naics:       '333999',
  vertical:    'Industrial Robotics',
  revenueBand: '$50M – $250M',
  country:     'United States',
  locations:   '2 states',
  employees:   420,
  domain:      'eastwardrobotics.com',
  firstSeen:   'Nov 2024',
  lastSeen:    'Apr 2026',
  broker:      'Marsh — Northeast Specialty',
  engagement:  78,
  engagementLabel: 'Active',
  lastMessage: '2h ago',
  avgResponseHours: 5,
  openQueries: 2,
  nextRenewalDays: 38,
  coverages: [
    { code: 'SUB-26-0118', line: 'Cyber', carrier: 'Hartford Mutual', score: 724, pure: 711, tier: 2, tierLabel: 'Standard',  decision: 'refer',   confidence: 86, percentile: 64, cohortMedian: 690, cohortTopDecile: 778, cohortSize: 142, premium: 185200, recommended: 185200, limit: 10_000_000, deductible: 50_000, status: 'In review',    statusTone: 'spot', signalCoverage: 92, awaiting: 'client', prevScore: 706 },
    { code: 'SUB-26-0119', line: 'PI',    carrier: 'Beazley',         score: 758, pure: 742, tier: 2, tierLabel: 'Preferred', decision: 'approve', confidence: 90, percentile: 79, cohortMedian: 705, cohortTopDecile: 790, cohortSize: 96,  premium: 162000, recommended: 162000, limit: 5_000_000,  deductible: 35_000, status: 'Bound',        statusTone: 'pos',  signalCoverage: 88, awaiting: null,     prevScore: 749 },
    { code: 'SUB-26-0120', line: 'D&O',   carrier: 'Chubb',           score: 648, pure: 631, tier: 4, tierLabel: 'Watch',     decision: 'refer',   confidence: 74, percentile: 42, cohortMedian: 672, cohortTopDecile: 744, cohortSize: 88,  premium: 140500, recommended: 152000, limit: 10_000_000, deductible: 75_000, status: 'Awaiting docs', statusTone: 'spot', signalCoverage: 79, awaiting: 'broker', prevScore: 654 },
  ],
};
CW.totalPremium = CW.coverages.reduce((s, c) => s + c.premium, 0);
CW.avgScore = Math.round(CW.coverages.reduce((s, c) => s + c.score, 0) / CW.coverages.length);

/* Drill-down nav — grouped tab tree */
const CW_NAV = [
  { kind: 'leaf',  name: 'Summary', icon: 'gauge' },
  { kind: 'group', name: 'Coverages', icon: 'shield-check',
    children: [
      { name: 'Coverage List',   icon: 'list-checks' },
      { name: 'Premium Build-up', icon: 'calculator' },
      { name: 'Risk Terms',      icon: 'scale' },
    ] },
  { kind: 'group', name: 'Risk Signals', icon: 'chart-no-axes-gantt',
    children: [
      { name: 'Score & Cohort',   icon: 'trending-up-down' },
      { name: 'Loss Profile',     icon: 'shield-alert' },
      { name: 'Exposure Profile', icon: 'globe' },
    ] },
  { kind: 'group', name: 'Engagement', icon: 'messages-square',
    children: [
      { name: 'Communications',        icon: 'messages-square' },
      { name: 'Opportunities & Risks', icon: 'lightbulb' },
    ] },
  { kind: 'leaf',  name: 'Pipeline & Renewals', icon: 'calendar-clock' },
];

/* tierColor / decisionTone now come from primitives.jsx (shared). */

/* ============================================================
 * Client workbench frame — thin config over the shared
 * <WorkbenchShell> primitive (primitives.jsx).
 * ============================================================ */
function ClientWorkbenchFrame({ active, children, isDark }) {
  const lead = (
    <React.Fragment>
      <span style={{ color: 'var(--ink-mute)' }}>/</span>
      {/* Identity cluster — single row so chips align with the breadcrumb. */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
        <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink)' }}>{CW.entity}</span>
        <span className="chip" style={{ fontSize: 11 }}>{CW.industry}</span>
        <span className="chip chip-info" style={{ fontSize: 11 }}>{CW.coverages.length} coverages</span>
      </div>
    </React.Fragment>
  );
  return (
    <WorkbenchShell
      nav={CW_NAV}
      active={active}
      isDark={isDark}
      backLabel="Book"
      account={{ initials: 'SA', name: 'Sasha Alvarez', email: 'sasha.alvarez@marsh.com' }}
      scope={{ label: 'Client', lines: [CW.entity, `${CW.coverages.length} coverages · $${(CW.totalPremium / 1000).toFixed(0)}k premium`] }}
      lead={lead}
      contextStats={[
        { label: 'Total premium', value: `$${(CW.totalPremium / 1000).toFixed(0)}k`, tone: 'info' },
        { label: 'Avg score', value: CW.avgScore },
        { label: 'Engagement', value: CW.engagementLabel },
      ]}
    >
      {children}
    </WorkbenchShell>
  );
}

Object.assign(window, { ClientWorkbenchFrame, CW, CW_NAV });
