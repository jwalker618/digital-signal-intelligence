/* global React, FrameReimag, Icon, Sparkline, Dial */

const E2 = 'Eastward Robotics';

/* ──────────────────────────────────────────────────────────────
 * 3. Action Plan (reimagined) — hero action + supporting cards
 * ────────────────────────────────────────────────────────────── */
function ReimActions({ isDark }) {
  const top = {
    headline: 'Commission a SOC 2 Type II audit',
    signal: 'No SOC 2 Type II on file',
    delta: 18200, pct: 9.8, effort: 'HIGH',
    duration: '4-6 months', cost: '$45k-90k', leverage: 47,
    why: "Carriers in your tier weight third-party attestation heavily. Roughly 78% of top-decile peers in your cohort hold a current SOC 2 Type II.",
    evidence: 'Final report or bridge letter from a Big-4 / qualified auditor.'
  };
  const others = [
  { headline: 'Verify backup encryption end-to-end', signal: 'Backup encryption unverified', delta: 11400, effort: 'LOW', duration: '2-4 weeks', leverage: 132 },
  { headline: 'Eliminate public-facing RDP', signal: 'Public-facing RDP detected', delta: 6200, effort: 'MEDIUM', duration: '4-8 weeks', leverage: 78 },
  { headline: 'Author + tabletop an IR playbook', signal: 'IR playbook not documented', delta: 4900, effort: 'MEDIUM', duration: '6-10 weeks', leverage: 62 }];

  const effortChip = (e) =>
  e === 'LOW' ? 'chip chip-pos' :
  e === 'MEDIUM' ? 'chip chip-warn' :
  'chip chip-neg';

  return (
    <FrameReimag menu="Action Plan" entity={E2} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto 1fr', gap: 18, height: '100%' }}>
        {/* Title strip */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Action plan</div>
            <h2 className="display" style={{ marginTop: 6 }}>
              Four moves to take <span className="info">$40.7k</span> off your renewal
            </h2>
            <div className="body" style={{ marginTop: 8, maxWidth: 520 }}>
              Prioritised by leverage — the premium impact divided by the effort to deliver it. Click any action for evidence requirements and references.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 24 }}>
            <div style={{ textAlign: 'right' }}>
              <div className="micro">total impact</div>
              <div className="num info">−$40.7k</div>
            </div>
            <div className="divider" />
            <div style={{ textAlign: 'right' }}>
              <div className="micro">low-effort wins</div>
              <div className="num pos">1</div>
            </div>
          </div>
        </div>

        {/* Hero action — INFO teal (it's the recommendation we want them to focus on,
             not an urgent thing they must do today) */}
        <div className="card-info" style={{ padding: 28, display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 28 }}>
          <div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 10 }}>
              <span className="chip chip-info">#1 BIGGEST LEVER</span>
              <span className={effortChip(top.effort)}>{top.effort} EFFORT</span>
            </div>
            <h2 className="huge" style={{ marginTop: 4 }}>{top.headline}</h2>
            <div className="body" style={{ marginTop: 10, fontSize: 14 }}>{top.why}</div>
            <div style={{ display: 'flex', gap: 32, marginTop: 18, paddingTop: 16, borderTop: '1px solid var(--rule)' }}>
              <div>
                <div className="micro">typical duration</div>
                <div className="num-sm" style={{ marginTop: 2 }}>{top.duration}</div>
              </div>
              <div>
                <div className="micro">approx. cost</div>
                <div className="num-sm" style={{ marginTop: 2 }}>{top.cost}</div>
              </div>
              <div>
                <div className="micro">leverage score</div>
                <div className="num-sm" style={{ marginTop: 2 }}>{top.leverage}</div>
              </div>
            </div>
            <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
              <button className="btn info">Discuss with broker</button>
              <button className="btn ghost">View references</button>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>If you close this gap</div>
              <div style={{ marginTop: 8 }}>
                <span className="num-xl pos">−$18.2k</span>
                <span className="num" style={{ color: 'var(--ink-soft)' }}> /yr</span>
              </div>
              <div className="caption" style={{ marginTop: 4 }}>9.8% off your cyber premium</div>
            </div>
            <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 14, marginTop: 14 }}>
              <div className="micro">Evidence required</div>
              <div style={{ fontSize: 13, marginTop: 4 }}>{top.evidence}</div>
            </div>
          </div>
        </div>

        {/* Supporting actions */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, alignItems: 'stretch' }}>
          {others.map((a, i) =>
          <div key={i} className="card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <span className="chip">#{i + 2}</span>
                <span className={effortChip(a.effort)}>{a.effort}</span>
              </div>
              <h3 style={{ font: '600 17px/1.25 IBM Plex Sans', margin: 0, color: 'var(--ink)' }}>{a.headline}</h3>
              <div className="caption" style={{ marginTop: 6 }}>{a.signal}</div>
              <div style={{ marginTop: 'auto', paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid var(--rule)' }}>
                <div>
                  <div className="micro">savings</div>
                  <div className="num pos">−${(a.delta / 1000).toFixed(1)}k</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="micro">leverage · {a.leverage}</div>
                  <div className="caption">{a.duration}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </FrameReimag>);

}

/* ──────────────────────────────────────────────────────────────
 * 4. Industry Benchmarks (reimagined) — bell curve + signal gaps
 * ────────────────────────────────────────────────────────────── */
function ReimPeers({ isDark }) {
  // Bell curve approximation
  const mean = 720,sd = 50;
  const W = 720,H = 200;
  const xs = [];
  for (let i = 0; i <= 60; i++) xs.push(mean - 3 * sd + 6 * sd * (i / 60));
  const ys = xs.map((x) => Math.exp(-0.5 * Math.pow((x - mean) / sd, 2)));
  const maxY = Math.max(...ys);
  const path = ys.map((y, i) => {
    const px = i / 60 * W;
    const py = H - y / maxY * (H - 30);
    return `${i === 0 ? 'M' : 'L'}${px.toFixed(1)},${py.toFixed(1)}`;
  }).join(' ');
  const subjectX = (724 - (mean - 3 * sd)) / (6 * sd) * W;
  const medianX = (714 - (mean - 3 * sd)) / (6 * sd) * W;
  const topX = (784 - (mean - 3 * sd)) / (6 * sd) * W;

  const peers = [
  { name: 'SOC 2 Type II audit', you: false, pct: 78 },
  { name: '24/7 SOC monitoring', you: false, pct: 72 },
  { name: 'Documented IR playbook', you: false, pct: 68 },
  { name: 'Verified backup encryption', you: false, pct: 65 },
  { name: 'MFA on admin accounts', you: true, pct: 88 },
  { name: 'EDR coverage > 95%', you: true, pct: 79 }];


  return (
    <FrameReimag menu="Industry Benchmarks" entity={E2} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto 1fr', gap: 18, height: '100%' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Industry benchmarks</div>
            <h2 className="display" style={{ marginTop: 6 }}>
              How you compare to 38 peers in your cohort
            </h2>
            <div className="caption" style={{ marginTop: 6 }}>
              USA · Industrial machinery (NAICS 333) · revenue 50-250M · cyber line
            </div>
          </div>
          <div style={{ display: 'flex', gap: 16 }}>
            <div className="card-info" style={{ padding: '12px 18px', borderRadius: 12 }}>
              <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>You</div>
              <div className="num" style={{ color: 'var(--info-deep)' }}>724</div>
            </div>
            <div className="card" style={{ padding: '12px 18px' }}>
              <div className="eyebrow">cohort median</div>
              <div className="num">714</div>
            </div>
            <div className="card" style={{ padding: '12px 18px' }}>
              <div className="eyebrow">top decile</div>
              <div className="num">784</div>
            </div>
          </div>
        </div>

        {/* Bell curve */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: 0 }}>Distribution of cohort scores</h3>
            <span className="caption">Your position highlighted</span>
          </div>
          <svg width={W} height={H + 30} viewBox={`0 0 ${W} ${H + 30}`}>
            {/* shaded region under curve */}
            <path d={`${path} L${W},${H} L0,${H} Z`} fill="var(--surface-sunken)" />
            <path d={path} fill="none" stroke="var(--ink-soft)" strokeWidth="1.5" />
            {/* gridlines */}
            {[570, 620, 670, 720, 770, 820, 870].map((s) => {
              const x = (s - (mean - 3 * sd)) / (6 * sd) * W;
              return (
                <g key={s}>
                  <line x1={x} y1={H} x2={x} y2={H + 4} stroke="var(--ink-mute)" />
                  <text x={x} y={H + 18} textAnchor="middle" style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{s}</text>
                </g>);

            })}
            {/* median marker */}
            <line x1={medianX} y1={0} x2={medianX} y2={H} stroke="var(--ink-mute)" strokeDasharray="3 3" />
            <text x={medianX} y={14} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--ink-mute)' }}>median</text>
            {/* top decile */}
            <line x1={topX} y1={0} x2={topX} y2={H} stroke="var(--pos)" strokeDasharray="3 3" />
            <text x={topX} y={14} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--pos)' }}>top decile</text>
            {/* subject marker */}
            {/* subject marker — INFO teal for "this is you" */}
            <line x1={subjectX} y1={0} x2={subjectX} y2={H} stroke="var(--info)" strokeWidth="2" />
            <circle cx={subjectX} cy={H - Math.exp(-0.5 * Math.pow((724 - mean) / sd, 2)) / maxY * (H - 30)} r="6" fill="var(--info)" stroke="var(--surface)" strokeWidth="2" />
            <rect x={subjectX - 38} y={H - 70} width={76} height={32} fill="var(--info)" rx="6" />
            <text x={subjectX} y={H - 50} textAnchor="middle" style={{ font: '600 13px IBM Plex Sans', fill: '#fff' }}>YOU · 724</text>
            <text x={subjectX} y={H - 36} textAnchor="middle" style={{ font: '10px IBM Plex Sans', fill: 'var(--info-soft)' }}>64th percentile</text>
          </svg>
          <div className="body" style={{ marginTop: 4 }}>
            You're outperforming the typical peer — <span className="info" style={{ fontWeight: 600 }}>60 points of headroom</span> separate you from the top-decile profile.
          </div>
        </div>

        {/* Signal-by-signal */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: 0 }}>Where your peers pull ahead — and where you do</h3>
              <div className="caption" style={{ marginTop: 4 }}>% of top-decile peers with the practice in place</div>
            </div>
            <span className="chip chip-info">your gaps highlighted</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            {peers.map((p) =>
            <div key={p.name}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                  <span style={{ fontSize: 13 }}>
                    {p.you ?
                  <span className="chip chip-pos" style={{ marginRight: 6 }}><Icon name="check" size={10} /> you</span> :

                  <span className="chip chip-info" style={{ marginRight: 6 }}>gap</span>
                  }
                    {p.name}
                  </span>
                  <span className="num-sm">{p.pct}%</span>
                </div>
                <div style={{ height: 8, background: 'var(--surface-sunken)', borderRadius: 4, overflow: 'hidden', position: 'relative' }}>
                  <div style={{
                  width: `${p.pct}%`, height: '100%',
                  background: p.you ? 'var(--pos)' : 'var(--info)'
                }} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </FrameReimag>);

}

Object.assign(window, { ReimActions, ReimPeers });