/* global React, FrameReimag, Icon, LossOutlookCard, ExposureCard,
   useCoverage, PageHead, OppByLineBar, StatusChip,
   CLIENT_LINES, CLIENT_PORTFOLIO, lineByKey, kMoney */

/* ============================================================
 * Risk Insights — premium decomposed to the signal, per coverage.
 *
 *   All   → book totals + a premium build-up row per line
 *   line  → that line's full base→bound waterfall + loss/exposure
 *
 * Each line's neutral "base" is derived so the waterfall reconciles:
 *   base − strengths + opportunity = final (bound) premium.
 * ============================================================ */

const E = 'Eastward Robotics';

/* sum helpers + derived base for a line. */
function lineMath(line) {
  const strengths = line.helping.reduce((s, h) => s + h[1], 0);
  const opp = line.opportunity.reduce((s, o) => s + o[1], 0);
  const base = line.premium + strengths - opp;
  return { strengths, opp, base, final: line.premium };
}

function ReimDrivers({ isDark }) {
  const [cov, setCov] = useCoverage('all');
  const line = cov === 'all' ? null : lineByKey(cov);
  const title = cov === 'all' ? 'Your premium, broken down by line' : `${line.line} — premium to the signal`;
  const sub = cov === 'all'
    ? 'Every line decomposed from a neutral base to its bound premium. Pick a coverage for its full signal-by-signal waterfall.'
    : line.cohortLabel;

  return (
    <FrameReimag menu="Risk Insights" entity={E} isDark={isDark}>
      <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 16, height: '100%', alignContent: 'start' }}>
        <PageHead eyebrow="Risk insights" title={title} sub={sub} active={cov} onChange={setCov} />
        {cov === 'all' ? <DriversPortfolio onPick={setCov} /> : <DriversLine line={line} />}
      </div>
    </FrameReimag>
  );
}

/* ════════════════════════ PORTFOLIO (All) ════════════════════════ */
function DriversPortfolio({ onPick }) {
  const P = CLIENT_PORTFOLIO;
  const math = CLIENT_LINES.map((l) => ({ line: l, ...lineMath(l) }));
  const baseSum = math.reduce((s, m) => s + m.base, 0);
  const strengthsSum = math.reduce((s, m) => s + m.strengths, 0);
  const maxFinal = Math.max(...math.map((m) => m.final));

  return (
    <React.Fragment>
      {/* book-total headline cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        <div className="card">
          <div className="eyebrow">Base premium</div>
          <div className="num" style={{ marginTop: 6 }}>${baseSum.toLocaleString()}</div>
          <div className="caption">Neutral, before signals · {P.lineCount} lines</div>
        </div>
        <div className="card-pos">
          <div className="eyebrow" style={{ color: 'var(--pos)' }}>Strengths</div>
          <div className="num pos" style={{ marginTop: 6 }}>−{kMoney(strengthsSum)}</div>
          <div className="caption">Signals lowering premium across the book</div>
        </div>
        <div className="card-spot">
          <div className="eyebrow" style={{ color: 'var(--spot)' }}>Opportunity</div>
          <div className="num" style={{ marginTop: 6, color: 'var(--spot-deep)' }}>+{kMoney(P.totalOpp)}</div>
          <div className="caption">{P.totalActions} signals to act on</div>
        </div>
        <div className="card-info">
          <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Final premium</div>
          <div className="num" style={{ marginTop: 6, color: 'var(--info-deep)' }}>${P.totalPremium.toLocaleString()}</div>
          <div className="caption">As bound across 3 carriers</div>
        </div>
      </div>

      {/* premium build-up by line */}
      <div className="card" style={{ padding: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
          <div>
            <div className="eyebrow">Premium build-up by line</div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>From base to bound, line by line</h3>
          </div>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <LegendDot color="var(--pos)" label="Strengths" />
            <LegendDot color="var(--spot)" label="Opportunity" />
            <LegendDot color="var(--ink)" label="Bound premium" />
          </div>
        </div>
        <div>
          {math.map((m) => <LineBuildupRow key={m.line.key} m={m} maxFinal={maxFinal} onPick={onPick} />)}
        </div>
      </div>

      {/* book-level loss / exposure / next move */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        <LossOutlookCard
          band="Moderate" trend="Mixed"
          quarters={[0, 0, 0.4, 0, 0, 0.5, 0, 0.6, 0, 0.4, 0.5, 0]}
          quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
          frequency={{ value: 37, cohort: 44 }}
          severity={{ value: 44, cohort: 47 }}
        />
        <ExposureCard value={P.aggExposure} yoy="+12%" band="large" sub="3 lines · multi-entity" />
        <div className="card-spot" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div>
              <div className="eyebrow" style={{ color: 'var(--spot)' }}>Your next move</div>
              <div className="num-sm" style={{ fontSize: 20, color: 'var(--spot-deep)', marginTop: 4 }}>−{kMoney(P.totalOpp)} available</div>
            </div>
            <span className="chip chip-spot">{P.totalActions} actions</span>
          </div>
          <div className="caption">
            {P.weakLine.short} holds the largest single opportunity and the lowest score. Start there — it moves the book most.
          </div>
          <div style={{ marginTop: 'auto', display: 'flex', gap: 8 }}>
            <button className="btn spot" onClick={() => onPick(P.weakLine.key)}>Open {P.weakLine.short} →</button>
            <button className="btn ghost">Export PDF</button>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

function LegendDot({ color, label }) {
  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: 6 }} className="micro">
      <span style={{ width: 10, height: 10, background: color, borderRadius: 2 }} /> {label}
    </span>
  );
}

/* One line's base→bound build-up as a compact row with a proportional bar. */
function LineBuildupRow({ m, maxFinal, onPick }) {
  const { line, base, strengths, opp, final } = m;
  const pct = (v) => `${(v / maxFinal) * 100}%`;
  return (
    <div
      onClick={() => onPick(line.key)}
      style={{ display: 'grid', gridTemplateColumns: '170px 1fr 96px 24px', gap: 18, alignItems: 'center', padding: '16px 0', borderTop: '1px solid var(--rule)', cursor: 'pointer' }}
    >
      {/* identity */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface-elev)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name={line.icon} size={16} color="var(--ink)" />
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600 }}>{line.short}</div>
          <div className="micro">base ${(base / 1000).toFixed(0)}k</div>
        </div>
      </div>

      {/* proportional bar: bound premium with the addressable opportunity highlighted */}
      <div>
        <div style={{ position: 'relative', height: 26, background: 'var(--surface-sunken)', borderRadius: 6, overflow: 'hidden' }}>
          {/* bound premium fill */}
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: pct(final), background: 'color-mix(in srgb, var(--ink) 16%, transparent)' }} />
          {/* opportunity (addressable) portion at the right edge of the fill */}
          <div style={{ position: 'absolute', top: 0, bottom: 0, width: pct(opp), left: `calc(${pct(final)} - ${pct(opp)})`, background: 'var(--spot)', opacity: 0.85 }} />
          {/* strengths already-saved marker */}
          <div style={{ position: 'absolute', top: 0, bottom: 0, width: 3, left: pct(final), background: 'var(--ink)' }} />
        </div>
        <div style={{ display: 'flex', gap: 14, marginTop: 6 }}>
          <span className="micro" style={{ color: 'var(--pos)' }}>−{kMoney(strengths)} strengths</span>
          <span className="micro" style={{ color: 'var(--spot-deep)' }}>+{kMoney(opp)} opportunity</span>
          <span className="micro">{line.opportunity.length} open signal{line.opportunity.length === 1 ? '' : 's'}</span>
        </div>
      </div>

      {/* final premium */}
      <div style={{ textAlign: 'right' }}>
        <div className="num-sm" style={{ fontSize: 17, fontWeight: 700 }}>${(final / 1000).toFixed(0)}k</div>
        <div className="micro">bound</div>
      </div>

      <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
    </div>
  );
}

/* ════════════════════════ SINGLE LINE ════════════════════════ */
function DriversLine({ line }) {
  const { base, strengths, opp, final } = lineMath(line);

  // waterfall items: base → strengths (down) → opportunity (up) → final
  const items = [
    { label: 'Base', value: base, type: 'base' },
    ...line.helping.map((h) => ({ label: h[0], value: -h[1], type: 'pos' })),
    ...line.opportunity.map((o) => ({ label: o[0], value: o[1], type: 'opp' })),
    { label: 'Final', value: final, type: 'final' },
  ];
  let running = 0;
  const bars = items.map((it) => {
    if (it.type === 'base') { const b = { ...it, lo: 0, hi: it.value }; running = it.value; return b; }
    if (it.type === 'final') return { ...it, lo: 0, hi: it.value };
    const lo = it.value > 0 ? running : running + it.value;
    const hi = it.value > 0 ? running + it.value : running;
    running += it.value;
    return { ...it, lo, hi };
  });
  const maxY = Math.max(...bars.map((b) => b.hi));
  const W = 1180, H = 220, barW = W / bars.length - 14;
  const worsening = /wors/i.test(line.loss.trend);

  return (
    <React.Fragment>
      {/* headline math cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        <div className="card">
          <div className="eyebrow">Base premium</div>
          <div className="num" style={{ marginTop: 6 }}>${base.toLocaleString()}</div>
          <div className="caption">Industry × revenue × limit</div>
        </div>
        <div className="card-pos">
          <div className="eyebrow" style={{ color: 'var(--pos)' }}>Strengths</div>
          <div className="num pos" style={{ marginTop: 6 }}>−{kMoney(strengths)}</div>
          <div className="caption">{line.helping.length} signals lowering your premium</div>
        </div>
        <div className="card-spot">
          <div className="eyebrow" style={{ color: 'var(--spot)' }}>Opportunity</div>
          <div className="num" style={{ marginTop: 6, color: 'var(--spot-deep)' }}>{opp > 0 ? '+' + kMoney(opp) : '—'}</div>
          <div className="caption">{line.opportunity.length ? `${line.opportunity.length} signals to act on` : 'no open signals'}</div>
        </div>
        <div className="card-info">
          <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Final premium</div>
          <div className="num" style={{ marginTop: 6, color: 'var(--info-deep)' }}>${final.toLocaleString()}</div>
          <div className="caption">As quoted by {line.carrier}</div>
        </div>
      </div>

      {/* waterfall */}
      <div className="card" style={{ padding: 22 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <div>
            <div className="eyebrow">Premium build-up</div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>From base to bound — every {line.short} signal accounted for</h3>
          </div>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <LegendDot color="var(--pos)" label="Strengths" />
            <LegendDot color="var(--spot)" label="Opportunity" />
            <LegendDot color="var(--ink)" label="Premium" />
          </div>
        </div>
        <svg width="100%" viewBox={`0 0 ${W} ${H + 32}`} style={{ display: 'block' }}>
          <defs>
            <linearGradient id="anchor-bar" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--ink)" stopOpacity="0.18" />
              <stop offset="100%" stopColor="var(--ink)" stopOpacity="0.78" />
            </linearGradient>
          </defs>
          {bars.map((b, i) => {
            const x = i * (W / bars.length) + 8;
            const yScale = H / maxY;
            const y = H - b.hi * yScale;
            const h = (b.hi - b.lo) * yScale;
            const isAnchor = b.type === 'base' || b.type === 'final';
            const fill = isAnchor ? 'url(#anchor-bar)' : b.type === 'pos' ? 'var(--pos)' : 'var(--spot)';
            return (
              <g key={i}>
                <rect x={x} y={y} width={barW} height={h} fill={fill} rx="3" />
                <text x={x + barW / 2} y={y - 6} textAnchor="middle" style={{ font: '600 12px IBM Plex Sans', fill: 'var(--ink)' }}>
                  {b.type === 'pos' ? `−$${(Math.abs(b.value) / 1000).toFixed(1)}k` : b.type === 'opp' ? `+$${(b.value / 1000).toFixed(1)}k` : `$${(b.value / 1000).toFixed(0)}k`}
                </text>
                <text x={x + barW / 2} y={H + 18} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--ink-soft)' }}>
                  {b.label.length > 16 ? b.label.slice(0, 14) + '…' : b.label}
                </text>
              </g>
            );
          })}
          {bars.slice(0, -1).map((b, i) => {
            const next = bars[i + 1];
            if (next.type === 'final') return null;
            const x1 = i * (W / bars.length) + 8 + barW;
            const x2 = (i + 1) * (W / bars.length) + 8;
            const yScale = H / maxY;
            const y = H - b.hi * yScale;
            return <line key={`c-${i}`} x1={x1} y1={y} x2={x2} y2={y} stroke="var(--ink-mute)" strokeDasharray="3 3" strokeWidth="1" />;
          })}
        </svg>
      </div>

      {/* loss / exposure / next move */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        <LossOutlookCard
          band={line.loss.band} trend={line.loss.trend}
          quarters={line.loss.quarters} quarterLabels={['23 Q1', '24 Q1', '25 Q1']}
          frequency={line.loss.frequency} severity={line.loss.severity}
        />
        <ExposureCard value={line.exposure.value} yoy={line.exposure.yoy} band={line.exposure.band} sub={line.exposure.sub} />

        {opp > 0 ? (
          <div className="card-spot" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow" style={{ color: 'var(--spot)' }}>Your next move</div>
                <div className="num-sm" style={{ fontSize: 20, color: 'var(--spot-deep)', marginTop: 4 }}>−{kMoney(opp)} available</div>
              </div>
              <span className="chip chip-spot">{line.opportunity.length} actions</span>
            </div>
            <div className="caption">
              {line.note || `The ${line.opportunity.length} opportunity signals above are each linked to a concrete remediation, prioritised by leverage (impact ÷ effort).`}
            </div>
            <div style={{ marginTop: 'auto', display: 'flex', gap: 8 }}>
              <button className="btn spot">See action plan →</button>
              <button className="btn ghost">Export PDF</button>
            </div>
          </div>
        ) : (
          <div className="card-pos" style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>
            <div className="eyebrow" style={{ color: 'var(--pos)' }}>No open signals</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 4 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--pos-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="badge-check" size={22} color="var(--pos)" />
              </div>
              <div style={{ font: '600 16px/1.3 IBM Plex Sans' }}>{line.short} is already optimised</div>
            </div>
            <div className="caption" style={{ marginTop: 'auto' }}>
              {line.note || 'This line is preferred — there are no opportunity signals left to act on.'}
            </div>
            <button className="btn ghost">Export PDF</button>
          </div>
        )}
      </div>
    </React.Fragment>
  );
}

Object.assign(window, { ReimDrivers });
