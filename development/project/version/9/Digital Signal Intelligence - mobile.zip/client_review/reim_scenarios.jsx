/* global React, FrameReimag, Icon */

/* ============================================================
 * Scenarios — Four kinds of what-ifs
 *   1. Improve a signal  (close opportunity → score + premium impact)
 *   2. Adjust limit      (lower limit cheaper, higher more)
 *   3. Add a coverage    (indicative new-line ranges)
 *   4. Restructure tower (primary+excess splits)
 * ============================================================ */

const ENT_S = 'Eastward Robotics';

function ReimScenarios({ isDark }) {
  return (
    <FrameReimag menu="Scenarios" entity={ENT_S} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title */}
        <div>
          <div className="eyebrow">Scenarios</div>
          <h2 className="display" style={{ marginTop: 6 }}>Explore what would happen</h2>
          <div className="body" style={{ marginTop: 8, maxWidth: 720 }}>
            Heuristic estimates intended to support conversation with your broker. Actual pricing
            is set by your carrier at placement and depends on full underwriting context.
          </div>
        </div>

        {/* 2-col grid — scenario cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>

          <ScenarioCard
            kind="signal"
            title="Improve a signal"
            subtitle="Close one of the 4 opportunity signals — see how it would move your score and premium."
            rows={[
              { label: 'SOC 2 Type II',       sub: 'High effort',   delta: '−$18.2k', score: '724 → 735' },
              { label: 'Backup encryption',   sub: 'Low effort',    delta: '−$11.4k', score: '724 → 731' },
              { label: 'Public RDP exposed',  sub: 'Medium effort', delta: '−$6.2k',  score: '724 → 728' },
              { label: 'IR playbook',         sub: 'Medium effort', delta: '−$4.9k',  score: '724 → 727' },
            ]}
            footer={{ label: 'Close all four', delta: '−$40.7k', score: '724 → 748' }}
          />

          <ScenarioCard
            kind="limit"
            title="Adjust your limit"
            subtitle="Cyber, your primary line. Two carrier-recommended alternatives:"
            rows={[
              { label: 'Minimum adequate',    sub: 'Drop to $5M limit',   delta: '−$36.8k', deltaTone: 'pos', score: 'Current $185.2k → $148.4k' },
              { label: 'Best-value',          sub: 'Lift to $25M limit',  delta: '+$29.7k', deltaTone: 'neg', score: 'Current $185.2k → $214.9k' },
            ]}
            note="Best-value gives better cost-per-dollar-of-coverage; minimum adequate is the cheapest acceptable to your carrier's appetite."
          />

          <ScenarioCard
            kind="add"
            title="Add a new coverage line"
            subtitle="Indicative ranges based on your industry and revenue band."
            rows={[
              { label: 'Property',                        sub: 'Common in your cohort', delta: '$70k – $220k',  deltaTone: 'mute' },
              { label: 'General Liability',               sub: 'Common in your cohort', delta: '$130k – $320k', deltaTone: 'mute' },
              { label: 'Product Liability',               sub: 'Often added',           delta: '$95k – $250k',  deltaTone: 'mute' },
              { label: 'Crime',                           sub: 'Sometimes added',       delta: '$40k – $95k',   deltaTone: 'mute' },
            ]}
          />

          <ScenarioCard
            kind="tower"
            title="Restructure your tower"
            subtitle="Splitting a single-line tower into primary + excess can reduce total premium by 7–10%."
            rows={[
              { label: 'Current — single tower',          sub: '$10M with one carrier',           delta: '$185,200',  deltaTone: 'mute' },
              { label: '60 / 40 split',                    sub: 'Lead carrier + excess',           delta: '−$13.0k',   score: '$172.2k total' },
              { label: '50 / 50 split',                    sub: 'Two equal layers',                delta: '−$16.7k',   score: '$168.5k total' },
            ]}
          />
        </div>

        {/* footer info */}
        <div style={{
          padding: '14px 18px',
          border: '1px solid var(--rule)',
          borderRadius: 10,
          background: 'var(--surface-sunken)',
          display: 'flex', alignItems: 'flex-start', gap: 12,
        }}>
          <Icon name="info" size={18} color="var(--ink-soft)" style={{ marginTop: 1, flexShrink: 0 }} />
          <div className="caption" style={{ lineHeight: 1.5 }}>
            Scenario estimates use your current carrier's pricing model and assume all other
            signals stay constant. To turn any of these into a firm quote, send the scenario to
            your broker from the action menu (...) on the row.
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function ScenarioCard({ kind, title, subtitle, rows, footer, note }) {
  const icons = { signal: 'list-checks', limit: 'sliders-horizontal', add: 'plus-circle', tower: 'layers' };
  return (
    <div className="card" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 14 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 8,
          background: 'var(--surface-elev)', border: '1px solid var(--rule)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <Icon name={icons[kind]} size={18} color="var(--ink)" />
        </div>
        <div style={{ flex: 1 }}>
          <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: 0 }}>{title}</h3>
          <div className="caption" style={{ marginTop: 4 }}>{subtitle}</div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map((r, i) => (
          <ScenarioRow key={i} {...r} />
        ))}
        {footer && (
          <div style={{ marginTop: 4 }}>
            <ScenarioRow {...footer} deltaTone="pos" emphasised />
          </div>
        )}
      </div>
      {note && <div className="caption" style={{ marginTop: 12 }}>{note}</div>}
    </div>
  );
}

function ScenarioRow({ label, sub, delta, score, deltaTone, emphasised }) {
  const tone = deltaTone || (delta?.startsWith('−') ? 'pos' : delta?.startsWith('+') ? 'neg' : 'info');
  const toneClass = tone === 'mute' ? '' : tone;
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr auto',
      gap: 16, alignItems: 'center',
      padding: '10px 0',
      borderTop: emphasised ? '2px solid var(--ink)' : '1px solid var(--rule)',
    }}>
      <div>
        <div style={{ fontSize: 13.5, fontWeight: emphasised ? 700 : 500 }}>{label}</div>
        {sub && <div className="micro" style={{ marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{ textAlign: 'right' }}>
        <div className={`num-sm ${toneClass}`} style={{
          fontSize: emphasised ? 18 : 15,
          fontVariantNumeric: 'tabular-nums',
          color: tone === 'mute' ? 'var(--ink)' : undefined,
        }}>{delta}</div>
        {score && <div className="micro" style={{ marginTop: 2 }}>{score}</div>}
      </div>
    </div>
  );
}

Object.assign(window, { ReimScenarios });
