/* global React, FrameReimag, Icon, ScoreHistory, CohortBar, PremiumBreakdown, Sparkline */

/* ============================================================
 * Overview — reimagined v2
 *
 * Layout
 *   row 1 — hero strip: SCORE / PREMIUM / AWAITING-YOU       (3 equal)
 *   row 2 — analytics:  SIGNAL PULSE / COHORT STANDING       (2 equal)
 *   row 3 — footer:     LOSS OUTLOOK / EXPOSURE / COVERAGE   (3 equal)
 *
 * Color discipline
 *   • info teal  — neutral hero facts (score, premium, charts)
 *   • coral spot — awaiting-you / urgent ONLY (the right hero card)
 *   • pos green  — value-positive deltas (above median, savings)
 *   • aux blue   — secondary informative (exposure)
 *   • opportunity in Signal Pulse uses INFO TEAL (it's a call to
 *     review, not a "bad" thing) — strengths stay green
 * ============================================================ */

const ENT = 'Eastward Robotics';

function ReimOverview({ isDark }) {
  // — score state ----------------------------------------------
  const score = 724;
  const prev = 706;
  const median = 714;
  const vsMedian = score - median;
  const vsPrev = score - prev;
  const scoreHist = [
  { label: 'Q1 ’25', value: 692 },
  { label: 'Q2 ’25', value: 705 },
  { label: 'Q3 ’25', value: 712 },
  { label: 'last quote', value: 706, marker: 'prev' },
  { label: 'now', value: 724 }];


  // — premium book --------------------------------------------
  const policies = [
  { name: 'Cyber', amount: 185200, color: 'var(--info)' },
  { name: 'PI', amount: 162000, color: 'var(--aux)' },
  { name: 'D&O', amount: 140500, color: 'var(--ink-soft)' }
  // — uncomment to see overflow behaviour ——
  // { name: 'Property', amount: 92000, color: 'var(--warn)' },
  // { name: 'GL',       amount: 64000, color: 'var(--info-deep)' },
  ];

  return (
    <FrameReimag menu="Overview" entity={ENT} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto 1fr', gap: 16, height: '100%' }}>

        {/* ────────── ROW 1 — hero strip ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 1fr 1.1fr', gap: 16 }}>

          {/* Score */}
          <div className="card-info" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Your signal score</div>
            <div style={{ display: 'flex', gap: 20, marginTop: 10, alignItems: 'flex-start' }}>
              <div className="num-xl" style={{ color: 'var(--info-deep)', lineHeight: 1 }}>{score}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 4 }}>
                <span className="chip chip-pos" style={{ alignSelf: 'flex-start' }}>
                  <Icon name="arrow-up" size={11} /> +{vsMedian} vs median
                </span>
                <span className="chip chip-pos" style={{ alignSelf: 'flex-start' }}>
                  <Icon name="trending-up" size={11} /> +{vsPrev} since last quote
                </span>
              </div>
            </div>
            <div style={{ flex: 1, marginTop: 14, minHeight: 96 }}>
              <ScoreHistory history={scoreHist} />
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
              <span className="chip"><Icon name="check" size={12} /> Standard tier</span>
              <span className="chip chip-info"><Icon name="trending-up" size={12} /> 64th percentile</span>
            </div>
          </div>

          {/* Premium */}
          <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div className="eyebrow">Annual premium</div>
            <div className="num-xl" style={{ marginTop: 10, lineHeight: 1 }}>
              ${policies.reduce((s, p) => s + p.amount, 0).toLocaleString()}
            </div>
            <div className="caption" style={{ marginTop: 4 }}>
              Across {policies.length} active polic{policies.length === 1 ? 'y' : 'ies'}
            </div>
            <div style={{ marginTop: 'auto' }}>
              <PremiumBreakdown policies={policies} />
            </div>
          </div>

          {/* Awaiting you — coral spotlight */}
          <div className="card-spot" style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="eyebrow" style={{ color: 'var(--spot)' }}>Awaiting you</span>
              <span className="chip chip-spot">1 of 2</span>
            </div>
            <div>
              <div style={{ font: '600 16px/1.25 IBM Plex Sans', color: 'var(--ink)' }}>
                Hartford Mutual needs MFA attestation for the cyber bind
              </div>
              <div className="caption" style={{ marginTop: 4 }}>2 hours ago · Cyber referral</div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
              <button className="btn spot">Open thread</button>
              <button className="btn ghost">Snooze</button>
            </div>
          </div>
        </div>

        {/* ────────── ROW 2 — analytics: pulse + cohort ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>

          {/* Signal pulse: helping (green) + opportunity (INFO teal — review, not bad) */}
          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div>
                <div className="eyebrow">Signal pulse</div>
                <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: '6px 0 0' }}>What's moving your premium</h3>
              </div>
              <span className="micro">cyber · primary line</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
              <PulseColumn
                heading="Helping"
                headingChip="chip chip-pos"
                headingIcon="arrow-down"
                deltaLabel="−$28.1k"
                deltaClass="pos"
                accent="var(--pos)"
                rows={[
                ['MFA on admins', 12100, 12100],
                ['No prior claims (5y)', 9300, 12100],
                ['EDR coverage 95%+', 6700, 12100]]
                }
                sign="−" />
              
              <PulseColumn
                heading="Opportunity"
                headingChip="chip chip-info"
                headingIcon="lightbulb"
                deltaLabel="+$40.7k"
                deltaClass="info"
                accent="var(--info)"
                rows={[
                ['SOC 2 Type II', 18200, 18200],
                ['Backup encryption', 11400, 18200],
                ['Public RDP exposed', 6200, 18200]]
                }
                sign="+" />
              
            </div>
          </div>

          {/* Cohort standing — horizontal distribution strip */}
          <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow">Cohort standing</div>
                <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                  You sit at the <span className="pos">64th percentile</span>
                </h3>
              </div>
              <span className="micro">38 peers</span>
            </div>
            <div style={{ marginTop: 18, flex: 1, display: 'flex', alignItems: 'center' }}>
              <CohortBar value={score} median={median} topDecile={784} range={[600, 880]} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 10, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
              <div>
                <div className="micro">vs median</div>
                <div className="num-sm pos">+{vsMedian}</div>
              </div>
              <div>
                <div className="micro">your score</div>
                <div className="num-sm info" style={{ color: "rgb(11, 34, 55)" }}>{score}</div>
              </div>
              <div>
                <div className="micro">to top decile</div>
                <div className="num-sm">{784 - score}</div>
              </div>
            </div>
          </div>
        </div>

        {/* ────────── ROW 3 — footer cards (3 equal, identical structure) ────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>

          <FooterCard
            variant="card-pos"
            eyebrowColor="var(--pos)"
            eyebrow="Loss outlook"
            headline="Low"
            headlineColor="var(--pos)"
            sub="Frequency improving · 2 claims / 36mo"
            spark={[6, 5, 4, 4, 3, 3, 2]}
            sparkColor="var(--pos)" />
          
          <FooterCard
            variant="card-aux"
            eyebrowColor="var(--aux)"
            eyebrow="Exposure"
            headline="$118M"
            headlineColor="var(--aux)"
            sub="Mid-market · 2 states · diversified"
            spark={[88, 94, 99, 108, 112, 115, 118]}
            sparkColor="var(--aux)" />
          
          <FooterCard
            variant="card"
            eyebrowColor="var(--ink-soft)"
            eyebrow="Coverage shape"
            headline="3 lines · tier 2–4"
            headlineColor="var(--ink)"
            sub="Cyber leads spend · all current"
            customRight={
            <div style={{ width: 96, height: 8, borderRadius: 4, overflow: 'hidden', display: 'flex' }}>
                {policies.map((p, i) =>
              <div key={i} style={{ flex: p.amount, background: p.color,
                borderRight: i < policies.length - 1 ? '2px solid var(--surface)' : 0 }} />
              )}
              </div>
            } />
          
        </div>
      </div>
    </FrameReimag>);

}

/* ─── helpers (kept local to keep the page legible) ─────────── */

function PulseColumn({ heading, headingChip, headingIcon, deltaLabel, deltaClass, accent, rows, sign }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
        <span className={headingChip}><Icon name={headingIcon} size={12} /> {heading}</span>
        <span className={`num-sm ${deltaClass}`}>{deltaLabel}</span>
      </div>
      {rows.map((r, i) =>
      <div key={i} style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, gap: 8, whiteSpace: 'nowrap' }}>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[0]}</span>
            <span className={deltaClass} style={{ fontWeight: 600, flexShrink: 0 }}>
              {sign}${(r[1] / 1000).toFixed(1)}k
            </span>
          </div>
          <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
            <div style={{ width: `${r[1] / r[2] * 100}%`, height: '100%', background: accent }} />
          </div>
        </div>
      )}
    </div>);

}

function FooterCard({ variant, eyebrow, eyebrowColor, headline, headlineColor, sub, spark, sparkColor, customRight }) {
  return (
    <div className={variant} style={{ padding: 20, display: 'flex', flexDirection: 'column', height: '100%', backgroundColor: "rgb(255, 255, 255)", borderColor: "rgb(228, 220, 204)" }}>
      <div className="eyebrow" style={{ ...{ color: eyebrowColor }, color: "rgb(154, 164, 174)" }}>{eyebrow}</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: 8, gap: 12 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="num-sm" style={{ ...{ fontSize: 22, color: headlineColor }, color: "rgb(11, 34, 55)" }}>{headline}</div>
          <div className="caption" style={{ marginTop: 4 }}>{sub}</div>
        </div>
        <div style={{ flexShrink: 0 }}>
          {customRight ?? <Sparkline points={spark} color={sparkColor} width={88} height={32} />}
        </div>
      </div>
    </div>);

}

Object.assign(window, { ReimOverview });