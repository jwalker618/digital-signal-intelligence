/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, bookByClient, engagementLabel */

/* ============================================================
 * 02. Client Health — engagement & forward-looking signals
 *
 * Layout
 *   row 1 — hero stats (clients, strong, quiet, opps, risks, renewals)
 *   row 2 — quiet client alert strip (orange)
 *   row 3 — client roster cards (one per client) with engagement,
 *           opportunities, risks, renewal countdown
 * ============================================================ */

function ReimBrokerClients({ isDark }) {
  const clients = bookByClient();
  const strong = clients.filter(c => c.engagement >= 80).length;
  const quiet  = clients.filter(c => c.engagement < 40).length;
  const opps   = clients.reduce((s, c) => s + c.opps, 0);
  const risks  = clients.reduce((s, c) => s + c.risks, 0);
  const renewalSoon = clients.filter(c => c.nextRenewalDays <= 60).length;

  return (
    <FrameReimag menu="Client Health" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* row 1 — hero */}
        <div>
          <div className="eyebrow">Client health</div>
          <h2 className="display" style={{ marginTop: 6 }}>Engagement, opportunities, risks across your book</h2>
          <div className="body" style={{ marginTop: 8, maxWidth: 640 }}>
            Engagement is a leading indicator — a client scoring "Quiet" or "Dormant" today is at elevated non-renewal risk in the next 6 months unless re-engaged.
          </div>
        </div>

        {/* KPI row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
          <MiniKpi label="Clients"          value={clients.length} />
          <MiniKpi label="Strong"           value={strong}     tone="pos"  />
          <MiniKpi label="Quiet / dormant"  value={quiet}      tone="spot" />
          <MiniKpi label="Open opps"        value={opps}       tone="info" />
          <MiniKpi label="Risk flags"       value={risks}      tone="neg"  />
          <MiniKpi label="Renewal ≤60d"     value={renewalSoon} tone="warn" />
        </div>

        {/* quiet client alert strip */}
        {quiet > 0 && (
          <div className="card-spot" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
              <div>
                <div className="eyebrow" style={{ color: 'var(--spot)' }}>Quiet client alerts</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>
                  {quiet} client{quiet === 1 ? '' : 's'} showing dormant signals — proactive touchpoint recommended
                </h3>
              </div>
              <span className="chip chip-spot">{quiet} flagged</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {clients.filter(c => c.engagement < 40).map((c) => (
                <div key={c.entity} style={{
                  display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr auto',
                  alignItems: 'center', gap: 12,
                  padding: '10px 14px',
                  background: 'var(--surface)',
                  border: '1px solid var(--rule)',
                  borderRadius: 8,
                }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{c.entity}</div>
                    <div className="micro">{c.vertical}</div>
                  </div>
                  <div>
                    <div className="micro">engagement</div>
                    <div className="num-sm" style={{ fontSize: 14, color: 'var(--spot)' }}>{c.engagement} · {c.engagementLabel}</div>
                  </div>
                  <div>
                    <div className="micro">renewal in</div>
                    <div className="num-sm" style={{ fontSize: 14, color: c.nextRenewalDays <= 60 ? 'var(--warn)' : 'var(--ink)' }}>{c.nextRenewalDays}d</div>
                  </div>
                  <button className="btn spot">Reach out →</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* client roster — full cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h3 style={{ font: '600 17px/1 IBM Plex Sans', margin: 0 }}>Client roster · {clients.length}</h3>
            <span className="caption">Sorted by engagement, highest first</span>
          </div>
          {clients.map((c) => <ClientHealthCard key={c.entity} client={c} />)}
        </div>

      </div>
    </FrameReimag>
  );
}

/* Thin wrapper over the shared <Kpi> primitive (primitives.jsx). */
function MiniKpi(props) {
  return <Kpi {...props} surface="card" valueSize={26} />;
}

function ClientHealthCard({ client }) {
  const c = client;
  const engColor = c.engagement >= 80 ? 'var(--pos)'
                  : c.engagement >= 60 ? 'var(--info)'
                  : c.engagement >= 40 ? 'var(--warn)'
                  : 'var(--spot)';
  return (
    <div className="card" style={{
      padding: 18,
      borderLeft: `4px solid ${engColor}`,
    }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 1.6fr 28px', gap: 20, alignItems: 'center' }}>
        {/* identity */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 4 }}>
            <span style={{ fontSize: 15, fontWeight: 600 }}>{c.entity}</span>
            <span className="chip">{c.vertical}</span>
          </div>
          <div className="micro">
            {c.policies.length} polic{c.policies.length === 1 ? 'y' : 'ies'} · ${(c.totalPremium / 1000).toFixed(0)}k premium
          </div>
          <div style={{
            marginTop: 8, display: 'flex', alignItems: 'center', gap: 6, fontSize: 12,
            color: c.nextRenewalDays <= 60 ? 'var(--warn)' : 'var(--ink-soft)',
            fontWeight: c.nextRenewalDays <= 60 ? 600 : 400,
          }}>
            <Icon name="calendar" size={12} />
            Renewal in {c.nextRenewalDays}d
          </div>
        </div>

        {/* engagement */}
        <div>
          <div className="micro">Engagement</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
            <span className="num" style={{ fontSize: 28, color: engColor, fontVariantNumeric: 'tabular-nums' }}>{c.engagement}</span>
            <span className="caption">{c.engagementLabel}</span>
          </div>
          <div style={{ marginTop: 8, height: 4, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ width: `${c.engagement}%`, height: '100%', background: engColor }} />
          </div>
        </div>

        {/* opps + risks */}
        <div>
          {c.opps > 0 && (
            <div style={{ marginBottom: 6 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, fontWeight: 600, color: 'var(--info-deep)', marginBottom: 4 }}>
                <Icon name="trending-up" size={11} /> OPPORTUNITIES · {c.opps}
              </div>
              <div className="caption" style={{ fontSize: 12 }}>
                {c.opps === 1 ? 'Cyber gap (industry default)'
                 : c.opps === 2 ? 'Cyber + product liability gaps'
                 : 'Cyber, clinical trials, product liability gaps'}
              </div>
            </div>
          )}
          {c.risks > 0 && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11.5, fontWeight: 600, color: 'var(--neg)', marginBottom: 4 }}>
                <Icon name="trending-down" size={11} /> RISKS · {c.risks}
              </div>
              <div className="caption" style={{ fontSize: 12 }}>
                {c.risks === 1 ? 'Renewal soon + recent loss event'
                 : 'Renewal soon · score declining · slow reply'}
              </div>
            </div>
          )}
          {c.opps === 0 && c.risks === 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--pos)' }}>
              <Icon name="check-circle-2" size={14} />
              <span style={{ fontSize: 13, fontWeight: 600 }}>Clean status — no flags</span>
            </div>
          )}
        </div>

        <Icon name="chevron-right" size={18} color="var(--ink-mute)" />
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerClients, MiniKpi });
