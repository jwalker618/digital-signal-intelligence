/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, BROKER_QUERIES, bookByClient, tierColor */

/* ============================================================
 * 01. Book of Clients — broker home
 *
 * Layout (revised for large books):
 *   row 1 — hero strip: broker identity + book stats (4 KPIs)
 *   row 2 — two columns:
 *            LEFT  · book roster — a fixed-height panel that scrolls
 *                    INTERNALLY (sticky header + column row), so the
 *                    roster can grow to any size without pushing the
 *                    rest of the page away.
 *            RIGHT · a pinned rail that keeps Tier mix + Open queries
 *                    always in view, no matter how long the roster.
 *
 * Previously tier-mix + queries sat in a third row beneath the roster
 * and fell off the bottom once a broker's book got large. They are the
 * broker's at-a-glance health + comms queue — they must stay visible.
 * ============================================================ */

function ReimBrokerBook({ isDark }) {
  const policies = BROKER_BOOK;
  const clients  = bookByClient();
  const totalPremium = policies.reduce((s, p) => s + p.premium, 0);
  const avgScore = Math.round(policies.reduce((s, p) => s + p.score, 0) / policies.length);
  const awaitingBroker = BROKER_QUERIES.filter(q => q.awaiting === 'broker').length;
  const awaitingClient = BROKER_QUERIES.filter(q => q.awaiting === 'client').length;
  const tiers = [1, 2, 3, 4, 5].map(t => ({
    t, n: policies.filter(p => p.tier === t).length,
  }));
  const maxTier = Math.max(...tiers.map(b => b.n), 1);

  // Roster search — find a particular entity / line / carrier.
  const [query, setQuery] = React.useState('');
  const [industry, setIndustry] = React.useState('All');
  const q = query.trim().toLowerCase();
  const industries = ['All', ...Array.from(new Set(policies.map(p => p.vertical)))];
  const visible = policies.filter(p => {
    if (industry !== 'All' && p.vertical !== industry) return false;
    if (!q) return true;
    return [p.entity, p.line, p.carrier, p.code, p.vertical]
      .some(f => String(f || '').toLowerCase().includes(q));
  });

  // Open-queries filter — this view is the broker's comms hub, so it needs
  // to slice a potentially long queue.
  const [qFilter, setQFilter] = React.useState('broker');
  const queryTabs = [
    { key: 'open',   label: 'Open',      n: BROKER_QUERIES.filter(x => x.awaiting !== 'resolved').length },
    { key: 'broker', label: 'On you',    n: awaitingBroker },
    { key: 'client', label: 'On client', n: awaitingClient },
    { key: 'resolved', label: 'Resolved', n: BROKER_QUERIES.filter(x => x.awaiting === 'resolved').length },
  ];
  const queriesShown = BROKER_QUERIES.filter(qq =>
    qFilter === 'open' ? qq.awaiting !== 'resolved' : qq.awaiting === qFilter
  );

  // Shared column template — kept in one place so header + rows never drift.
  const COLS = '1.7fr 1.2fr 1fr 54px 48px 92px 104px 30px';

  return (
    <FrameReimag menu="Book of Clients" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto minmax(0, 1fr)', gap: 16, height: '100%' }}>

        {/* row 1 — hero stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 24, display: 'flex', alignItems: 'center', gap: 18 }}>
            <div style={{
              width: 64, height: 64, borderRadius: 12,
              background: 'var(--info-soft)', color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="briefcase" size={32} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">Broker book</div>
              <h2 className="display" style={{ marginTop: 4, lineHeight: 1.1 }}>
                Marsh
                <span style={{ display: 'block', fontSize: 18, fontWeight: 400, color: 'var(--ink-soft)', marginTop: 4 }}>
                  Northeast Specialty
                </span>
              </h2>
              <div className="caption" style={{ marginTop: 8 }}>
                {clients.length} clients · {policies.length} policies in force
              </div>
            </div>
          </div>
          <KpiCard label="Aggregate premium" value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} sub="annual" />
          <KpiCard label="Avg signal score" value={avgScore} sub="across the book" tone="info" />
          <KpiCard label="Awaiting you" value={awaitingBroker} sub={`of ${BROKER_QUERIES.length} open queries`} tone="spot" />
        </div>

        {/* row 2 — roster (scrolls internally) + pinned rail */}
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 392px', gap: 16, alignItems: 'start', minHeight: 0 }}>

          {/* LEFT · roster */}
          <div className="card" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', maxHeight: 828 }}>
            {/* sticky header — title + search + industry filter */}
            <div style={{
              flexShrink: 0,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '14px 20px', borderBottom: '1px solid var(--rule)',
              background: 'var(--surface-elev)', gap: 16, flexWrap: 'wrap',
            }}>
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Book roster</h3>
                <span className="chip">{(q || industry !== 'All') ? `${visible.length} of ${policies.length}` : `${policies.length} policies`}</span>
              </div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                <label className="pl-search">
                  <Icon name="search" size={15} color="var(--ink-mute)" />
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search client, carrier…"
                  />
                  {query && (
                    <button type="button" className="pl-search-clear" aria-label="Clear search" onClick={() => setQuery('')}>
                      <Icon name="x" size={13} />
                    </button>
                  )}
                </label>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  {industries.map((ind) => (
                    <button
                      key={ind}
                      type="button"
                      className="chip qfilter"
                      onClick={() => setIndustry(ind)}
                      style={industry === ind
                        ? { background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }
                        : undefined}
                    >
                      {ind === 'Industrial Robotics' ? 'Industrial' : ind === 'Pharmaceuticals' ? 'Pharma' : ind === 'Transportation' ? 'Transport' : ind}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* column header */}
            <div style={{
              flexShrink: 0,
              display: 'grid', gridTemplateColumns: COLS, gap: 0,
              background: 'var(--surface-sunken)',
              padding: '8px 20px',
              borderBottom: '1px solid var(--rule)',
            }}>
              {['Client', 'Coverage', 'Carrier', 'Score', 'Tier', 'Premium', 'Status', ''].map((h, i) => (
                <span key={i} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>
              ))}
            </div>

            {/* scroll body */}
            <div style={{ overflowY: 'auto', flex: 1, minHeight: 0 }}>
              {visible.map((p, i) => (
                <div key={p.code} className="pl-row" title={`Open ${p.entity}`} style={{
                  display: 'grid', gridTemplateColumns: COLS,
                  gap: 0, alignItems: 'center',
                  padding: '10px 20px',
                  borderBottom: i < visible.length - 1 ? '1px solid var(--rule)' : 0,
                  fontSize: 13,
                }}>
                  <span style={{ fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', paddingRight: 8 }}>{p.entity}</span>
                  <span style={{ color: 'var(--ink-soft)' }}>{p.line}</span>
                  <span style={{ color: 'var(--ink-soft)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', paddingRight: 8 }}>{p.carrier}</span>
                  <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{p.score}</span>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    width: 24, height: 24, borderRadius: 6,
                    background: tierColor(p.tier) + '22',
                    color: tierColor(p.tier),
                    fontWeight: 700, fontSize: 12,
                  }}>{p.tier}</span>
                  <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(p.premium / 1000).toFixed(0)}k</span>
                  <span className={`chip chip-${p.statusTone}`} style={{ alignSelf: 'flex-start', justifySelf: 'flex-start' }}>{p.status}</span>
                  <span className="pl-open" style={{ justifySelf: 'end' }}>
                    <Icon name="chevron-right" size={16} />
                  </span>
                </div>
              ))}
              {visible.length === 0 && (
                <div style={{ padding: '36px 20px', textAlign: 'center' }} className="caption">
                  No policies match your filter.
                </div>
              )}
            </div>
          </div>

          {/* RIGHT · pinned rail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minHeight: 0 }}>
            {/* tier mix */}
            <div className="card" style={{ padding: 20 }}>
              <div className="eyebrow">Tier mix</div>
              <h3 style={{ font: '600 16px/1.2 IBM Plex Sans', margin: '5px 0 10px' }}>Risk quality across the book</h3>
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, height: 92, marginTop: 4 }}>
                {tiers.map(({ t, n }) => (
                  <div key={t} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
                    <span className="num-sm" style={{ fontSize: 15, color: tierColor(t), fontVariantNumeric: 'tabular-nums' }}>{n}</span>
                    <div style={{
                      width: '100%', height: `${(n / maxTier) * 100}%`, minHeight: 4,
                      background: tierColor(t), borderRadius: '6px 6px 0 0',
                    }} />
                    <span className="micro">T{t}</span>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
                <div className="micro" style={{ marginBottom: 9 }}>Recent movements · last 6 months</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
                  {[
                    { icon: 'trending-up', color: 'var(--pos)', delta: '+5%', text: 'Tier‑2 spread, as scores improved on renewals' },
                    { icon: 'trending-up', color: 'var(--warn)', delta: '+2', text: 'Tier‑4 placements — Granite Peak & BrightLeaf harder to place' },
                    { icon: 'trending-down', color: 'var(--info)', delta: '−18d', text: 'Avg time-to-bind, helped by pre-filled attestations' },
                  ].map((m, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                        width: 20, height: 20, borderRadius: 6, flexShrink: 0,
                        background: m.color + '1f', color: m.color,
                      }}>
                        <Icon name={m.icon} size={12} />
                      </span>
                      <div style={{ fontSize: 12, lineHeight: 1.4 }}>
                        <span style={{ fontWeight: 700, color: m.color, fontVariantNumeric: 'tabular-nums' }}>{m.delta}</span>
                        <span style={{ color: 'var(--ink-soft)' }}> {m.text}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* open queries */}
            <div className="card" style={{ padding: 20, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <div>
                  <div className="eyebrow">Open queries</div>
                  <h3 style={{ font: '600 16px/1.2 IBM Plex Sans', margin: '5px 0 0' }}>Waiting on you or your clients</h3>
                </div>
                <span className="chip chip-spot">{awaitingBroker} on you</span>
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 12, flexWrap: 'wrap' }}>
                {queryTabs.map(tab => (
                  <button
                    key={tab.key}
                    type="button"
                    className={`chip qfilter ${qFilter === tab.key ? 'qfilter-on' : ''}`}
                    onClick={() => setQFilter(tab.key)}
                  >
                    {tab.label} <span style={{ opacity: 0.6 }}>({tab.n})</span>
                  </button>
                ))}
              </div>
              <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8, overflowY: 'auto', flex: 1, minHeight: 0 }}>
                {queriesShown.length === 0 && (
                  <div style={{ padding: '18px 0', textAlign: 'center' }} className="caption">Nothing here right now.</div>
                )}
                {queriesShown.map((qq) => (
                  <div key={qq.refCode} style={{
                    display: 'grid', gridTemplateColumns: '1fr auto', gap: '2px 12px', alignItems: 'center',
                    padding: '10px 12px',
                    background: 'var(--surface-elev)',
                    border: '1px solid var(--rule)',
                    borderRadius: 8,
                  }}>
                    <div style={{ fontSize: 13, fontWeight: 600, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{qq.entity}</div>
                    <span className={`chip ${qq.awaiting === 'broker' ? 'chip-spot' : qq.awaiting === 'client' ? 'chip-info' : 'chip-pos'}`} style={{ justifySelf: 'end' }}>
                      {qq.awaiting === 'broker' ? 'on you' : qq.awaiting === 'client' ? 'on client' : 'resolved'}
                    </span>
                    <div className="micro" style={{
                      gridColumn: '1 / 2',
                      overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                    }}>{qq.ask}</div>
                    <span className="micro" style={{ gridColumn: '2 / 3', justifySelf: 'end' }}>{qq.age}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>

      </div>
    </FrameReimag>
  );
}

function KpiCard({ label, value, sub, tone }) {
  const color = tone === 'info' ? 'var(--info-deep)' : tone === 'spot' ? 'var(--spot-deep)' : 'var(--ink)';
  const cardCls = tone === 'info' ? 'card-info' : tone === 'spot' ? 'card-spot' : 'card';
  return (
    <div className={cardCls} style={{ padding: 22 }}>
      <div className="eyebrow" style={tone ? { color } : undefined}>{label}</div>
      <div className="num-xl" style={{ marginTop: 6, color, lineHeight: 1 }}>{value}</div>
      <div className="caption" style={{ marginTop: 6 }}>{sub}</div>
    </div>
  );
}

Object.assign(window, { ReimBrokerBook, KpiCard });
