/* global React, FrameReimag, Icon, CARRIER_ORG, CARRIER_SUBMISSIONS */

/* ============================================================
 * Carrier · 01 Referral Pipeline — inbound submissions queue
 *
 * Layout
 *   row 1 — hero with pipeline KPIs
 *   row 2 — filter pills + sort
 *   row 3 — submissions table (entity, broker, line, score, tier,
 *           decision, premium, status, age)
 * ============================================================ */

function ReimCarrierPipeline({ isDark, mode = 'referral' }) {
  const isReferral = mode === 'referral';
  const subs = CARRIER_SUBMISSIONS;
  const [query, setQuery] = React.useState('');
  const q = query.trim().toLowerCase();
  const visible = q
    ? subs.filter(s => [s.entity, s.industry, s.broker, s.line, s.code]
        .some(f => String(f || '').toLowerCase().includes(q)))
    : subs;
  const referrals = subs.filter(s => s.decision === 'refer').length;
  const approvals = subs.filter(s => s.decision === 'approve').length;
  const declines  = subs.filter(s => s.decision === 'decline').length;
  const totalPremium = subs.reduce((s, x) => s + x.premium, 0);
  // Referral triage metrics (replace the decision-breakdown KPIs, which only
  // make sense on the full pipeline) so the hero row stays full, same-sized.
  const avgScore = Math.round(subs.reduce((n, s) => n + s.score, 0) / subs.length);
  const toHours = (r) => r.endsWith('d') ? parseFloat(r) * 24 : parseFloat(r);
  const oldest = subs.reduce((a, b) => toHours(b.received) > toHours(a.received) ? b : a).received;
  // Premium spread across the queue — low / median / high.
  const premiums = subs.map(s => s.premium).sort((a, b) => a - b);
  const pn = premiums.length;
  const loPrem = premiums[0];
  const hiPrem = premiums[pn - 1];
  const medPrem = pn % 2 ? premiums[(pn - 1) / 2] : (premiums[pn / 2 - 1] + premiums[pn / 2]) / 2;
  const fmtK = (v) => `$${Math.round(v / 1000)}k`;
  // Last column widens to hold quick approve/decline actions in referral mode.
  const gridCols = `2fr 1fr 1.4fr 80px 70px 100px 110px 130px 70px ${isReferral ? '150px' : '28px'}`;

  return (
    <FrameReimag menu={isReferral ? 'Referral Pipeline' : 'Full Pipeline'} entity={CARRIER_ORG.shortName} persona="carrier" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* hero row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 22, display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{
              width: 56, height: 56, borderRadius: 12,
              background: 'var(--info-soft)', color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="user-star" size={28} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">{isReferral ? 'Referral pipeline' : 'Full pipeline'}</div>
              <div className="num" style={{ fontSize: 32, lineHeight: 1, marginTop: 6, color: 'var(--info)', fontVariantNumeric: 'tabular-nums' }}>
                {subs.length}
              </div>
              <div className="caption" style={{ marginTop: 6 }}>
                {isReferral ? 'submissions awaiting decision' : 'submissions in pipeline'}
              </div>
            </div>
          </div>
          {isReferral ? (
            <React.Fragment>
              <MiniKpi label="Avg score" value={avgScore} tone="info" />
              <div className="card" style={{ padding: 16 }}>
                <div className="micro">Premium range</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, marginTop: 8 }}>
                  {[['Low', loPrem, 'var(--ink-soft)'], ['Median', medPrem, 'var(--ink)'], ['High', hiPrem, 'var(--ink-soft)']].map(([k, v, c]) => (
                    <div key={k} style={{ minWidth: 0 }}>
                      <div className="micro" style={{ fontSize: 10 }}>{k}</div>
                      <div className="num" style={{ fontSize: 16, color: c, marginTop: 3, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{fmtK(v)}</div>
                    </div>
                  ))}
                </div>
              </div>
              <MiniKpi label="Oldest waiting" value={oldest} tone="spot" />
            </React.Fragment>
          ) : (
            <React.Fragment>
              <MiniKpi label="To refer"   value={referrals} tone="spot" />
              <MiniKpi label="To approve" value={approvals} tone="pos" />
              <MiniKpi label="Declined"   value={declines}  tone="neg" />
            </React.Fragment>
          )}
          <MiniKpi label="Pipeline $"  value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} />
        </div>

        {/* filters */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Find a specific entity — on both pipelines. */}
          <label className="pl-search">
            <Icon name="search" size={15} color="var(--ink-mute)" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search entity, broker…"
            />
            {query && (
              <button type="button" className="pl-search-clear" aria-label="Clear search" onClick={() => setQuery('')}>
                <Icon name="x" size={13} />
              </button>
            )}
          </label>
          <span style={{ width: 8 }} />
          {/* Decision filter is only meaningful on the full pipeline — in the
              referral view every row is already a referral. */}
          {!isReferral && (
            <React.Fragment>
              <span className="micro" style={{ marginRight: 4 }}>Decision:</span>
              <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
              <span className="chip">Refer ({referrals})</span>
              <span className="chip">Approve ({approvals})</span>
              <span className="chip">Decline ({declines})</span>
              <span style={{ width: 16 }} />
            </React.Fragment>
          )}
          <span className="micro" style={{ marginRight: 4 }}>Line:</span>
          <span className="chip">Cyber</span>
          <span className="chip">Property</span>
          <span className="chip">Casualty</span>
          <span className="chip">D&O</span>
          <span className="chip">Marine</span>
          <span style={{ flex: 1 }} />
          <span className="caption">Sort: oldest first</span>
        </div>

        {/* table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: gridCols,
            background: 'var(--surface-elev)',
            padding: '10px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Entity', 'Broker', 'Line', 'Score', 'Tier', 'Decision', 'Premium', 'Status', 'Age', isReferral ? 'Quick' : ''].map((h, hi) => (
              <span key={hi} className="micro" style={{ fontSize: 11, letterSpacing: '0.06em', justifySelf: hi === 9 && isReferral ? 'center' : undefined }}>{h}</span>
            ))}
          </div>
          {visible.map((s, i) => (
            <div key={s.code} className="pl-row" title={`Open ${s.entity} — ${s.code}`} style={{
              display: 'grid',
              gridTemplateColumns: gridCols,
              gap: 0, alignItems: 'center',
              padding: '12px 20px',
              borderBottom: i < visible.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13,
            }}>
              <div>
                <div style={{ fontWeight: 600 }}>{s.entity}</div>
                <div className="micro">{s.industry}</div>
              </div>
              <span className="caption">{s.broker}</span>
              <span style={{ color: 'var(--ink)' }}>{s.line}</span>
              <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{s.score}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 24, height: 24, borderRadius: 6,
                background: tierColor(s.tier) + '22', color: tierColor(s.tier),
                fontWeight: 700, fontSize: 12,
              }}>{s.tier}</span>
              <span className={`chip chip-${decisionTone(s.decision)}`} style={{ justifySelf: 'flex-start' }}>{s.decision}</span>
              <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(s.premium / 1000).toFixed(0)}k</span>
              <span className={`chip chip-${s.statusTone}`} style={{ justifySelf: 'flex-start' }}>{s.status}</span>
              <span className="micro">{s.received}</span>
              {isReferral ? (
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', justifySelf: 'center' }}>
                  <button className="qd-btn qd-approve" title={`Approve ${s.entity}`} aria-label="Approve"><Icon name="check" size={14} /></button>
                  <button className="qd-btn qd-decline" title={`Decline ${s.entity}`} aria-label="Decline"><Icon name="x" size={14} /></button>
                  {/* open the full submission detail */}
                  <Icon name="chevron-right" size={16} color="var(--ink-mute)" style={{ marginLeft: 2 }} />
                </div>
              ) : (
                <Icon name="chevron-right" size={16} color="var(--ink-mute)" />
              )}
            </div>
          ))}
          {visible.length === 0 && (
            <div style={{ padding: '40px 20px', textAlign: 'center' }} className="caption">
              No submissions match “{query}”.
            </div>
          )}
        </div>

      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimCarrierPipeline });
