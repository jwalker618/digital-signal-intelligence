/* global React, Icon */

/* ============================================================
 * Login + Reset Password — full-screen, no chrome
 *
 * Layout: split-screen
 *   left  — DSI brand panel (deep navy, signal-bars graphic, tagline)
 *   right — auth form (changes per state)
 *
 * 5 states surface as separate artboards on the canvas:
 *   01 Sign in (email + password)
 *   02 SSO (tenant identifier)
 *   03 MFA challenge (6-digit TOTP)
 *   04 Reset password — request
 *   05 Reset password — set new
 * ============================================================ */

function AuthShell({ children }) {
  return (
    <div className="ds-reimag" style={{ width: '100%', height: '100%', display: 'flex' }}>
      <BrandPanel />
      <div style={{
        flex: 1, background: 'var(--canvas)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 40,
      }}>
        <div style={{ width: '100%', maxWidth: 420 }}>
          {children}
        </div>
      </div>
    </div>
  );
}

function BrandPanel() {
  return (
    <div style={{
      width: '46%', background: '#051322', color: '#F1ECE0',
      display: 'flex', flexDirection: 'column',
      padding: 44, position: 'relative', overflow: 'hidden',
    }}>
      {/* Wordmark */}
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img src="dsi-logo.svg" alt="Generate · DSI" style={{ height: 56, width: 'auto', display: 'block' }} />
      </div>

      {/* Centred statement */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ font: '600 38px/1.15 IBM Plex Sans', letterSpacing: '-0.015em', maxWidth: 460 }}>
          Risk,<br/>
          <span style={{ color: '#39D3BA' }}>illuminated by signal.</span>
        </div>
        <div style={{ font: '400 14px/1.6 IBM Plex Sans', color: 'rgba(241,236,224,0.7)', maxWidth: 420, marginTop: 18 }}>
          A continuous signal engine for risk in the agentic era.
        </div>
        {/* Decorative pulse */}
        <div style={{ marginTop: 36, display: 'flex', gap: 10, alignItems: 'center' }}>
          {[10, 18, 12, 26, 16, 22, 14, 30, 20].map((h, i) => (
            <div key={i} style={{
              width: 4, height: h,
              background: i % 3 === 1 ? '#39D3BA' : 'rgba(57,211,186,0.4)',
              borderRadius: 2,
            }} />
          ))}
        </div>
      </div>

      {/* Footer */}
      <div style={{ font: '11px IBM Plex Sans', color: 'rgba(241,236,224,0.45)', display: 'flex', gap: 16 }}>
        <span>v8.2.1 · build 2026.05</span>
        <span style={{ marginLeft: 'auto' }}>SOC 2 Type II · ISO 27001</span>
      </div>
    </div>
  );
}

function BigSignalMark() {
  return (
    <div style={{ position: 'relative', width: 40, height: 32 }}>
      {[
        { x: 0,  y: 14, w: 6, h: 18 },
        { x: 9,  y: 8,  w: 6, h: 24 },
        { x: 18, y: 0,  w: 6, h: 32 },
        { x: 27, y: 6,  w: 6, h: 26 },
      ].map((b, i) => (
        <div key={i} style={{
          position: 'absolute', left: b.x, top: b.y, width: b.w, height: b.h,
          background: i === 2 ? '#39D3BA' : '#39D3BA',
          opacity: i === 2 ? 1 : 0.55,
          borderRadius: 2,
        }} />
      ))}
    </div>
  );
}

/* ─── Form atoms ──────────────────────────────────────────────── */

function AuthHeading({ kicker, title, body }) {
  return (
    <div style={{ marginBottom: 28 }}>
      {kicker && <div className="eyebrow" style={{ color: 'var(--info)' }}>{kicker}</div>}
      <h1 style={{ font: '600 28px/1.2 IBM Plex Sans', margin: '6px 0 0', color: 'var(--ink)' }}>{title}</h1>
      {body && <p className="caption" style={{ marginTop: 8, lineHeight: 1.55 }}>{body}</p>}
    </div>
  );
}

function Field({ label, value, type = 'text', placeholder }) {
  return (
    <label style={{ display: 'block', marginBottom: 14 }}>
      <span style={{ display: 'block', font: '500 12px IBM Plex Sans', color: 'var(--ink-soft)', marginBottom: 6 }}>{label}</span>
      <div style={{
        padding: '11px 14px', fontSize: 14,
        background: 'var(--surface)',
        border: '1px solid var(--rule-strong)',
        borderRadius: 8, color: 'var(--ink)',
        fontFamily: type === 'password' ? 'ui-monospace, monospace' : 'inherit',
        letterSpacing: type === 'password' ? '0.2em' : 'normal',
      }}>
        {value || <span style={{ color: 'var(--ink-mute)' }}>{placeholder}</span>}
      </div>
    </label>
  );
}

function PrimaryBtn({ children }) {
  return (
    <button className="btn" style={{ width: '100%', justifyContent: 'center', padding: '12px 14px', fontSize: 14 }}>
      {children}
    </button>
  );
}

function MutedLink({ children }) {
  return (
    <a href="#" style={{
      font: '500 13px IBM Plex Sans', color: 'var(--ink-soft)',
      textDecoration: 'none',
    }}>{children}</a>
  );
}

function ToggleStrip({ left, right, active }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4,
      padding: 4, background: 'var(--surface-sunken)',
      borderRadius: 10, marginBottom: 22,
    }}>
      {[left, right].map((label, i) => (
        <button key={label} style={{
          padding: '8px 12px', fontSize: 13, fontWeight: 600,
          background: i === active ? 'var(--surface)' : 'transparent',
          border: 0, borderRadius: 8,
          color: i === active ? 'var(--ink)' : 'var(--ink-soft)',
          boxShadow: i === active ? '0 1px 2px rgba(0,0,0,0.08)' : 'none',
        }}>{label}</button>
      ))}
    </div>
  );
}

/* ─── Variants ───────────────────────────────────────────────── */

function ReimLogin({}) {
  return (
    <AuthShell>
      <AuthHeading
        kicker="Welcome"
        title="Sign in to your account"
        body="Use your work email + password, or switch to SSO if your organisation has it set up."
      />
      <ToggleStrip left="Email + password" right="SSO" active={0} />
      <Field label="Work email" value="eli.kovacic@eastwardrobotics.com" />
      <Field label="Password" type="password" value="••••••••••••" />
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 18 }}>
        <MutedLink>Forgot password?</MutedLink>
      </div>
      <PrimaryBtn>Sign in</PrimaryBtn>
      <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--rule)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span className="caption">First time here?</span>
        <MutedLink>Get an invite from your broker →</MutedLink>
      </div>
    </AuthShell>
  );
}

function ReimLoginSSO({}) {
  return (
    <AuthShell>
      <AuthHeading
        kicker="Welcome"
        title="Sign in via SSO"
        body="Enter your organisation's tenant identifier. We'll bounce you to your identity provider to finish signing in."
      />
      <ToggleStrip left="Email + password" right="SSO" active={1} />
      <Field label="Tenant identifier" value="marsh-northeast" placeholder="e.g. your company domain" />
      <PrimaryBtn>
        <Icon name="key-round" size={14} /> Continue with SSO
      </PrimaryBtn>
      <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--rule)' }}>
        <div className="caption" style={{ lineHeight: 1.5 }}>
          You'll be redirected to your identity provider (Okta, Azure AD, Google Workspace, etc.).
          MFA is enforced by your tenant's policy.
        </div>
      </div>
    </AuthShell>
  );
}

function ReimLoginMFA({}) {
  return (
    <AuthShell>
      <AuthHeading
        kicker="Two-factor authentication"
        title="Enter your code"
        body="Open your authenticator app and enter the 6-digit code for DSI."
      />
      <div style={{ marginBottom: 18 }}>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between' }}>
          {['4', '8', '2', '1', '6', '9'].map((d, i) => (
            <div key={i} style={{
              flex: 1, height: 56,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 22, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
              background: 'var(--surface)',
              border: '1px solid ' + (i === 5 ? 'var(--info)' : 'var(--rule-strong)'),
              borderRadius: 10, color: 'var(--ink)',
            }}>{i < 5 ? d : ''}</div>
          ))}
        </div>
      </div>
      <PrimaryBtn>Verify</PrimaryBtn>
      <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--rule)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <MutedLink>← Back to sign in</MutedLink>
        <MutedLink>Use a recovery code</MutedLink>
      </div>
    </AuthShell>
  );
}

function ReimReset({}) {
  return (
    <AuthShell>
      <AuthHeading
        kicker="Reset password"
        title="Get a reset link"
        body="Enter the email you sign in with. We'll send a one-time link that expires in 30 minutes."
      />
      <Field label="Work email" value="eli.kovacic@eastwardrobotics.com" />
      <PrimaryBtn>
        <Icon name="mail" size={14} /> Send reset link
      </PrimaryBtn>
      <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--rule)' }}>
        <MutedLink>← Back to sign in</MutedLink>
      </div>
    </AuthShell>
  );
}

function ReimResetSet({}) {
  const strength = 4; // out of 5
  return (
    <AuthShell>
      <AuthHeading
        kicker="Reset password"
        title="Choose a new password"
        body="Pick something at least 12 characters with a mix of upper/lower case, a digit, and a symbol."
      />
      <Field label="New password" type="password" value="••••••••••••••••" />
      {/* strength meter */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '-6px 0 16px' }}>
        <div style={{ flex: 1, height: 4, display: 'flex', gap: 3 }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} style={{
              flex: 1, borderRadius: 2,
              background: i < strength
                ? (strength <= 1 ? 'var(--neg)' : strength <= 3 ? 'var(--warn)' : 'var(--pos)')
                : 'var(--rule)',
            }} />
          ))}
        </div>
        <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--pos)' }}>Strong</span>
      </div>
      <Field label="Confirm password" type="password" value="••••••••••••••••" />
      <PrimaryBtn>Set new password</PrimaryBtn>
    </AuthShell>
  );
}

Object.assign(window, { ReimLogin, ReimLoginSSO, ReimLoginMFA, ReimReset, ReimResetSet });
