/* global React, FrameReimag, Icon */

/* ============================================================
 * REIMAGINED pages — same content & purpose, fresh visual direction.
 *
 * Direction:
 *   • Warmer paper canvas + true white cards → real surface elevation
 *   • Navy ink stays as structural color; coral becomes the "you" accent
 *   • Semantic colors used as STRUCTURAL fills (tinted cards), not decoration
 *   • Type scale breathes — 56px heroes / 32px titles / 14px body
 *   • Charts where charts are clearer than tables
 * ============================================================ */

const E = 'Eastward Robotics';

/* Shared bits ──────────────────────────────────────────────── */
function Sparkline({ points, color = 'var(--ink)', height = 28 }) {
  const w = 80;
  const max = Math.max(...points),min = Math.min(...points);
  const path = points.map((p, i) => {
    const x = i / (points.length - 1) * w;
    const y = height - (p - min) / (max - min || 1) * height;
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return (
    <svg width={w} height={height} style={{ display: 'block', height: "80px" }}>
      <path d={path} fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" />
    </svg>);

}

function Dial({ value, max = 100, size = 132, label, sublabel, color = 'var(--info)' }) {
  const cx = size / 2,cy = size / 2;
  const r = size / 2 - 10;
  const C = 2 * Math.PI * r;
  // Show 3/4 arc (gauge style)
  const arc = 0.75;
  const offset = (1 - arc) / 2;
  const dash = C * arc;
  const fill = value / max * dash;
  return (
    <svg width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} stroke="var(--surface-sunken)" strokeWidth="10" fill="none"
      strokeDasharray={`${dash} ${C}`}
      transform={`rotate(${90 + offset * 360} ${cx} ${cy})`}
      strokeLinecap="round" />
      
      <circle cx={cx} cy={cy} r={r} stroke={color} strokeWidth="10" fill="none"
      strokeDasharray={`${fill} ${C}`}
      transform={`rotate(${90 + offset * 360} ${cx} ${cy})`}
      strokeLinecap="round" />
      
      <text x={cx} y={cy + 4} textAnchor="middle" style={{ font: '600 28px IBM Plex Sans', fill: 'var(--ink)' }}>
        {label ?? value}
      </text>
      {sublabel &&
      <text x={cx} y={cy + 24} textAnchor="middle" style={{ font: '11px IBM Plex Sans', fill: 'var(--ink-mute)' }}>
          {sublabel}
        </text>
      }
    </svg>);

}

/* ──────────────────────────────────────────────────────────────
 * 1. Overview (reimagined)
 * ────────────────────────────────────────────────────────────── */
function ReimOverview({ isDark }) {
  return (
    <FrameReimag menu="Overview" entity={E} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto 1fr', gap: 20, height: '100%' }}>

        {/* Hero strip ─ score / status / next-step ─────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1.2fr', gap: 16 }}>
          {/* Score — INFO teal (neutral hero fact, no value judgement) */}
          <div className="card-info" style={{ padding: "20px", width: "457px" }}>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Your signal score</div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 18, marginTop: 8, width: "453px" }}>
              <div className="num-xl" style={{ color: 'var(--info-deep)', fontSize: "64px" }}>724</div>
              <div style={{ paddingBottom: 10, height: "8px" }}>
                <div className="pos" style={{ fontWeight: 600, fontSize: 14 }}>+18 since last quote</div>
                <Sparkline points={[680, 692, 688, 705, 712, 718, 724]} color="var(--info-deep)" />
              </div>
            </div>
            <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <span className="chip chip-pos"><Icon name="check" size={12} /> Standard tier</span>
              <span className="chip chip-info"><Icon name="trending-up" size={12} /> 64th percentile</span>
            </div>
          </div>

          {/* Premium */}
          <div className="card" style={{ padding: "20px", width: "34px" }}>
            <div className="eyebrow">Annual premium</div>
            <div className="num" style={{ marginTop: 8 }}>$487,700</div>
            <div className="caption" style={{ marginTop: 4 }}>Across 3 active policies</div>
            <div style={{ display: 'flex', gap: 16, marginTop: 14 }}>
              <div>
                <div className="micro">Cyber</div>
                <div className="num-sm">$185k</div>
              </div>
              <div>
                <div className="micro">PI</div>
                <div className="num-sm">$162k</div>
              </div>
              <div>
                <div className="micro">D&O</div>
                <div className="num-sm">$140k</div>
              </div>
            </div>
          </div>

          {/* Open action — SPOT coral, reserved for "awaiting you / urgent" */}
          <div className="card-spot" style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: "20px 20px 20px 22px" }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="eyebrow" style={{ color: 'var(--spot)' }}>Awaiting you</span>
              <span className="chip chip-spot">1 of 2</span>
            </div>
            <div>
              <div style={{ font: '600 16px/1.25 IBM Plex Sans', color: 'var(--ink)' }}>
                Hartford Mutual needs MFA attestation for the cyber bind
              </div>
              <div className="caption" style={{ marginTop: 4 }}>2 hours ago · Cyber referral</div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
              <button className="btn spot">Open thread</button>
              <button className="btn ghost">Snooze</button>
            </div>
          </div>
        </div>

        {/* Body: 3 panels ──────────────────────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr 1fr', gap: 16 }}>

          {/* Pulse — helping / hurting with bars */}
          <div className="card" style={{ padding: "20px" }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
              <div>
                <div className="eyebrow">Signal pulse</div>
                <h3 style={{ font: '600 18px/1 IBM Plex Sans', margin: '6px 0 0' }}>What's moving your premium</h3>
              </div>
              <span className="micro">cyber · primary line</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span className="chip chip-pos"><Icon name="arrow-down" size={12} /> Helping</span>
                  <span className="num-sm pos">−$28.1k</span>
                </div>
                {[
                ['MFA on admins', 12100, 12100],
                ['No prior claims (5y)', 9300, 12100],
                ['EDR coverage 95%+', 6700, 12100]].
                map((r, i) =>
                <div key={i} style={{ marginTop: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, gap: 8, whiteSpace: 'nowrap' }}>
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[0]}</span><span className="pos" style={{ fontWeight: 600, flexShrink: 0 }}>−${(r[1] / 1000).toFixed(1)}k</span>
                    </div>
                    <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
                      <div style={{ width: `${r[1] / r[2] * 100}%`, height: '100%', background: 'var(--pos)' }} />
                    </div>
                  </div>
                )}
              </div>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span className="chip chip-neg"><Icon name="arrow-up" size={12} /> Opportunity</span>
                  <span className="num-sm neg">+$40.7k</span>
                </div>
                {[
                ['SOC 2 Type II', 18200, 18200],
                ['Backup encryption', 11400, 18200],
                ['Public RDP exposed', 6200, 18200]].
                map((r, i) =>
                <div key={i} style={{ marginTop: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, gap: 8, whiteSpace: 'nowrap' }}>
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[0]}</span><span className="neg" style={{ fontWeight: 600, flexShrink: 0 }}>+${(r[1] / 1000).toFixed(1)}k</span>
                    </div>
                    <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 4, overflow: 'hidden' }}>
                      <div style={{ width: `${r[1] / r[2] * 100}%`, height: '100%', background: 'var(--neg)' }} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Peer dial */}
          <div className="card" style={{ padding: "20px 20px 20px 22px" }}>
            <div className="eyebrow">Cohort standing</div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>You're ahead of two-thirds of comparable peers</h3>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Dial value={64} max={100} label="64th" sublabel="percentile" color="var(--info)" />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div>
                  <div className="micro">cohort median</div>
                  <div className="num-sm">714</div>
                </div>
                <div>
                  <div className="micro">your score</div>
                  <div className="num-sm info">724</div>
                </div>
                <div>
                  <div className="micro">top decile</div>
                  <div className="num-sm">784</div>
                </div>
              </div>
            </div>
            <div className="caption" style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
              <span className="info" style={{ fontWeight: 600 }}>60 points of headroom</span> to the top-decile profile in your cohort of 38 peers.
            </div>
          </div>

          {/* Loss + Exposure compact */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="card-pos" style={{ padding: "2px" }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div className="eyebrow" style={{ color: 'var(--pos)' }}>Loss outlook</div>
                  <div className="num-sm" style={{ marginTop: 4, color: 'var(--pos)' }}>Low</div>
                  <div className="caption" style={{ marginTop: 2 }}>Frequency improving · 2 claims / 36mo</div>
                </div>
                <Sparkline points={[6, 5, 4, 4, 3, 3, 2]} color="var(--pos)" />
              </div>
            </div>
            <div className="card-aux" style={{ padding: "20px" }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div className="eyebrow">Exposure</div>
                  <div className="num-sm" style={{ marginTop: 4, color: 'var(--aux)' }}>$118M</div>
                  <div className="caption" style={{ marginTop: 2 }}>Mid-market · 2 states · diversified</div>
                </div>
                <Sparkline points={[88, 94, 99, 108, 112, 115, 118]} color="var(--aux)" />
              </div>
            </div>
            <div className="card-tinted" style={{ padding: "20px" }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div className="eyebrow">Coverage shape</div>
                  <div className="num-sm" style={{ marginTop: 4 }}>3 lines · tier 2-4</div>
                  <div className="caption" style={{ marginTop: 2 }}>Cyber leads spend</div>
                </div>
                {/* tiny stacked bar */}
                <div style={{ width: 80, height: 8, borderRadius: 4, overflow: 'hidden', display: 'flex' }}>
                  <div style={{ flex: 185, background: 'var(--info)' }} />
                  <div style={{ flex: 162, background: 'var(--aux)' }} />
                  <div style={{ flex: 140, background: 'var(--ink-soft)' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </FrameReimag>);

}

/* ──────────────────────────────────────────────────────────────
 * 2. Risk Insights (reimagined) — premium impact as a waterfall
 * ────────────────────────────────────────────────────────────── */
function ReimDrivers({ isDark }) {
  // waterfall: base → strengths (down) → drags (up) → final
  const items = [
  { label: 'Base', value: 157000, type: 'base' },
  { label: 'MFA on admin', value: -12100, type: 'pos' },
  { label: 'No prior claims', value: -9300, type: 'pos' },
  { label: 'EDR coverage 95%+', value: -6700, type: 'pos' },
  { label: 'SOC 2 Type II', value: 18200, type: 'neg' },
  { label: 'Backup encryption', value: 11400, type: 'neg' },
  { label: 'Public-facing RDP', value: 6200, type: 'neg' },
  { label: 'IR playbook', value: 4900, type: 'neg' },
  { label: 'Final', value: 185200, type: 'final' }];

  // Build waterfall positions
  let running = 0;
  const bars = items.map((it) => {
    if (it.type === 'base') {const b = { ...it, lo: 0, hi: it.value };running = it.value;return b;}
    if (it.type === 'final') {return { ...it, lo: 0, hi: it.value };}
    const lo = it.value > 0 ? running : running + it.value;
    const hi = it.value > 0 ? running + it.value : running;
    running += it.value;
    return { ...it, lo, hi };
  });
  const maxY = Math.max(...bars.map((b) => b.hi));
  const W = 740,H = 200,barW = W / bars.length - 12;

  return (
    <FrameReimag menu="Risk Insights" entity={E} isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto 1fr', gap: 18, height: '100%' }}>
        <div>
          <div className="eyebrow">Risk insights</div>
          <h2 className="display" style={{ marginTop: 6 }}>
            Your premium, broken down to the signal
          </h2>
        </div>

        {/* Headline math */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          <div className="card">
            <div className="eyebrow">Base premium</div>
            <div className="num" style={{ marginTop: 6 }}>$157,000</div>
            <div className="caption">Industry × revenue × limit</div>
          </div>
          <div className="card-pos">
            <div className="eyebrow" style={{ color: 'var(--pos)' }}>Strengths</div>
            <div className="num pos" style={{ marginTop: 6 }}>−$28.1k</div>
            <div className="caption">3 signals lowering your premium</div>
          </div>
          <div className="card-warn">
            <div className="eyebrow" style={{ color: 'var(--warn)' }}>Opportunity</div>
            <div className="num warn" style={{ marginTop: 6 }}>+$40.7k</div>
            <div className="caption">4 signals you could improve</div>
          </div>
          <div className="card-info">
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Final premium</div>
            <div className="num" style={{ marginTop: 6, color: 'var(--info-deep)' }}>$185,200</div>
            <div className="caption">As quoted by Hartford Mutual</div>
          </div>
        </div>

        {/* Waterfall */}
        <div className="card" style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 28 }}>
          <div>
            <div className="eyebrow">Premium build-up</div>
            <h3 style={{ font: '600 18px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>From base to bound — every signal accounted for</h3>
            <svg width={W} height={H + 30} viewBox={`0 0 ${W} ${H + 30}`}>
              {bars.map((b, i) => {
                const x = i * (W / bars.length) + 8;
                const yScale = H / maxY;
                const y = H - b.hi * yScale;
                const h = (b.hi - b.lo) * yScale;
                const fill = b.type === 'base' ? 'var(--ink-soft)' :
                b.type === 'final' ? 'var(--info)' :
                b.type === 'pos' ? 'var(--pos)' : 'var(--neg)';
                return (
                  <g key={i}>
                    <rect x={x} y={y} width={barW} height={h} fill={fill} rx="2" />
                    <text x={x + barW / 2} y={y - 4} textAnchor="middle"
                    style={{ font: '600 11px IBM Plex Sans', fill: 'var(--ink)' }}>
                      {b.type === 'pos' ? `−$${(Math.abs(b.value) / 1000).toFixed(1)}k` :
                      b.type === 'neg' ? `+$${(b.value / 1000).toFixed(1)}k` :
                      `$${(b.value / 1000).toFixed(0)}k`}
                    </text>
                    <text x={x + barW / 2} y={H + 14} textAnchor="middle"
                    style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-soft)' }}>
                      {b.label.length > 14 ? b.label.slice(0, 12) + '…' : b.label}
                    </text>
                  </g>);

              })}
              {/* dotted connector lines */}
              {bars.slice(0, -1).map((b, i) => {
                const next = bars[i + 1];
                if (next.type === 'final') return null;
                const x1 = i * (W / bars.length) + 8 + barW;
                const x2 = (i + 1) * (W / bars.length) + 8;
                const yScale = H / maxY;
                const y = H - b.hi * yScale;
                return <line key={`c-${i}`} x1={x1} y1={y} x2={x2} y2={y} stroke="var(--ink-mute)" strokeDasharray="3 3" strokeWidth="1" />;
              })}
            </svg>
          </div>

          {/* Side: loss + exposure mini cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <div className="eyebrow">Loss outlook</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 6 }}>
                <span className="num pos">Low</span>
                <span className="chip chip-pos"><Icon name="trending-down" size={12} /> Improving</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 10 }}>
                <div><div className="micro">Frequency</div><div className="num-sm">32</div></div>
                <div><div className="micro">Severity</div><div className="num-sm">41</div></div>
              </div>
            </div>
            <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 14 }}>
              <div className="eyebrow">Exposure</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 6 }}>
                <span className="num">$118M</span>
                <span className="chip">Mid-market</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 10 }}>
                <div><div className="micro">Size</div><div className="num-sm">64</div></div>
                <div><div className="micro">Complexity</div><div className="num-sm">47</div></div>
              </div>
            </div>
            <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 14, marginTop: 'auto' }}>
              <div className="caption">
                4 signals could shave <span className="info" style={{ fontWeight: 600 }}>$40.7k</span> off your renewal.
              </div>
              <button className="btn info" style={{ marginTop: 10 }}>See action plan →</button>
            </div>
          </div>
        </div>
      </div>
    </FrameReimag>);

}

Object.assign(window, { ReimOverview, ReimDrivers, Sparkline, Dial });