/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, bookByClient */

/* ============================================================
 * 10. Book Health — retention, depth, profitability
 *
 * Layout
 *   row 1 — title + KPI strip (clients, policies, premium, commission, yield)
 *   row 2 — three feature cards: retention / depth / profitability
 *   row 3 — premium by vertical + premium by line (2 cards)
 * ============================================================ */

function ReimBrokerHealth({ isDark }) {
  const clients = bookByClient();
  const policies = BROKER_BOOK;
  const totalPremium = policies.reduce((s, p) => s + p.premium, 0);
  const avgCommission = 11.6;
  const totalCommission = totalPremium * (avgCommission / 100);
  const retention = 92.4;
  const tenureMonths = 34;
  const avgLinesPerClient = policies.length / clients.length;
  const crossSell = clients.filter(c => c.policies.length >= 3).length / clients.length * 100;
  const avgPremiumPerClient = totalPremium / clients.length;

  // group by vertical for chart
  const byVertical = {};
  for (const p of policies) {
    byVertical[p.vertical] = (byVertical[p.vertical] || 0) + p.premium;
  }
  const verticals = Object.entries(byVertical)
    .map(([name, premium]) => ({ name, premium, share: premium / totalPremium * 100, count: policies.filter(p => p.vertical === name).length }))
    .sort((a, b) => b.premium - a.premium);

  // group by line
  const byLine = {};
  for (const p of policies) {
    byLine[p.line] = (byLine[p.line] || 0) + p.premium;
  }
  const lineRows = Object.entries(byLine)
    .map(([name, premium]) => ({ name, premium, share: premium / totalPremium * 100, count: policies.filter(p => p.line === name).length }))
    .sort((a, b) => b.premium - a.premium);

  return (
    <FrameReimag menu="Book Health" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 24 }}>
          <div>
            <div className="eyebrow">Book health</div>
            <h2 className="display" style={{ marginTop: 6 }}>Retention, depth, profitability</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              The business view of your book — beyond risk into the relationship + economics.
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, auto)', gap: 28 }}>
            <KpiSnug label="Clients"          value={clients.length} />
            <KpiSnug label="Policies"         value={policies.length} />
            <KpiSnug label="Total premium"    value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} />
            <KpiSnug label="Est. commission"  value={`$${(totalCommission / 1000).toFixed(0)}k`} tone="pos" />
            <KpiSnug label="Cmsn yield"       value={`${avgCommission}%`} />
          </div>
        </div>

        {/* three feature cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          <FeatureCard
            icon="trending-up"
            iconColor="var(--pos)"
            eyebrow="Retention"
            primaryValue={`${retention}%`}
            primaryLabel="Annual retention rate"
            primaryColor="var(--pos)"
            extra={[
              ['Average tenure', `${tenureMonths} mo`, `~${(tenureMonths / 12).toFixed(1)} yrs`],
              ['Renewing ≤60d',  '2 clients', 'BrightLeaf, TerraWind'],
            ]}
            footer="Indicative — production wires actual renewal history."
            barValue={retention}
            barMin={70}
            barMax={100}
            barColor="var(--pos)"
          />
          <FeatureCard
            icon="layers"
            iconColor="var(--info)"
            eyebrow="Depth of relationship"
            primaryValue={avgLinesPerClient.toFixed(2)}
            primaryLabel="Avg lines per client"
            primaryColor="var(--info)"
            extra={[
              ['Cross-sell (≥3 lines)',     `${Math.round(crossSell)}%`, 'Share holding 3+ lines'],
              ['Avg premium / client',      `$${(avgPremiumPerClient / 1000).toFixed(0)}k`, 'Book-weighted average'],
            ]}
            footer="Eastward (3 lines) and AscendCare (2 lines) anchor the relationship depth."
          />
          <FeatureCard
            icon="chart-pie"
            iconColor="var(--warn)"
            eyebrow="Profitability"
            primaryValue={`${avgCommission}%`}
            primaryLabel="Commission yield"
            primaryColor="var(--ink)"
            extra={[
              ['Est. annual commission', `$${(totalCommission / 1000).toFixed(0)}k`, 'Book-weighted'],
              ['Best-yielding line',     'Aspen (Marine)', '14.2% commission'],
            ]}
            footer="Production wires actual broker remuneration including contingents + overrides."
          />
        </div>

        {/* breakdowns */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <BreakdownCard title="Premium by vertical" rows={verticals} />
          <BreakdownCard title="Premium by coverage line" rows={lineRows} />
        </div>

        {/* footer note */}
        <div style={{
          padding: '12px 16px',
          background: 'var(--surface-sunken)',
          border: '1px solid var(--rule)',
          borderRadius: 10,
          display: 'flex', alignItems: 'flex-start', gap: 12,
        }}>
          <Icon name="info" size={16} color="var(--ink-soft)" style={{ marginTop: 2 }} />
          <span className="caption" style={{ lineHeight: 1.5 }}>
            Retention + tenure are synthesised for the demo; commission yield and per-line / per-vertical
            breakdowns are computed live from the placed book. See Risk Aggregation for peril-level
            concentration narratives.
          </span>
        </div>

      </div>
    </FrameReimag>
  );
}

function FeatureCard({ icon, iconColor, eyebrow, primaryValue, primaryLabel, primaryColor, extra, footer, barValue, barMin, barMax, barColor }) {
  return (
    <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 34, height: 34, borderRadius: 8,
          background: 'color-mix(in srgb, var(--surface) 86%, ' + iconColor + ' 14%)',
          color: iconColor,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Icon name={icon} size={18} />
        </div>
        <div className="eyebrow">{eyebrow}</div>
      </div>
      <div>
        <div className="num-xl" style={{ color: primaryColor, lineHeight: 1 }}>{primaryValue}</div>
        <div className="caption" style={{ marginTop: 4 }}>{primaryLabel}</div>
      </div>
      {barValue != null && (
        <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden' }}>
          <div style={{
            width: `${((barValue - barMin) / (barMax - barMin)) * 100}%`,
            height: '100%', background: barColor,
          }} />
        </div>
      )}
      <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {extra.map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>{row[0]}</div>
              <div className="micro" style={{ marginTop: 2 }}>{row[2]}</div>
            </div>
            <div style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontSize: 14 }}>{row[1]}</div>
          </div>
        ))}
      </div>
      {footer && <div className="caption" style={{ fontSize: 11.5, marginTop: 4 }}>{footer}</div>}
    </div>
  );
}

function BreakdownCard({ title, rows }) {
  const max = Math.max(...rows.map(r => r.share));
  return (
    <div className="card" style={{ padding: 22 }}>
      <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: '0 0 14px' }}>{title}</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {rows.map((r) => (
          <div key={r.name}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{r.name}</span>
              <span style={{ fontSize: 13, fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>
                ${(r.premium / 1000).toFixed(0)}k <span className="micro" style={{ fontWeight: 400 }}>({r.share.toFixed(0)}% · {r.count})</span>
              </span>
            </div>
            <div style={{ height: 5, background: 'var(--surface-sunken)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: `${(r.share / max) * 100}%`, height: '100%', background: 'var(--info)' }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ReimBrokerHealth });
