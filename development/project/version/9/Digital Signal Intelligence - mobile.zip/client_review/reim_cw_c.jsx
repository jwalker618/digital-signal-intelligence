/* global React, Icon, ClientWorkbenchFrame, WbCard, WbKpi, WbRow, CW, tierColor, decisionTone */

/* ============================================================
 * Client Workbench tabs — group C
 *   • Communications        (referral message thread, broker-scoped)
 *   • Opportunities & Risks (coverage gaps + risk flags)
 *   • Pipeline & Renewals   (state mix + upcoming renewals)
 * ============================================================ */

/* ─── 08 Communications ──────────────────────────────────────── */
function CwComms({ isDark }) {
  // Threads across Eastward's coverages — mirrors ReferralMessage rows.
  const threads = [
    {
      ref: 'REF-2026-04832', line: 'Cyber', carrier: 'Hartford Mutual', awaiting: 'client', age: '2h',
      ask: 'Need MFA AAL2 attestation before binding',
      messages: [
        { from: 'carrier', who: 'Hartford Mutual', body: 'Need an MFA AAL2 attestation on admin accounts before we can bind the cyber line.', at: 'Apr 28 · 09:12' },
        { from: 'broker',  who: 'You (Marsh)',      body: 'Requested from Eastward IT — Okta export should cover AAL2. Will forward today.', at: 'Apr 28 · 10:40', signal: 'identity.mfa_aal2 → pending' },
      ],
    },
    {
      ref: 'REF-2026-04833', line: 'Cyber', carrier: 'Hartford Mutual', awaiting: 'client', age: '1d',
      ask: 'SOC 2 Type II report or equivalent attestation requested',
      messages: [
        { from: 'carrier', who: 'Hartford Mutual', body: 'SOC 2 Type II not on file — please provide the report or an equivalent attestation.', at: 'Apr 27 · 14:05' },
      ],
    },
    {
      ref: 'REF-2026-04820', line: 'D&O', carrier: 'Chubb', awaiting: 'broker', age: '3d',
      ask: 'Updated board roster + bios for current FY',
      messages: [
        { from: 'carrier', who: 'Chubb',          body: 'For the D&O placement we need the current board roster and bios.', at: 'Apr 25 · 11:20' },
        { from: 'broker',  who: 'You (Marsh)',     body: 'Acknowledged — chasing Eastward company secretary.', at: 'Apr 25 · 16:02' },
      ],
    },
  ];
  const awaitingYou = threads.filter(t => t.awaiting === 'broker').length;

  return (
    <ClientWorkbenchFrame active="Communications" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
          <CwcKpi label="Open threads" value={threads.length} tone="info" />
          <CwcKpi label="Awaiting you" value={awaitingYou} tone="spot" />
          <CwcKpi label="Avg response" value={`${CW.avgResponseHours}h`} />
          <CwcKpi label="Last activity" value={CW.lastMessage} />
        </div>

        <WbCard title="Referral threads" icon="messages-square" headerRight={<span className="chip chip-spot">{awaitingYou} on you</span>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {threads.map((t) => (
              <div key={t.ref} style={{ border: '1px solid var(--rule)', borderRadius: 10, overflow: 'hidden' }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px',
                  background: 'var(--surface-elev)', borderBottom: '1px solid var(--rule)',
                }}>
                  <span className="chip">{t.line}</span>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{t.ask}</span>
                  <span style={{ flex: 1 }} />
                  <span className={`chip ${t.awaiting === 'broker' ? 'chip-spot' : 'chip-info'}`}>
                    {t.awaiting === 'broker' ? 'on you' : 'on client'}
                  </span>
                  <span className="micro">{t.age}</span>
                </div>
                <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {t.messages.map((m, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, justifyContent: m.from === 'broker' ? 'flex-end' : 'flex-start' }}>
                      <div style={{ maxWidth: '74%' }}>
                        <div style={{
                          padding: '9px 12px', borderRadius: 10, fontSize: 12.5, lineHeight: 1.45,
                          background: m.from === 'broker' ? 'var(--info-soft)' : 'var(--surface-sunken)',
                          border: '1px solid var(--rule)',
                          color: 'var(--ink)',
                        }}>{m.body}</div>
                        <div className="micro" style={{ marginTop: 4, textAlign: m.from === 'broker' ? 'right' : 'left' }}>
                          {m.who} · {m.at}
                        </div>
                        {m.signal && (
                          <div style={{ marginTop: 4, textAlign: m.from === 'broker' ? 'right' : 'left' }}>
                            <span className="chip chip-info" style={{ fontFamily: 'ui-monospace, monospace', fontSize: 10.5 }}>{m.signal}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </WbCard>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 09 Opportunities & Risks ───────────────────────────────── */
function CwOpps({ isDark }) {
  const opps = [
    { line: 'Tech E&O',       rationale: 'Robotics integrators in the cohort carry standalone tech E&O; Eastward has none today.', range: [120000, 210000] },
    { line: 'Cyber — limit',  rationale: 'Current $10M cyber limit sits below the cohort median for $50M–250M revenue. Room to upsell.', range: [40000, 80000] },
    { line: 'Product Liab.',  rationale: 'Heavy-equipment floor exposure. Industry default to carry product liability.', range: [110000, 190000] },
  ];
  const risks = [
    { flag: 'D&O in Tier 4',          detail: 'D&O placement scores 648 (T4). Renewal pricing pressure likely — pre-empt with carrier.', sev: 'high' },
    { flag: 'SOC 2 Type II missing',  detail: 'Holding up the cyber bind; carrier requested attestation 1d ago.', sev: 'med' },
    { flag: 'Public RDP exposed',     detail: 'One internet-facing RDP host detected in discovery — a recurring underwriting drag.', sev: 'med' },
  ];
  const sevColor = (s) => s === 'high' ? 'var(--neg)' : s === 'med' ? 'var(--warn)' : 'var(--ink-soft)';

  return (
    <ClientWorkbenchFrame active="Opportunities & Risks" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, alignContent: 'start' }}>
        <WbCard title="Opportunities" icon="trending-up" headerRight={<span className="chip chip-info">{opps.length} coverage gaps</span>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {opps.map((o) => (
              <div key={o.line} style={{ padding: 14, border: '1px solid var(--rule)', borderRadius: 10, borderLeft: '4px solid var(--info)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                  <span style={{ fontSize: 14, fontWeight: 700 }}>{o.line}</span>
                  <span className="micro" style={{ fontVariantNumeric: 'tabular-nums' }}>est. ${(o.range[0] / 1000).toFixed(0)}k–${(o.range[1] / 1000).toFixed(0)}k</span>
                </div>
                <div className="caption" style={{ fontSize: 12.5, lineHeight: 1.5 }}>{o.rationale}</div>
              </div>
            ))}
          </div>
        </WbCard>

        <WbCard title="Risk flags" icon="triangle-alert" headerRight={<span className="chip chip-spot">{risks.length} flagged</span>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {risks.map((r) => (
              <div key={r.flag} style={{ padding: 14, border: '1px solid var(--rule)', borderRadius: 10, borderLeft: `4px solid ${sevColor(r.sev)}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                  <span style={{ fontSize: 14, fontWeight: 700 }}>{r.flag}</span>
                  <span className="chip" style={{ color: sevColor(r.sev), borderColor: sevColor(r.sev), textTransform: 'uppercase', fontSize: 10 }}>{r.sev}</span>
                </div>
                <div className="caption" style={{ fontSize: 12.5, lineHeight: 1.5 }}>{r.detail}</div>
              </div>
            ))}
          </div>
        </WbCard>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 10 Pipeline & Renewals ─────────────────────────────────── */
function CwPipeline({ isDark }) {
  const stages = ['Submitted', 'Scored', 'Referred', 'Quoted', 'Bound'];
  const coverageStage = { 'SUB-26-0118': 2, 'SUB-26-0119': 4, 'SUB-26-0120': 2 }; // index into stages
  const renewals = CW.coverages
    .map(c => ({ ...c, days: c.code === 'SUB-26-0118' ? 38 : c.code === 'SUB-26-0119' ? 38 : 38 }))
    .sort((a, b) => a.days - b.days);

  return (
    <ClientWorkbenchFrame active="Pipeline & Renewals" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Placement pipeline" icon="git-branch" headerRight={<span className="chip">{CW.coverages.length} coverages</span>}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {CW.coverages.map((c) => {
              const stageIdx = coverageStage[c.code];
              return (
                <div key={c.code}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 700 }}>{c.line}</span>
                    <span className="micro">{c.carrier}</span>
                    <span style={{ flex: 1 }} />
                    <span className={`chip chip-${c.statusTone}`}>{c.status}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
                    {stages.map((s, i) => {
                      const done = i <= stageIdx;
                      const isCur = i === stageIdx;
                      return (
                        <React.Fragment key={s}>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, minWidth: 0 }}>
                            <div style={{
                              width: 16, height: 16, borderRadius: '50%', flexShrink: 0,
                              background: done ? (isCur ? 'var(--spot)' : 'var(--pos)') : 'var(--surface-sunken)',
                              border: `2px solid ${done ? (isCur ? 'var(--spot)' : 'var(--pos)') : 'var(--rule-strong)'}`,
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                            }}>
                              {done && !isCur && <Icon name="check" size={9} color="#fff" />}
                            </div>
                            <span className="micro" style={{ fontSize: 10, color: isCur ? 'var(--spot)' : done ? 'var(--ink)' : 'var(--ink-mute)', fontWeight: isCur ? 700 : 400 }}>{s}</span>
                          </div>
                          {i < stages.length - 1 && (
                            <div style={{ flex: 1, height: 2, background: i < stageIdx ? 'var(--pos)' : 'var(--rule)', marginTop: -16 }} />
                          )}
                        </React.Fragment>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </WbCard>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14 }}>
          <WbCard title="Upcoming renewals" icon="calendar-clock" headerRight={<span className="chip chip-warn">all within 60d</span>}>
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr 1.3fr 110px 120px',
              padding: '0 0 8px', borderBottom: '1px solid var(--rule)',
            }}>
              {['Line', 'Carrier', 'Premium', 'Renews in'].map(h => <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>)}
            </div>
            {renewals.map((c, i) => (
              <div key={c.code} style={{
                display: 'grid', gridTemplateColumns: '1fr 1.3fr 110px 120px', alignItems: 'center',
                padding: '11px 0', borderBottom: i < renewals.length - 1 ? '1px solid var(--rule)' : 0, fontSize: 13,
              }}>
                <span style={{ fontWeight: 600 }}>{c.line}</span>
                <span style={{ color: 'var(--ink-soft)' }}>{c.carrier}</span>
                <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(c.premium / 1000).toFixed(0)}k</span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--warn)', fontWeight: 600 }}>
                  <Icon name="clock" size={12} />{c.days}d
                </span>
              </div>
            ))}
            <div className="caption" style={{ marginTop: 12 }}>
              All three coverages renew on the same cycle — a combined renewal review is the efficient play.
            </div>
          </WbCard>

          <WbCard title="Pipeline state" icon="chart-pie" padding={18}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 2 }}>
              {[
                { label: 'Bound',    n: CW.coverages.filter(c => c.status === 'Bound').length, tone: 'pos' },
                { label: 'Referred', n: CW.coverages.filter(c => c.decision === 'refer').length, tone: 'spot' },
                { label: 'Declined', n: 0, tone: 'neg' },
              ].map(s => (
                <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: `var(--${s.tone})`, flexShrink: 0 }} />
                  <span style={{ fontSize: 13, flex: 1 }}>{s.label}</span>
                  <span style={{ fontSize: 15, fontWeight: 700, color: `var(--${s.tone})`, fontVariantNumeric: 'tabular-nums' }}>{s.n}</span>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 14, paddingTop: 10, borderTop: '1px solid var(--rule)' }}>
              Two referrals open against the cyber and D&O lines; PI is bound.
            </div>
          </WbCard>
        </div>

      </div>
    </ClientWorkbenchFrame>
  );
}

/* Thin wrapper over the shared <Kpi> primitive. */
function CwcKpi(props) {
  return <Kpi {...props} surface="card" />;
}

Object.assign(window, { CwComms, CwOpps, CwPipeline });
