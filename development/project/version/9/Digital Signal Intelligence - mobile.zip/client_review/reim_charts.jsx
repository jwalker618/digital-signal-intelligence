/* global React, FrameReimag, Icon */

/* ============================================================
 * Reusable visualization primitives used across reimagined pages.
 * Split out so Overview / Drivers / etc. can share them.
 * ============================================================ */

/* ─── Simple monotone sparkline (kept for compact use) ─────────── */
function Sparkline({ points, color = 'var(--ink)', height = 28, width = 80 }) {
  const max = Math.max(...points), min = Math.min(...points);
  const path = points.map((p, i) => {
    const x = (i / (points.length - 1)) * width;
    const y = height - ((p - min) / (max - min || 1)) * height;
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      <path d={path} fill="none" stroke={color} strokeWidth="1.75" strokeLinecap="round" />
    </svg>
  );
}

/* ─── ScoreHistory — annotated time-series with markers ──────────
 *  Shows the score across quotes/snapshots over time, with the
 *  previous quote and current values labelled inline.
 *
 *  Props
 *    history: [{ label, value, marker? }]      — points to plot
 *    color:   primary stroke color (defaults to info)
 *
 *  The last point is always rendered as "current"; any point where
 *  `marker === 'prev'` is labelled as the previous quote anchor.
 */
function ScoreHistory({ history, color = 'var(--info-deep)' }) {
  const W = 380, H = 96, PAD_X = 14, PAD_TOP = 22, PAD_BOTTOM = 22;
  const vals = history.map(h => h.value);
  const min = Math.min(...vals) - 8;
  const max = Math.max(...vals) + 8;
  const pts = history.map((h, i) => {
    const x = PAD_X + (i / (history.length - 1)) * (W - 2 * PAD_X);
    const y = H - PAD_BOTTOM - ((h.value - min) / (max - min)) * (H - PAD_TOP - PAD_BOTTOM);
    return { ...h, x, y };
  });
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const area = `${path} L${pts[pts.length - 1].x.toFixed(1)},${H - PAD_BOTTOM} L${pts[0].x.toFixed(1)},${H - PAD_BOTTOM} Z`;

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block', overflow: 'visible' }}>
      {/* baseline rule */}
      <line x1="0" y1={H - PAD_BOTTOM} x2={W} y2={H - PAD_BOTTOM} stroke="var(--rule)" strokeWidth="1" />
      <path d={area} fill={color} opacity="0.10" />
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" />
      {pts.map((p, i) => {
        const isLast = i === pts.length - 1;
        const isPrev = p.marker === 'prev';
        const isHighlight = isLast || isPrev;
        return (
          <g key={i}>
            <circle
              cx={p.x} cy={p.y}
              r={isLast ? 5 : isPrev ? 4.5 : 2.5}
              fill={isHighlight ? color : 'var(--surface)'}
              stroke={color} strokeWidth="1.5"
            />
            <text x={p.x} y={H - 6} textAnchor="middle"
              style={{ font: '10px IBM Plex Sans', fill: isHighlight ? 'var(--ink)' : 'var(--ink-mute)', fontWeight: isHighlight ? 600 : 400 }}>
              {p.label}
            </text>
            {isHighlight && (
              <text x={p.x} y={p.y - 10} textAnchor="middle"
                style={{ font: '600 11px IBM Plex Sans', fill: color }}>
                {p.value}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

/* ─── CohortBar — horizontal distribution strip ──────────────────
 *  Replaces the radial dial. Shows the cohort's score range as a
 *  bar with bands (mid / top quartile / top decile), explicit
 *  markers for median + top decile, and a tall pin for "you".
 *
 *  Props
 *    value:  the subject's score
 *    median: cohort median
 *    topDecile: cohort top-decile threshold
 *    range:  [min, max] visible scale
 */
function CohortBar({ value, median, topDecile, range }) {
  const W = 360, H = 96, PAD_X = 6;
  const scale = (v) => PAD_X + ((v - range[0]) / (range[1] - range[0])) * (W - 2 * PAD_X);
  const youX = scale(value);
  const barY = 50, barH = 14;
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: 'block' }}>
      {/* base track */}
      <rect x={PAD_X} y={barY} width={W - 2 * PAD_X} height={barH} fill="var(--surface-sunken)" rx={barH / 2} />
      {/* top-decile zone */}
      <rect x={scale(topDecile)} y={barY} width={W - PAD_X - scale(topDecile)} height={barH}
        fill="var(--pos-soft)" rx={barH / 2} />
      {/* median tick */}
      <line x1={scale(median)} y1={barY - 4} x2={scale(median)} y2={barY + barH + 4}
        stroke="var(--ink-mute)" strokeWidth="1.5" />
      <text x={scale(median)} y={barY + barH + 18} textAnchor="middle"
        style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-mute)' }}>median {median}</text>
      {/* top-decile tick */}
      <line x1={scale(topDecile)} y1={barY - 4} x2={scale(topDecile)} y2={barY + barH + 4}
        stroke="var(--pos)" strokeWidth="1.5" />
      <text x={scale(topDecile)} y={barY + barH + 18} textAnchor="middle"
        style={{ font: '10px IBM Plex Sans', fill: 'var(--pos)' }}>top 10% {topDecile}</text>
      {/* you pin */}
      <line x1={youX} y1={barY - 14} x2={youX} y2={barY + barH + 6}
        stroke="var(--info)" strokeWidth="2.5" />
      <circle cx={youX} cy={barY + barH / 2} r="7" fill="var(--info)" stroke="var(--surface)" strokeWidth="2" />
      <rect x={youX - 28} y={barY - 30} width="56" height="18" fill="var(--info)" rx="4" />
      <text x={youX} y={barY - 17} textAnchor="middle"
        style={{ font: '600 11px IBM Plex Sans', fill: '#fff' }}>YOU · {value}</text>
      {/* axis ends */}
      <text x={PAD_X} y={barY - 6} style={{ font: '9.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{range[0]}</text>
      <text x={W - PAD_X} y={barY - 6} textAnchor="end" style={{ font: '9.5px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{range[1]}</text>
    </svg>
  );
}

/* ─── PremiumBreakdown — proportional bar that handles N policies ─
 *  Lays out the top-3 segments explicitly; everything else is
 *  collapsed into a "+N more" segment. Same component covers the
 *  3-policy case (Eastward today) and a hypothetical 10-policy book.
 *
 *  Props
 *    policies: [{ name, amount, color }]
 *    maxVisible: how many segments to render individually (default 3)
 */
function PremiumBreakdown({ policies, maxVisible = 3 }) {
  const sorted = [...policies].sort((a, b) => b.amount - a.amount);
  const visible = sorted.slice(0, maxVisible);
  const rest    = sorted.slice(maxVisible);
  const restSum = rest.reduce((s, p) => s + p.amount, 0);
  const segs = restSum > 0
    ? [...visible, { name: `+${rest.length} more`, amount: restSum, color: 'var(--ink-soft)' }]
    : visible;
  const total = sorted.reduce((s, p) => s + p.amount, 0);
  return (
    <div>
      {/* stacked bar */}
      <div style={{
        display: 'flex', height: 14, borderRadius: 7, overflow: 'hidden',
        marginTop: 12, background: 'var(--surface-sunken)',
      }}>
        {segs.map((p, i) => (
          <div key={i} title={`${p.name} · $${p.amount.toLocaleString()}`}
            style={{
              flex: p.amount, background: p.color,
              borderRight: i < segs.length - 1 ? '2px solid var(--surface)' : 0,
            }} />
        ))}
      </div>
      {/* legend */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginTop: 14 }}>
        {segs.map((p, i) => (
          <div key={i}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 8, height: 8, background: p.color, borderRadius: 2 }} />
              <span className="micro">{p.name}</span>
            </div>
            <div className="num-sm" style={{ fontSize: 14, marginTop: 2 }}>
              ${(p.amount / 1000).toFixed(0)}k
            </div>
            <div className="micro">{Math.round((p.amount / total) * 100)}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Sparkline, ScoreHistory, CohortBar, PremiumBreakdown });
