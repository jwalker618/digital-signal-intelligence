/* global React, FrameReimag, Icon */

/* ============================================================
 * Admin Console — 7 artboards spanning the 6 admin functions
 *
 *   01 System Health — uptime, pipeline latencies, extractor health
 *   02 Users & Roles — invite + user table + role definitions
 *   03 Configs       — config versions, deploy actions
 *   04 Audit Log     — filterable event log with diff expander
 *   05 Loss Register — CSV import + loss event table
 *   06 Recalibration — proposal list
 *   07 Recalibration · detail — single proposal with governance actions
 *
 * Common chrome via FrameReimag persona="admin".
 * ============================================================ */

const ADMIN_ORG = 'Hartford Mutual';

/* ─── 01 System Health ──────────────────────────────────────── */
function ReimAdminHealth({ isDark }) {
  const components = [
    { name: 'API server',         status: 'green', detail: 'p99 142ms · 2 instances healthy' },
    { name: 'Postgres (primary)', status: 'green', detail: 'connections 24/200 · lag 0ms' },
    { name: 'Postgres (replica)', status: 'green', detail: 'replication lag 12ms' },
    { name: 'Redis',              status: 'green', detail: 'memory 38% · hit-rate 96.4%' },
    { name: 'Object store',       status: 'amber', detail: 'one bucket nearing quota (84%)' },
    { name: 'Email relay',        status: 'green', detail: 'last delivery 12s ago' },
  ];
  const extractors = [
    { name: 'cyber.mfa_extractor',    mode: 'live',     success: 8420, errors:  3, status: 'green', lastError: '—' },
    { name: 'property.cope_extractor', mode: 'live',     success: 3120, errors:  8, status: 'green', lastError: 'COPE doc parse — non-standard format' },
    { name: 'pharma.recall_extractor', mode: 'shadow',   success:  892, errors: 14, status: 'amber', lastError: 'FDA feed timeout (transient)' },
    { name: 'energy.flood_extractor',  mode: 'live',     success: 1680, errors:  1, status: 'green', lastError: '—' },
    { name: 'logistics.tms_extractor', mode: 'shadow',   success:  420, errors: 22, status: 'amber', lastError: 'Schema drift — investigating' },
  ];
  const statusColor = (s) => s === 'green' ? 'var(--pos)' : s === 'amber' ? 'var(--warn)' : 'var(--neg)';

  return (
    <FrameReimag menu="System Health" entity={ADMIN_ORG} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + status pill */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">System health</div>
            <h2 className="display" style={{ marginTop: 6 }}>All systems operational</h2>
            <div className="caption" style={{ marginTop: 6 }}>Auto-refresh every 30s · last check 14s ago</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="chip chip-pos" style={{ padding: '6px 12px', fontSize: 13 }}>
              <Icon name="check-circle-2" size={13} /> 5 of 6 green
            </span>
            <button className="btn ghost"><Icon name="refresh-cw" size={13} /> Refresh</button>
          </div>
        </div>

        {/* pipeline KPIs */}
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
            <div>
              <div className="eyebrow">Pipeline · last 24h</div>
              <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Throughput + latencies</h3>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
            <AdminKpi label="Assessments" value="12,840" sub="+8% vs 7d" />
            <AdminKpi label="p50"          value="84 ms"   sub="median latency" />
            <AdminKpi label="p95"          value="312 ms"  sub="" tone="info" />
            <AdminKpi label="p99"          value="864 ms"  sub="" tone="warn" />
            <AdminKpi label="Failure rate" value="0.12%"   sub="2 errors / 1k" tone="pos" />
          </div>
        </div>

        {/* components + extractors */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Components</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 12px' }}>Subsystems</h3>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {components.map((c, i) => (
                <div key={c.name} style={{
                  display: 'grid', gridTemplateColumns: '12px 1fr',
                  gap: 12, alignItems: 'flex-start',
                  padding: '10px 0',
                  borderBottom: i < components.length - 1 ? '1px solid var(--rule)' : 0,
                }}>
                  <div style={{
                    width: 10, height: 10, borderRadius: '50%',
                    background: statusColor(c.status),
                    marginTop: 5,
                  }} />
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{c.name}</div>
                    <div className="micro" style={{ marginTop: 2 }}>{c.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{
              padding: '14px 20px', borderBottom: '1px solid var(--rule)',
              background: 'var(--surface-elev)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Extractors</h3>
              <span className="chip">{extractors.length} active</span>
            </div>
            <AdminTable
              cols="2fr 90px 90px 80px 100px 1.6fr"
              headers={['Extractor', 'Mode', 'Success', 'Errors', 'Status', 'Last error']}
              rows={extractors.map((e) => [
                <code style={{ fontSize: 12 }}>{e.name}</code>,
                <span className="caption">{e.mode}</span>,
                <span style={{ fontVariantNumeric: 'tabular-nums' }}>{e.success.toLocaleString()}</span>,
                <span style={{ fontVariantNumeric: 'tabular-nums', color: e.errors > 10 ? 'var(--warn)' : 'var(--ink-soft)' }}>{e.errors}</span>,
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: statusColor(e.status) }} />
                  <span style={{ textTransform: 'capitalize', fontWeight: 600 }}>{e.status}</span>
                </span>,
                <span style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{e.lastError}</span>,
              ])}
            />
          </div>
        </div>
      </div>
    </FrameReimag>
  );
}

/* ─── Shared admin atoms ──────────────────────────────────────── */

function AdminKpi({ label, value, sub, tone }) {
  const color = tone === 'pos' ? 'var(--pos)' : tone === 'info' ? 'var(--info)' : tone === 'warn' ? 'var(--warn)' : 'var(--ink)';
  return (
    <div style={{
      padding: 14,
      background: 'var(--surface-elev)',
      border: '1px solid var(--rule)',
      borderRadius: 10,
    }}>
      <div className="micro">{label}</div>
      <div className="num" style={{ fontSize: 24, color, marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
      {sub && <div className="micro" style={{ marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function AdminTable({ cols, headers, rows, dense }) {
  return (
    <>
      <div style={{
        display: 'grid', gridTemplateColumns: cols,
        padding: '8px 20px',
        background: 'var(--surface-sunken)',
        borderBottom: '1px solid var(--rule)',
      }}>
        {headers.map((h) => <span key={h} className="micro" style={{ fontSize: 11, letterSpacing: '0.06em' }}>{h}</span>)}
      </div>
      {rows.map((row, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: cols,
          gap: 0, alignItems: 'center',
          padding: dense ? '8px 20px' : '12px 20px',
          borderBottom: i < rows.length - 1 ? '1px solid var(--rule)' : 0,
          fontSize: 13,
        }}>
          {row.map((cell, j) => <div key={j}>{cell}</div>)}
        </div>
      ))}
    </>
  );
}

/* ─── 02 Users & Roles ─────────────────────────────────────── */
function ReimAdminUsers({ isDark }) {
  const users = [
    { email: 'jordan.reyes@hartfordmutual.com', name: 'Jordan Reyes', role: 'CARRIER_UNDERWRITER', mfa: true,  status: 'active',   lastLogin: '14:22 today' },
    { email: 'olivia.cho@hartfordmutual.com',   name: 'Olivia Cho',   role: 'CARRIER_UNDERWRITER', mfa: true,  status: 'active',   lastLogin: '11:08 today' },
    { email: 'marcus.adams@hartfordmutual.com', name: 'Marcus Adams', role: 'ADMIN',               mfa: true,  status: 'active',   lastLogin: '08:42 today' },
    { email: 'priya.bhatt@hartfordmutual.com',  name: 'Priya Bhatt',  role: 'ANALYST',             mfa: true,  status: 'active',   lastLogin: 'yesterday' },
    { email: 'sasha.morales@marsh.com',         name: 'Sasha Morales', role: 'BROKER',             mfa: true,  status: 'active',   lastLogin: 'yesterday' },
    { email: 'eli.kovacic@eastwardrobotics.com', name: 'Eli Kovacic',  role: 'CLIENT',              mfa: false, status: 'active',   lastLogin: '3 days ago' },
    { email: 'dana.weiss@hartfordmutual.com',   name: 'Dana Weiss',   role: 'ANALYST',             mfa: false, status: 'inactive', lastLogin: '2 weeks ago' },
    { email: 'sam.lee@hartfordmutual.com',      name: 'Sam Lee',      role: 'CARRIER_UNDERWRITER', mfa: true,  status: 'locked',   lastLogin: '1 month ago' },
  ];
  const roles = [
    { name: 'ADMIN',                description: 'Full administrative access', users: 2,  perms: 38 },
    { name: 'CARRIER_UNDERWRITER',  description: 'Assess + decide on submissions', users: 8, perms: 22 },
    { name: 'BROKER',               description: 'Book of clients, placement, queries', users: 5, perms: 18 },
    { name: 'CLIENT',               description: 'Read-only on own policies', users: 12, perms: 9 },
    { name: 'ANALYST',              description: 'Reporting + recalibration', users: 4,  perms: 16 },
  ];
  const statusTone = (s) => s === 'active' ? 'pos' : s === 'locked' ? 'neg' : 'spot';

  return (
    <FrameReimag menu="Users & Roles" entity={ADMIN_ORG} persona="admin" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* title + KPIs */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div className="eyebrow">Users & roles</div>
            <h2 className="display" style={{ marginTop: 6 }}>Identity + access</h2>
            <div className="caption" style={{ marginTop: 6 }}>
              {users.length} users across {roles.length} roles. Manage invitations + access from here.
            </div>
          </div>
          <button className="btn"><Icon name="user-plus" size={14} /> Invite user</button>
        </div>

        {/* users table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name="users" size={16} />
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Users</h3>
              <span className="chip">{users.length}</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
              <span className="chip">Active</span>
              <span className="chip">Locked</span>
              <span className="chip">Inactive</span>
            </div>
          </div>
          <AdminTable
            cols="2fr 1.4fr 1.4fr 60px 110px 1fr 90px"
            headers={['Email', 'Name', 'Role', 'MFA', 'Status', 'Last login', '']}
            rows={users.map((u) => [
              <code style={{ fontSize: 12 }}>{u.email}</code>,
              <span style={{ fontWeight: 600 }}>{u.name}</span>,
              <span className="caption" style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}>{u.role}</span>,
              <span className="caption">{u.mfa ? 'on' : <span style={{ color: 'var(--warn)' }}>off</span>}</span>,
              <span className={`chip chip-${statusTone(u.status)}`} style={{ justifySelf: 'flex-start' }}>{u.status}</span>,
              <span className="micro">{u.lastLogin}</span>,
              u.status === 'active'
                ? <a href="#" style={{ fontSize: 12, color: 'var(--neg)' }}><Icon name="user-x" size={11} /> Deactivate</a>
                : <span className="micro">—</span>,
            ])}
          />
        </div>

        {/* roles table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name="shield-check" size={16} />
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Roles</h3>
              <span className="chip">{roles.length}</span>
            </div>
          </div>
          <AdminTable
            cols="1.6fr 2.5fr 80px 100px"
            headers={['Name', 'Description', 'Users', 'Permissions']}
            rows={roles.map((r) => [
              <span style={{ fontWeight: 700, fontFamily: 'ui-monospace, monospace', fontSize: 12 }}>{r.name}</span>,
              <span style={{ color: 'var(--ink-soft)' }}>{r.description}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>{r.users}</span>,
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{r.perms} perms</span>,
            ])}
          />
        </div>
      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimAdminHealth, ReimAdminUsers, AdminKpi, AdminTable });
