# Handoff — DSI portal: multi-coverage, coverage detail, broker book & mobile

> One evening's design session, packaged for implementation in the **`frontend/`**
> Next.js app. Every change below is mapped to the **exact real file(s)** it
> affects, with the current behavior, the target behavior, and the prototype
> file that demonstrates it.

---

## About the design files

The files in `prototype_reference/` are **design references written as standalone
HTML/React (Babel-in-browser) prototypes**. They are *not* production code to copy
in. They use plain globals, inline styles, and `iconify-icon` web components because
they run with no build step.

**Your job is to recreate the intent of these prototypes inside the existing
`frontend/` codebase**, using its established patterns:

- **Next.js App Router** pages under `src/app/(app)/…`
- **Tailwind + the existing token classes** (`text-ink`, `bg-surface`, `text-spot`,
  `var(--info)`, etc. — already defined in `globals.css` / `design-tokens.ts`)
- **The existing UI kit** in `src/components/ui` (`Card`, `Chip`, `Button`,
  `Eyebrow`, `NumDisplay`, `KpiSnug`, typography helpers)
- **Existing tone/format helpers** (`portalTone.ts`, `format.ts`, `coerce.ts`,
  `tier.ts`, `coverageIcon.ts`)
- **Existing data fetching** (`useRoleScopedFetch`, `fetchOverview`,
  `fetchSubmissionScore`, the `portal.ts` types)

Match the codebase, not the prototype's literal markup. Where the prototype uses
hard-coded mock data (e.g. `client_coverages.js`), the real implementation should
read the equivalent fields off the API types already defined in
`src/types/portal.ts` (`ClientCoverageEntry`, `ClientOverviewResponse`,
`BrokerOverviewResponse`, `ScoreResponse`, `ImpactBreakdown`, …).

## Fidelity

**High-fidelity.** Colors, spacing, typography and interaction are all final and
intentional. Recreate them faithfully using the codebase's existing primitives.

---

## The five changes (in priority order)

| # | Change | Real files | Type |
|---|--------|-----------|------|
| 1 | Multi-coverage across the client intelligence pages | `client/page.tsx`, `client/drivers`, `client/peers`, `client/scenarios`, `client/actions` | **Upgrade** existing per-coverage handling |
| 2 | Client-flavoured Coverage Detail drill-through | `client/coverages/page.tsx` (+ new `client/coverages/[code]`), `client/profile` | **New page**, replaces a jump |
| 3 | Broker "Book of Clients" layout fix for large books | `broker/page.tsx` | **Layout restructure** |
| 4 | Mobile companion redesign refinements | `app/m/*`, `components/mobile/*`, `lib/mobileFeed.ts` | **Refinement** of existing |
| 5 | (Prototype housekeeping only — see note) | n/a | No codebase work |

---

## 1 — Multi-coverage across the client intelligence pages

### The problem
Eastward Robotics holds **several coverages** (in the design: Cyber, Professional
Indemnity, D&O), and **each has its own** score, premium build-up, loss outlook,
exposure, cohort standing and action set. Today these five client pages mostly
collapse to a single "primary" coverage:

- **Summary** (`src/app/(app)/client/page.tsx`) — leads with one score.
- **Risk Insights** (`src/app/(app)/client/drivers/page.tsx`) — already scopes to
  one coverage via a **plain `<select>` `CoveragePicker`** (defaults to
  `active_coverages[0]`, switches with `?code=`). There is **no portfolio / "All"
  view**.
- **Industry Benchmarks** (`src/app/(app)/client/peers/page.tsx`)
- **Scenarios** (`src/app/(app)/client/scenarios/page.tsx`)
- **Action Plan** (`src/app/(app)/client/actions/page.tsx`)

### The target
Introduce a single, consistent **coverage switcher** — a segmented control
`[ All · Cyber · PI · D&O ]` — at the top of **all five** pages, replacing the bare
`<select>`. `All` renders a **portfolio roll-up**; any line re-renders the page for
that coverage. It must scale past three lines (horizontal overflow + a count badge
on "All", a status dot on lines with something awaiting).

**Build it once as a shared component** (the prototype defines it in
`client_switcher.jsx` as `CoverageSwitcher` + a `PageHead` wrapper). Suggested home:
`src/components/portal/CoverageSwitcher.tsx`. Replace the local `CoveragePicker`
in `drivers/page.tsx` with it, and add it to the other four pages. Keep driving the
selection off the existing `?code=` query param (and add a sentinel like
`code=all` for the portfolio view) so deep links and the existing
`fetchSubmissionScore(code)` flow keep working.

### Per-page specifics

- **Summary — portfolio-first.** `All` view leads with: a **premium-weighted
  blended score** (+ delta since last quote), **total premium** with a per-line
  split, and a **standing strip** — one clickable card per coverage showing its
  score, percentile, delta, status and a position-on-cohort micro-bar. Then "where
  the upside is" (premium opportunity by line). Selecting a line shows that line's
  full summary (score history, signal pulse, cohort bar, loss, exposure, terms).
  *Prototype: `reim_overview.jsx` → `PortfolioSummary` and `LineSummary`.*

- **Risk Insights — `All` = book totals + per-line build-up.** Four book-total
  cards (Base, Strengths, Opportunity, Final) and a "premium build-up by line" list
  (each line base→bound, click to drill). Per-line keeps the existing waterfall
  (the codebase already has `<Waterfall>` and `ImpactBreakdown`), but the neutral
  **base must reconcile**: `base − strengths + opportunity = final`.
  *Prototype: `reim_drivers.jsx` → `DriversPortfolio` / `DriversLine`.*

- **Industry Benchmarks — `All` = small multiples.** One compact cohort bar per
  line (each vs **its own** cohort/median/top-decile — they differ), plus top
  cross-line opportunities. Per-line shows the full bell-curve distribution + the
  peer-practice list. *Prototype: `reimagined_b.jsx` → `ReimPeers`,
  `PeersPortfolio`, `PeersLine`, `BellCurve`, `MiniCohort`.*

- **Scenarios — `All` = portfolio moves.** "Where to focus first" (lines ranked by
  premium-on-the-table), "add a new coverage line", "rebalance the book". Per-line
  keeps improve-signal / adjust-limit / restructure-tower, made line-specific.
  *Prototype: `reim_scenarios.jsx` → `ScenariosPortfolio` / `ScenariosLine`.*

- **Action Plan — `All` = cross-line leverage rank.** Every action across all lines,
  ranked by leverage (impact ÷ effort), each tagged with its line. Per-line shows
  just that line's ranked plan. *Prototype: `reimagined_b.jsx` → `ReimActions`.*

### Differentiated data (so the states read differently)
The prototype's three lines are deliberately distinct — preserve this character with
real data:
- **Cyber** — mid-pack, improving, several open opportunities.
- **PI** — top-quartile / preferred, **nothing awaiting, no open opportunities**
  (render the green "already optimised" empty state, not an empty table).
- **D&O** — below cohort median, **worsening** loss outlook, carries the book's
  single biggest opportunity.

Drive all of this off `active_coverages[]` and each coverage's `ScoreResponse` /
`ImpactBreakdown` — do **not** hard-code the three lines.

---

## 2 — Client-flavoured Coverage Detail (replace the jump to the submission)

### The problem
On **`src/app/(app)/client/coverages/page.tsx`**, each `PolicyRow` links to:

```tsx
<Link href={`/client/submissions/${policy.submission_code}`} …>
```

That destination is the **carrier-flavoured submission view** (submission codes,
underwriting chrome) — a jarring context switch for an insured. The Coverages list
is also the only place that shows all coverages, but it never shows the **full
detail** for any one of them.

### The target
Replace that link with an **in-place master → detail drill** (or a dedicated
`src/app/(app)/client/coverages/[code]/page.tsx` route) that shows the **full policy
record for one coverage in the client's own visual language**, with a clear
**"← All coverages"** back affordance. No submission chrome.

The detail page contains:
- **Header band** — coverage name, status chip, carrier, policy reference, renewal,
  score, premium.
- **KPI strip** — limit / aggregate, retention, territory, waiting period, underwriter.
- **Policy terms** — sub-limits table + key endorsements.
- **Placement status** — a timeline (Submitted → Quoted → Referred → In review →
  Bound), each coverage sitting at its real stage.
- **Premium snapshot** — base → strengths → opportunity → bound (links to Risk
  Insights for the full waterfall).
- **Loss outlook + exposure** — reuse the existing client `_components`
  (`LossOutlookCard`, `ExposureCard`) already in
  `src/app/(app)/client/_components/`.
- **Awaiting you** — coral card with open requests, OR a green "nothing awaiting /
  bound at preferred terms" state (PI).
- **Documents** — ready-to-download vs pending-from-you.
- **Your contacts** — broker + the line's underwriter.

*Prototype: `reim_coverages.jsx` → `ReimCoverages` (master list with internal
master/detail state via `initialOpen`), `ReimCoverageDetail`, `Timeline`,
`Contact`, `SnapCell`. Note the prototype's `COV_DETAIL` map is the **shape** of the
operational fields the detail needs (sub-limits, endorsements, timeline, documents,
underwriter) — wire these to the real API where available, and use the existing
`active_coverages` analytical fields for score/premium/cohort/loss/exposure.*

### Also: soften the Profile coverage rows
On **`src/app/(app)/client/profile/page.tsx`**, the coverage rows currently imply a
drill (chevron) into the same jarring destination. Remove the per-row chevron and
add a single hint pointing at the Coverages page for the full record
("Open any line in Coverages for its full policy record"). *Prototype: see the
edited rows in `reim_profile.jsx`.*

---

## 3 — Broker "Book of Clients": keep tier-mix & queries visible on large books

### The problem
On **`src/app/(app)/broker/page.tsx`** (the `BookBody` component), the layout is,
top to bottom:

1. Hero KPIs
2. **Book roster** — a `Card` (`pad="none"`) wrapping a `<table>` that **grows with
   its content** (no internal scroll, no max-height)
3. **Tier mix + Open queries** — a `grid lg:grid-cols-[1fr_1.4fr]` row **below** the
   roster

Because the roster grows unbounded, on any realistically large book the **Tier mix
and Open queries fall well below the fold** — yet they're the broker's at-a-glance
health and comms queue and should always be in view.

### The target
Restructure the working area below the hero into **two columns**:

- **Left — Book roster** in a **fixed-height panel that scrolls internally**
  (sticky header row + sticky column-header row; the `<tbody>` scrolls). In the
  prototype this is `max-height ≈ 828px`; use a sensible cap (or `min-h-0` inside a
  flex/grid track) so it never pushes siblings away.
- **Right — a pinned rail** holding **Tier mix** (with the "recent movements" block)
  and **Open queries** (with its filter tabs), always visible beside the roster
  regardless of roster length.

The page already has the search box, vertical filter chips, query filter tabs, tier
buckets and movements — **keep all of that**; this is purely a layout move
(roster → internal scroll; tier-mix + queries → right rail) so nothing falls off the
bottom. *Prototype: `reim_broker_book.jsx` → `ReimBrokerBook` — note the
`gridTemplateColumns: 'minmax(0,1fr) 392px'` two-column area, the roster card with
`maxHeight` + `overflowY:auto` body, and the right-hand `flex-col` rail.*

> The prototype also grows the mock book to ~20 policies / 10 clients to demonstrate
> the scroll. In the real app the book size comes from `data.clients` — no action
> needed beyond making the layout robust to large counts.

---

## 4 — Mobile companion redesign

The mobile app **already exists** in the codebase: route `src/app/m/page.tsx` →
`src/components/mobile/MobileApp.tsx`, with `FeedSections.tsx`, `SignalHero.tsx`,
`ReplySheet.tsx`, `primitives.tsx`, and the `src/lib/mobileFeed.ts` adapter (the
production twin of the prototype's `feed_data.js`, same single-feed shape:
`org / greeting / brief / climate / score / awaiting[] / glance[] / threads[] /
feed[]`).

Treat the prototype as a **visual-refinement reference** for that existing surface,
not a new build. The prototype demonstrates the intended single-scroll, no-tab-bar
"one intelligence feed" structure with: a frosted **glass header** + persona segment,
**climate strip**, **daily brief**, a **signal hero** (ring + sparkline + movers),
a **coral "awaiting you"** horizontal snap rail, a 2×2 **glance widget grid**
(incl. a tier-mix mini-chart tile), a **conversations** list opening a **reply
bottom-sheet with a smart-reply prefill**, a **signal-feed timeline**, a floating
**"Ask anything"** assistant pill, and light/dark via a header toggle.

*Prototype files: `mobile/widgets.jsx` (all the feed widgets + the `MOBILE_CSS`),
`mobile/app.jsx` (shell, glass header, persona switch, reply sheet, tweaks),
`mobile/feed_data.js` (the per-persona feed adapter — compare against the real
`mobileFeed.ts`).* Diff the prototype widgets against the current
`components/mobile/*` and pull across any spacing / hierarchy / interaction
refinements; keep reading data from `mobileFeed.ts`.

---

## 5 — Prototype housekeeping (no codebase work)

The prototype was originally one giant `Client portal review.html` canvas holding
every persona. This session also **split it into per-section entry pages + a hub**
(`index.html`, `Client portal.html`, `Broker portal.html`, …) purely so the
**prototype** loads faster for review. **This does not map to the codebase** — the
real app is already route-split by Next.js. No action; noted only so the extra HTML
files in the bundle aren't mistaken for a structural change.

---

## Design tokens (already in the codebase — use these, don't invent)

The prototype and the app share one palette. In the app these are Tailwind classes /
CSS vars already defined (`globals.css`, `src/lib/design-tokens.ts`):

- **Canvas / ink** — warm off-white canvas, navy ink (`bg-canvas`, `text-ink`,
  `text-ink-soft`, `text-ink-mute`); surfaces `bg-surface`, `bg-surface-elev`,
  `bg-surface-sunken`; hairlines `border-rule`, `border-rule-strong`.
- **Semantic tones** — **info/teal** = facts (`--info`, `--info-soft`,
  `--info-deep`), **spot/coral** = "awaiting you" / actions (`--spot`, …),
  **pos/green** = strengths, **neg/red** & **warn/amber** = risk, **aux/blue** =
  secondary. Tone→class mapping lives in `portalToneToTone` / `design-tokens.ts`.
- **Type** — IBM Plex Sans; tabular-nums for figures; the `Eyebrow / NumDisplay /
  Body / Micro / Caption` helpers already encode the scale.
- **Radii / shadow** — `rounded-card`, `rounded-btn`, `rounded-chip`; soft
  navy-tinted shadows (heavier in dark mode).

Tone/format helpers to reuse: `tierStatus`, `peerStanding(Positive)`,
`opportunityFromDrag` (`portalTone.ts`); `formatCurrency`, `formatText`
(`format.ts`); `compactCurrency` (`coerce.ts`); `tierToneOf`, `TIER_BAR`,
`TIER_TEXT` (`tier.ts`); `lineIcon` (`coverageIcon.ts`).

---

## Prototype reference files in this bundle

Under `prototype_reference/`:

| File | Demonstrates | Maps to |
|------|-------------|---------|
| `client_switcher.jsx` | `CoverageSwitcher`, `PageHead`, `StandingStrip`, `MiniCohort`, `OppByLineBar` | Change 1 (shared switcher) |
| `client_coverages.js` | Per-line data **shape** + portfolio roll-up math | Changes 1 & 2 (data fields) |
| `reim_overview.jsx` | Summary: `PortfolioSummary` + `LineSummary` | Change 1 (Summary) |
| `reim_drivers.jsx` | Risk Insights: portfolio totals + per-line waterfall | Change 1 (Risk Insights) |
| `reimagined_b.jsx` | Industry Benchmarks + Action Plan | Change 1 (Benchmarks, Actions) |
| `reim_scenarios.jsx` | Scenarios: portfolio + per-line | Change 1 (Scenarios) |
| `reim_coverages.jsx` | Coverage Detail master/detail | Change 2 |
| `reim_profile.jsx` | Softened profile coverage rows | Change 2 |
| `reim_broker_book.jsx` | Book of Clients: internal-scroll roster + pinned rail | Change 3 |
| `mobile/widgets.jsx`, `mobile/app.jsx`, `mobile/feed_data.js` | Mobile feed widgets, shell, adapter | Change 4 |

Open the corresponding HTML harness to see any prototype rendered:
`Client portal.html` (changes 1 & 2), `Broker portal.html` (change 3),
`mobile/DSI Mobile.html` (change 4).

---

## Suggested implementation order

1. **Change 3** (Book of Clients layout) — self-contained, one file, immediate value.
2. **Change 2** (Coverage Detail) — removes the worst UX wart; new route + soften profile.
3. **Change 1** (multi-coverage switcher) — biggest; build the shared `CoverageSwitcher`
   first, land it on Risk Insights (already half-there), then roll to the other four.
4. **Change 4** (mobile refinements) — diff against existing components, polish.
