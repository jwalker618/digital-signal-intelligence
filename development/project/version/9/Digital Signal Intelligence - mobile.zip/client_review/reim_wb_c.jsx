/* global React, WorkbenchFrame, WbCard, WbKpi, WbRow, WB, Icon, Ledger */

/* ============================================================
 * Workbench tabs · third batch — reference/structure tabs.
 *
 * Color discipline (carried from the rest of the system):
 *   • info teal  — reserved for THE hero fact per page (final/offered
 *                  premium, signal score). Not for every neutral fact.
 *   • coral spot — actions / awaiting / opportunity only.
 *   • pos green  — strengths, value-positive deltas, savings.
 *   • warn amber — attention, moderate effort.
 *   • neg red    — costs, hard exclusions.
 *   • plain ink  — every other fact (deductibles, periods, line %s, etc.)
 *
 * Tabs covered:
 *   • Exposure Assessment
 *   • Scenarios
 *   • Distribution               (Commercial)
 *   • Terms Overview             (Commercial)
 *   • Deductible Structure       (Risk)
 *   • SIR & Waiting Periods      (Risk)
 *   • Aggregate & Reinstatement  (Risk)
 * ============================================================ */

/* ─── Exposure Assessment ─────────────────────────────────────── */
function WbExposure({ isDark }) {
  const bandPct = 0.52;
  return (
    <WorkbenchFrame active="Exposure Assessment" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Exposure profile" icon="target">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 14 }}>
            <WbKpi label="Exposure value" value="$118M" tone="info" />
            <WbKpi label="Band"           value="Mid-market" sub="$25M – $250M" />
            <WbKpi label="Size score"     value="64" />
            <WbKpi label="Complexity"     value="47" />
            <WbKpi label="Modifier"       value="1.04x" />
            <WbKpi label="Method"         value="Revenue × rate" />
          </div>
        </WbCard>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title="Band position" icon="gauge">
            <div className="caption" style={{ marginBottom: 14 }}>Where you sit within the mid-market band</div>
            <div style={{ position: 'relative', height: 36 }}>
              <div style={{
                position: 'absolute', left: 0, right: 0, top: 14, height: 8, borderRadius: 4,
                background: 'var(--surface-sunken)',
                border: '1px solid var(--rule)',
              }} />
              <div style={{
                position: 'absolute', left: `${bandPct * 100}%`, top: 0, bottom: 0,
                width: 2, background: 'var(--info)', transform: 'translateX(-50%)',
              }} />
              <div style={{
                position: 'absolute', left: `${bandPct * 100}%`, top: -22, transform: 'translateX(-50%)',
                fontSize: 11, fontWeight: 700, color: 'var(--info)', whiteSpace: 'nowrap',
              }}>$118M</div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--ink-mute)', marginTop: 8 }}>
              <span>$25M floor</span><span>$250M ceiling</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
              <WbKpi label="Band percentile" value="52%" />
              <WbKpi label="Below ceiling"   value="$132M" />
              <WbKpi label="Above floor"     value="$93M" />
            </div>
          </WbCard>

          <WbCard title="Components" icon="puzzle">
            <ComponentRow name="Size"       weight="0.70" score={64} band="Mid"      mod="1.04x" />
            <ComponentRow name="Complexity" weight="0.30" score={47} band="Moderate" mod="1.00x" />
            <div style={{ paddingTop: 12, marginTop: 8, borderTop: '1px solid var(--ink-soft)', display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13.5, fontWeight: 700 }}>Combined modifier</span>
              <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--info-deep)', fontVariantNumeric: 'tabular-nums' }}>1.04x</span>
            </div>
          </WbCard>
        </div>

        <WbCard title="Exposure vs overall score" icon="chart-scatter">
          <ScatterMini />
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

function ComponentRow({ name, weight, score, band, mod }) {
  return (
    <div style={{ padding: '12px 0', borderBottom: '1px solid var(--rule)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 13, fontWeight: 600 }}>{name}</span>
        <span className="micro">Weight {weight}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
        <div>
          <div className="micro">Score</div>
          <div style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{score}</div>
        </div>
        <div>
          <div className="micro">Band</div>
          <div style={{ fontWeight: 600 }}>{band}</div>
        </div>
        <div>
          <div className="micro">Modifier</div>
          <div style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{mod}</div>
        </div>
      </div>
    </div>
  );
}

function ScatterMini() {
  const W = 980, H = 220;
  const points = [
    { x: 28, y: 612, dec: 'approve' }, { x: 42, y: 638, dec: 'approve' }, { x: 35, y: 656, dec: 'approve' },
    { x: 52, y: 686, dec: 'refer'   }, { x: 60, y: 712, dec: 'refer'   }, { x: 48, y: 702, dec: 'refer'   },
    { x: 71, y: 668, dec: 'refer'   }, { x: 78, y: 596, dec: 'decline' }, { x: 82, y: 568, dec: 'decline' },
    { x: 22, y: 678, dec: 'approve' }, { x: 38, y: 720, dec: 'approve' }, { x: 56, y: 742, dec: 'refer'   },
    { x: 40, y: 698, dec: 'approve' }, { x: 30, y: 742, dec: 'approve' }, { x: 50, y: 668, dec: 'refer'   },
    { x: 88, y: 540, dec: 'decline' }, { x: 18, y: 740, dec: 'approve' }, { x: 64, y: 724, dec: 'refer'   },
  ];
  const color = (d) => d === 'approve' ? 'var(--pos)' : d === 'refer' ? 'var(--warn)' : 'var(--neg)';
  const xToPx = (x) => 50 + (x / 100) * (W - 70);
  const yToPx = (y) => H - 28 - ((y - 400) / 600) * (H - 56);
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
      <line x1={50} y1={H - 28} x2={W - 20} y2={H - 28} stroke="var(--rule)" />
      <line x1={50} y1={20}     x2={50}     y2={H - 28} stroke="var(--rule)" />
      {[0, 25, 50, 75, 100].map((v) => (
        <text key={v} x={xToPx(v)} y={H - 12} textAnchor="middle" style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{v}</text>
      ))}
      {[400, 600, 800, 1000].map((v) => (
        <text key={v} x={42} y={yToPx(v) + 3} textAnchor="end" style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{v}</text>
      ))}
      <text x={W/2} y={H} textAnchor="middle" style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-soft)' }}>Exposure magnitude score →</text>
      <text x={16} y={H/2} transform={`rotate(-90, 16, ${H/2})`} textAnchor="middle" style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-soft)' }}>Composite score →</text>
      {points.map((p, i) => (
        <circle key={i} cx={xToPx(p.x)} cy={yToPx(p.y)} r="4" fill={color(p.dec)} opacity="0.7" />
      ))}
      {/* subject — same high-contrast callout as the Loss chart */}
      {(() => {
        const cx = xToPx(64), cy = yToPx(724);
        const pillCy = cy - 32, pillW = 116, pillH = 22;
        return (
          <g>
            <circle cx={cx} cy={cy} r="15" fill="var(--info)" opacity="0.16" />
            <line x1={cx} y1={pillCy + pillH / 2} x2={cx} y2={cy - 9} stroke="var(--info)" strokeWidth="1.5" />
            <circle cx={cx} cy={cy} r="7" fill="var(--info)" stroke="var(--surface)" strokeWidth="2.5" />
            <rect x={cx - pillW / 2} y={pillCy - pillH / 2} width={pillW} height={pillH} rx="6" fill="var(--info)" />
            <text x={cx} y={pillCy + 4} textAnchor="middle" style={{ font: '700 11.5px IBM Plex Sans', fill: '#fff', letterSpacing: '0.02em' }}>YOU · 64 / 724</text>
          </g>
        );
      })()}
    </svg>
  );
}

/* ─── Scenarios ──────────────────────────────────────────────── */
function WbScenarios({ isDark }) {
  const overrides = [
    { code: 'cyber.soc2_typeii',  orig: 35, scen: 65, weight: 0.18, contrib: 6.3, scenContrib: 11.7 },
    { code: 'cyber.rdp_exposed',  orig: 25, scen: 75, weight: 0.12, contrib: 3.0, scenContrib: 9.0 },
  ];
  return (
    <WorkbenchFrame active="Scenarios" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Signal overrides" icon="flask-conical" headerRight={<span className="chip chip-info">2 modified</span>}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 14 }}>
            <div>
              <div className="micro">Original composite</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 2 }}>
                <span style={{ fontSize: 22, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>724</span>
                <span className="caption">Tier 2</span>
              </div>
            </div>
            <div>
              <div className="micro" style={{ color: 'var(--info)' }}>Scenario composite</div>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 2 }}>
                <span style={{ fontSize: 26, fontWeight: 700, color: 'var(--info)', fontVariantNumeric: 'tabular-nums' }}>738</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--pos)' }}>+14</span>
                <span className="caption">Tier 2 · stays</span>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 70px 70px 90px 90px 90px', padding: '8px 0', borderTop: '1px solid var(--rule)', borderBottom: '1px solid var(--rule)' }}>
            {['Signal', 'Original', 'Weight', 'Contribution', 'Scenario', 'New contrib'].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 10.5 }}>{h}</span>
            ))}
          </div>
          {overrides.map((o) => (
            <div key={o.code} style={{
              display: 'grid', gridTemplateColumns: '1.6fr 70px 70px 90px 90px 90px',
              padding: '10px 0', borderBottom: '1px solid var(--rule)',
              alignItems: 'center', fontSize: 13,
            }}>
              <code style={{ fontSize: 12 }}>{o.code}</code>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{o.orig}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--ink-soft)' }}>{o.weight.toFixed(2)}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{o.contrib.toFixed(1)}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center',
                padding: '4px 8px', borderRadius: 6,
                border: '1px solid var(--info)',
                color: 'var(--info)', fontWeight: 700,
                background: 'var(--info-soft)',
                width: 'fit-content', justifyContent: 'center',
              }}>
                {o.scen}
              </span>
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700, color: 'var(--info)' }}>{o.scenContrib.toFixed(1)}</span>
            </div>
          ))}
        </WbCard>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title="Loss modifier" icon="shield">
            <CompareRow k="Propensity score"     o="41.0" s="36.2" />
            <CompareRow k="Frequency multiplier" o="0.94x" s="0.91x" />
            <CompareRow k="Severity multiplier"  o="0.98x" s="0.97x" />
            <CompareRow k="Combined modifier"    o="0.92x" s="0.88x" bold />
          </WbCard>
          <WbCard title="Exposure & scaling" icon="layers">
            <CompareRow k="Exposure value" o="$118M" s="$118M" />
            <CompareRow k="Size score"     o="64"     s="64"     />
            <CompareRow k="Exposure mod"   o="1.04x"  s="1.04x"  bold />
            <CompareRow k="ILF factor"     o="1.000x" s="1.000x" />
            <CompareRow k="Deductible fac" o="1.000x" s="1.000x" />
          </WbCard>
        </div>

        <WbCard title="Pricing cascade · original vs scenario" icon="trending-down">
          <div style={{ display: 'grid', gridTemplateColumns: '50% 25% 25%', borderBottom: '1px solid var(--rule)', paddingBottom: 8 }}>
            <span className="micro">Step</span>
            <span className="micro" style={{ textAlign: 'right' }}>Original</span>
            <span className="micro" style={{ textAlign: 'right', color: 'var(--info)' }}>Scenario</span>
          </div>
          {[
            ['Tier assignment',      'Tier 2',   'Tier 2'],
            ['Base premium',         '$168,400', '$168,400'],
            ['After categorical',    '$164,200', '$164,200'],
            ['After signals',        '$182,400', '$176,200'],
            ['After direct queries', '$187,300', '$181,100'],
            ['After loss analysis',  '$178,900', '$173,700'],
            ['After exposure',       '$185,200', '$179,200'],
            ['ILF (limit $10M)',     '$185,200', '$179,200'],
            ['Deductible ($50k)',    '$185,200', '$179,200'],
          ].map((r, i, arr) => {
            const last = i === arr.length - 1;
            const changed = r[1] !== r[2];
            return (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '50% 25% 25%',
                padding: '8px 0', fontSize: 13,
                borderBottom: last ? 0 : '1px solid var(--rule)',
              }}>
                <span>{r[0]}</span>
                <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{r[1]}</span>
                <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: changed ? 700 : 500, color: changed ? 'var(--info)' : 'inherit' }}>{r[2]}</span>
              </div>
            );
          })}
          <div style={{
            display: 'grid', gridTemplateColumns: '50% 25% 25%',
            padding: '14px 0 4px', borderTop: '2px solid var(--ink)', marginTop: 4,
            fontSize: 17, fontWeight: 700,
          }}>
            <span>Final premium</span>
            <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>$185,200</span>
            <span style={{ textAlign: 'right', color: 'var(--pos)', fontVariantNumeric: 'tabular-nums' }}>$179,200</span>
          </div>
          <div style={{ textAlign: 'right', fontSize: 13, fontWeight: 700, color: 'var(--pos)', marginTop: 4 }}>
            −$6,000 (−3.2%) if both signals raised to 65 / 75
          </div>
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

function CompareRow({ k, o, s, bold }) {
  const changed = o !== s;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px 30px 80px', padding: '8px 0', borderBottom: '1px solid var(--rule)', fontSize: 13, alignItems: 'baseline', fontWeight: bold ? 700 : 500 }}>
      <span style={{ color: 'var(--ink-soft)' }}>{k}</span>
      <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{o}</span>
      <span style={{ textAlign: 'center', color: 'var(--ink-mute)' }}>→</span>
      <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', color: changed ? 'var(--info)' : 'inherit', fontWeight: bold ? 700 : changed ? 600 : 500 }}>{s}</span>
    </div>
  );
}

/* ─── Distribution ───────────────────────────────────────────── */
function WbDistribution({ isDark }) {
  const rows = [
    { carrier: 'Hartford Mutual', role: 'LEAD',     line: 60, premium: 102_354 },
    { carrier: 'Beazley',         role: 'Follower', line: 25, premium:  42_647 },
    { carrier: 'Chubb',           role: 'Follower', line: 15, premium:  25_589 },
  ];
  return (
    <WorkbenchFrame active="Distribution" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>
        <WbCard title="Subscription · this carrier's slice" icon="network">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            <WbKpi label="Signed line"        value="60%" />
            <WbKpi label="Role"               value="LEAD" />
            <WbKpi label="Lead loading"       value="1.05x" />
            <WbKpi label="This carrier earns" value="$107,472" tone="info" sub="60% × $170,590 × 1.05" />
          </div>
        </WbCard>
        <WbCard title="Subscription tower" icon="users">
          {/* visual tower */}
          <div style={{ display: 'flex', height: 28, borderRadius: 6, overflow: 'hidden', marginBottom: 14, border: '1px solid var(--rule)' }}>
            {rows.map((r, i) => (
              <div key={r.carrier} style={{
                flex: r.line,
                background: r.role === 'LEAD' ? 'var(--info)' : `color-mix(in srgb, var(--info) ${40 - i * 10}%, var(--surface))`,
                color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 700,
                borderRight: i < rows.length - 1 ? '2px solid var(--surface)' : 0,
              }}>
                {r.line}%
              </div>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 110px 90px 110px', padding: '8px 0', borderBottom: '1px solid var(--rule)' }}>
            {['Carrier', 'Role', 'Signed line', 'Premium'].map((h) => <span key={h} className="micro" style={{ fontSize: 10.5 }}>{h}</span>)}
          </div>
          {rows.map((r, i) => (
            <div key={r.carrier} style={{
              display: 'grid', gridTemplateColumns: '2fr 110px 90px 110px',
              padding: '10px 0', borderBottom: i < rows.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13, alignItems: 'center',
            }}>
              <span style={{ fontWeight: r.role === 'LEAD' ? 700 : 500 }}>{r.carrier}</span>
              <span>{r.role === 'LEAD' ? <span className="chip chip-info">LEAD</span> : <span className="caption">{r.role}</span>}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{r.line}%</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 600 }}>${(r.premium / 1000).toFixed(1)}k</span>
            </div>
          ))}
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── Terms Overview ─────────────────────────────────────────── */
function WbCommercial({ isDark }) {
  return (
    <WorkbenchFrame active="Terms Overview" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 14, alignContent: 'start' }}>

        {/* Hero: the offered premium framed against net + gross + technical */}
        <div className="card-info" style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr auto auto auto', gap: 32, alignItems: 'center' }}>
          <div>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Offered premium</div>
            <div className="num-xl" style={{ marginTop: 6, color: 'var(--info-deep)', lineHeight: 1 }}>$170,590</div>
            <div className="caption" style={{ marginTop: 8 }}>at gross · 0% discretion applied</div>
          </div>
          <div>
            <div className="micro">Net</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22 }}>$162,050</div>
          </div>
          <div>
            <div className="micro">Gross</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22 }}>$170,590</div>
          </div>
          <div>
            <div className="micro">Technical</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22, color: 'var(--ink-soft)' }}>$185,200</div>
          </div>
        </div>

        {/* Entity + period side by side */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14 }}>
          <WbCard title="Insured entity" icon="building-2">
            <DefList rows={[
              ['Entity name',  'Eastward Robotics, Inc.'],
              ['Entity ID',    <code style={{ fontSize: 12 }}>ENT_8x42aPq3</code>],
              ['Market',       'United States'],
              ['Base currency','USD'],
            ]} cols={2} />
          </WbCard>
          <WbCard title="Policy period" icon="calendar">
            <DefList rows={[
              ['Written date', '26 Apr 2026'],
              ['Earned start', '01 May 2026'],
              ['Earned end',   '30 Apr 2027'],
              ['Method',       'Straight line'],
            ]} cols={2} />
          </WbCard>
        </div>

        {/* Premium ladder + commission structure */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14 }}>
          <WbCard title="Premium ladder" icon="layers">
            <PremiumLadder
              rungs={[
                { label: 'Technical premium', value: '$185,200', tone: 'muted' },
                { label: 'Total commission',  value: '−$23,150', tone: 'neg' },
                { label: 'Net premium',       value: '$162,050', tone: 'sub' },
                { label: 'Taxes & levies',    value: '+$8,540',  tone: 'warn' },
                { label: 'Gross premium',     value: '$170,590', tone: 'sub' },
                { label: 'Discretion',        value: '0.0%',     tone: 'muted' },
                { label: 'Offered premium',   value: '$170,590', tone: 'final' },
              ]}
            />
          </WbCard>
          <WbCard title="Commission structure" icon="hand-coins">
            <DefList rows={[
              ['Brokerage',          '12.5%'],
              ['Overrider',          '0.0%'],
              ['Profit commission',  '0.0%'],
            ]} cols={2} />
            <div style={{
              marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--ink-soft)',
              display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
            }}>
              <span style={{ fontSize: 13, fontWeight: 700 }}>Total commission</span>
              <span style={{ fontSize: 17, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>$23,150</span>
            </div>
            <div className="caption" style={{ marginTop: 8 }}>
              Earned on net premium · paid to Marsh on placement.
            </div>
          </WbCard>
        </div>

      </div>
    </WorkbenchFrame>
  );
}

/* Definition list — uniform two-column key/value display. */
function DefList({ rows, cols = 1 }) {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: cols === 2 ? '1fr 1fr' : '1fr',
      columnGap: 24,
    }}>
      {rows.map(([k, v], i) => (
        <div key={i} style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          padding: '7px 0',
          borderBottom: '1px solid var(--rule)',
        }}>
          <span className="micro">{k}</span>
          <span style={{ fontSize: 13, fontWeight: 600, textAlign: 'right' }}>{v}</span>
        </div>
      ))}
    </div>
  );
}

/* Premium ladder — compact summary form of the build-up. */
function PremiumLadder({ rungs }) {
  return (
    <div>
      {rungs.map((r, i) => {
        const last = i === rungs.length - 1;
        const isSub   = r.tone === 'sub';
        const isFinal = r.tone === 'final';
        const colors = {
          muted: 'var(--ink-soft)',
          neg:   'var(--neg)',
          warn:  'var(--warn)',
          sub:   'var(--ink)',
          final: 'var(--info-deep)',
        };
        return (
          <div key={r.label} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
            padding: isFinal ? '14px 4px 4px' : isSub ? '10px 4px 6px' : '7px 4px',
            borderTop: isSub ? '1px solid var(--ink-soft)'
                     : isFinal ? '2px solid var(--ink)'
                     : 0,
            marginTop: isSub || isFinal ? 4 : 0,
            borderBottom: !isSub && !isFinal && !last ? '1px solid var(--rule)' : 0,
          }}>
            <span style={{
              fontSize: isFinal ? 14 : 13,
              fontWeight: isFinal || isSub ? 700 : 500,
              letterSpacing: isFinal ? '0.02em' : 'normal',
              textTransform: isFinal ? 'uppercase' : 'none',
              color: r.tone === 'muted' ? 'var(--ink-soft)' : 'var(--ink)',
            }}>{r.label}</span>
            <span style={{
              fontSize: isFinal ? 22 : isSub ? 16 : 13,
              fontWeight: 700,
              fontVariantNumeric: 'tabular-nums',
              color: colors[r.tone] || 'var(--ink)',
            }}>{r.value}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ─── Deductible Structure ───────────────────────────────────── */
function WbDeductible({ isDark }) {
  const sublimits = [
    ['Ransomware payment',           '$2,000,000'],
    ['Regulatory fines + penalties', '$1,000,000'],
    ['PCI fines',                    '$500,000'],
    ['Business interruption',        '$5,000,000'],
    ['Crisis management',            '$250,000'],
  ];
  return (
    <WorkbenchFrame active="Deductible Structure" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>
        <WbCard title="Deductible" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            <WbKpi label="Type"     value="Per occurrence" />
            <WbKpi label="Amount"   value="$50,000" />
            <WbKpi label="Currency" value="USD" />
            <WbKpi label="Basis"    value="Each claim" />
          </div>
        </WbCard>
        <WbCard title={`Sub-limits · ${sublimits.length}`} icon="minus-circle">
          {sublimits.map((r, i) => (
            <div key={r[0]} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
              padding: '10px 0', borderBottom: i < sublimits.length - 1 ? '1px solid var(--rule)' : 0,
            }}>
              <span style={{ fontSize: 13 }}>{r[0]}</span>
              <span style={{ fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{r[1]}</span>
            </div>
          ))}
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── SIR & Waiting Periods ──────────────────────────────────── */
function WbSir({ isDark }) {
  return (
    <WorkbenchFrame active="SIR & Waiting Periods" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>
        <WbCard title="Self-insured retention" icon="shield">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            <WbKpi label="SIR applies" value="No" />
            <WbKpi label="Amount"      value="—" />
            <WbKpi label="Currency"    value="USD" />
          </div>
          <div className="caption" style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
            No self-insured retention is structured into this risk. The standard <strong>$50,000</strong> deductible applies per occurrence (see Deductible Structure).
          </div>
        </WbCard>
        <WbCard title="Waiting periods" icon="clock">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            <WbKpi label="Period" value="8 hours" sub="0.33 days" />
            <WbKpi label="Type"   value="Business interruption" />
            <WbKpi label="Trigger" value="Time deductible" />
          </div>
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── Aggregate & Reinstatement ──────────────────────────────── */
function WbAggregate({ isDark }) {
  return (
    <WorkbenchFrame active="Aggregate & Reinstatement" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>
        <WbCard title="Aggregate limits" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            <WbKpi label="Aggregate limit"      value="$10,000,000" tone="info" />
            <WbKpi label="Aggregate deductible" value="$50,000" />
            <WbKpi label="Basis"                value="Annual" />
          </div>
        </WbCard>
        <WbCard title="Reinstatement provisions" icon="refresh-cw">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
            <WbKpi label="Reinstatements" value="1" sub="available during period" />
            <WbKpi label="Rate"           value="50%" sub="of original premium per reinstatement" />
          </div>
        </WbCard>
        <WbCard title="Layer detail" icon="bar-chart-3">
          <DefList rows={[
            ['Attachment point', '$0'],
            ['Layer limit',      '$10,000,000'],
            ['Position',         'Primary · ground-up'],
          ]} cols={2} />
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

Object.assign(window, { WbExposure, WbScenarios, WbDistribution, WbCommercial, WbDeductible, WbSir, WbAggregate });
