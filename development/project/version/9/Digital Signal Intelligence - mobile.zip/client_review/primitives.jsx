/* global React */

/* ============================================================
 * Primitives shared across faithful + reimagined variants.
 * Recreate the codebase's actual primitive components in one place.
 * ============================================================ */

// Icon — uses iconify-icon (lucide set). Already in <head>.
function Icon({ name, size = 18, color, className = '', style = {} }) {
  return (
    <iconify-icon
      icon={`lucide:${name}`}
      width={size}
      height={size}
      style={{ color, display: 'inline-flex', verticalAlign: '-2px', ...style }}
      class={className}
    />
  );
}

/* ──────────────────────────────────────────────────────────────
 * Shared reimagined utilities — single source of truth for the
 * tone→colour mappings and the KPI stat block that were previously
 * re-implemented in a dozen files.
 * ────────────────────────────────────────────────────────────── */

// Map a semantic tone to its CSS custom property.
function toneVar(tone) {
  return tone === 'pos'  ? 'var(--pos)'
       : tone === 'info' ? 'var(--info)'
       : tone === 'spot' ? 'var(--spot)'
       : tone === 'warn' ? 'var(--warn)'
       : tone === 'neg'  ? 'var(--neg)'
       : 'var(--ink)';
}

// Tier (1–5) → colour. Lower tiers are better (green), higher worse (red).
function tierColor(t) {
  return t <= 2 ? 'var(--pos)' : t === 3 ? 'var(--info)' : t === 4 ? 'var(--warn)' : 'var(--neg)';
}

// Underwriting decision → tone token (for chip-* classes / toneVar).
function decisionTone(d) {
  return d === 'approve' ? 'pos' : d === 'refer' ? 'spot' : d === 'decline' ? 'neg' : 'mute';
}

/* ──────────────────────────────────────────────────────────────
 * WorkbenchShell — the single drill-down workbench chrome shared by
 * the Carrier Submission Workbench and Broker Client Workbench.
 * Identical collapse-rail (5%) + 50% overlay drawer + theme toggle;
 * the six things that actually differ between personas are props:
 *   nav          drill-down tab tree ([{kind:'leaf'|'group', …}])
 *   active       current tab name
 *   account      { initials, name, email }
 *   scope        { label, lines:[…] }  — the "what am I scoped to" block
 *   backLabel    breadcrumb root link text (e.g. "Pipeline" / "Book")
 *   lead         ReactNode: identity cluster between breadcrumb & spacer
 *   contextStats [{ label, value, tone }] — hidden on the Summary tab
 * ────────────────────────────────────────────────────────────── */
function WorkbenchShell({ nav, active, account, scope, backLabel, lead, contextStats = [], isDark, children }) {
  const [expanded, setExpanded] = React.useState(false);
  const [dark, setDark] = React.useState(!!isDark);
  const activeGroup = nav.find(n => n.kind === 'group' && n.children?.some(c => c.name === active))?.name;
  const isSummary = active === 'Summary';
  return (
    <div className={`ds-reimag ${dark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <WorkbenchSidebar nav={nav} active={active} activeGroup={activeGroup} account={account} scope={scope} expanded={expanded} onToggle={() => setExpanded(e => !e)} />
        <div className="main">
          <div className="topbar" style={{ height: 'auto', minHeight: 64, padding: '0 24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 0', flex: 1, minWidth: 0 }}>
              <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--ink-soft)' }}>
                <Icon name="arrow-left" size={12} /> {backLabel}
              </a>
              {lead}
              <span style={{ flex: 1 }} />
              {/* Context stats duplicate the Summary banner, so only surface them
                  on deeper tabs where that banner isn't visible. */}
              {!isSummary && contextStats.length > 0 && (
                <div style={{ display: 'flex', gap: 18, alignItems: 'center' }}>
                  {contextStats.map(s => <CtxStat key={s.label} {...s} />)}
                </div>
              )}
              {/* Light / dark toggle — always the furthest-right token. */}
              <button
                className="theme-toggle"
                style={{ marginLeft: 18 }}
                title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
                aria-label="Toggle light or dark mode"
                onClick={() => setDark(d => !d)}
              >
                <Icon name={dark ? 'sun' : 'moon'} size={16} />
              </button>
            </div>
          </div>
          <div className="work">{children}</div>
        </div>
      </div>
    </div>
  );
}

function CtxStat({ label, value, tone }) {
  return (
    <div style={{ textAlign: 'right' }}>
      <div className="micro" style={{ fontSize: 10 }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 700, color: toneVar(tone), fontVariantNumeric: 'tabular-nums', lineHeight: 1.1 }}>{value}</div>
    </div>
  );
}

function WorkbenchSidebar({ nav, active, activeGroup, account, scope, expanded, onToggle }) {
  return (
    <React.Fragment>
      {/* Collapsed rail — 5% of the frame, top-level tabs only. */}
      <aside className="sidebar">
        <button className="sb-btn" title="Expand menu" onClick={onToggle} aria-label="Expand menu">
          <Icon name="panel-left-open" size={20} />
        </button>
        <div className="sb-rule" />
        {nav.map((n) => {
          const act = n.kind === 'leaf' ? n.name === active : activeGroup === n.name;
          return (
            <div key={n.name} className={`sb-icon ${act ? 'active' : ''}`} title={n.name}>
              <Icon name={n.icon} size={20} />
            </div>
          );
        })}
        <div style={{ flex: 1 }} />
        <button className="sb-btn" title="Log out" aria-label="Log out">
          <Icon name="log-out" size={20} />
        </button>
      </aside>

      {/* Expanded overlay — 50% of the frame, full drill-down tree. */}
      {expanded && (
        <React.Fragment>
          <div className="sb-scrim" onClick={onToggle} />
          <aside className="sb-overlay">
            <div className="sbx-head">
              <button className="sb-btn" title="Close menu" onClick={onToggle} aria-label="Close menu">
                <Icon name="panel-left-close" size={20} />
              </button>
            </div>
            <div className="sbx-account">
              <div className="sbx-avatar">{account.initials}</div>
              <div style={{ minWidth: 0 }}>
                <div className="sbx-name">{account.name}</div>
                <div className="sbx-email">{account.email}</div>
              </div>
            </div>
            {/* What this workbench is scoped to (submission / client). */}
            <div style={{ padding: '10px 10px 12px', borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
              <div className="micro" style={{ color: 'rgba(255,255,255,0.5)' }}>{scope.label}</div>
              {scope.lines.map((ln, i) => (
                <div key={i} style={i === 0
                  ? { fontSize: 13, fontWeight: 600, color: '#fff', marginTop: 3 }
                  : { fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>{ln}</div>
              ))}
            </div>
            <nav className="sbx-nav" style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
              {nav.map((n) => (
                <div key={n.name}>
                  {n.kind === 'leaf' ? (
                    <div className={`sbx-item ${n.name === active ? 'active' : ''}`}>
                      <Icon name={n.icon} size={18} /><span>{n.name}</span>
                    </div>
                  ) : (
                    <React.Fragment>
                      <div className="sbx-group"><Icon name={n.icon} size={13} /><span>{n.name}</span></div>
                      {n.children.map((c) => (
                        <div key={c.name} className={`sbx-item sbx-sub ${c.name === active ? 'active' : ''}`}>
                          <Icon name={c.icon} size={16} /><span>{c.name}</span>
                        </div>
                      ))}
                    </React.Fragment>
                  )}
                </div>
              ))}
            </nav>
            <div className="sbx-foot">
              <div className="sbx-item"><Icon name="settings" size={18} /><span>Settings</span></div>
              <div className="sbx-item"><Icon name="log-out" size={18} /><span>Log out</span></div>
            </div>
          </aside>
        </React.Fragment>
      )}
    </React.Fragment>
  );
}

/* The one KPI stat block. `surface` picks the wrapper:
 *   'plain'  — bare (sits inside an existing card)
 *   'card'   — the standard .card tile (padding 16)
 *   'panel'  — surface-elev bordered tile (admin density)
 * `valueSize` keeps the few legitimately different scales. */
function Kpi({ label, value, sub, tone, valueSize = 22, surface = 'plain', hidden }) {
  const vis = hidden ? 'hidden' : undefined;
  const wrap = surface === 'card'
    ? { className: 'card', style: { padding: 16, visibility: vis } }
    : surface === 'panel'
    ? { style: { padding: 14, background: 'var(--surface-elev)', border: '1px solid var(--rule)', borderRadius: 10, visibility: vis } }
    : { style: { visibility: vis } };
  return (
    <div {...wrap}>
      <div className="micro">{label}</div>
      <div className="num" style={{ fontSize: valueSize, color: toneVar(tone), marginTop: 4, fontVariantNumeric: 'tabular-nums' }}>{value}</div>
      {sub && <div className="micro" style={{ marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * FAITHFUL chrome
 * ────────────────────────────────────────────────────────────── */

// Client portal nav icons (collapsed sidebar shows just the icons)
const CLIENT_NAV = [
  { name: 'Overview',            icon: 'gauge' },
  { name: 'Your Profile',        icon: 'user-circle' },
  { name: 'Coverages',           icon: 'shield-check' },
  { name: 'Risk Insights',       icon: 'list-checks' },
  { name: 'Industry Benchmarks', icon: 'trending-up-down' },
  { name: 'Scenarios',           icon: 'flask-conical' },
  { name: 'Action Plan',         icon: 'lightbulb' },
  { name: 'Request Coverage',    icon: 'plus-circle' },
  { name: 'Communications',      icon: 'messages-square' },
];

// Broker portal nav — mirrors PORTAL_BROKER_CHILDREN from navConfig.ts
const BROKER_NAV = [
  { name: 'Book of Clients',       icon: 'briefcase' },
  { name: 'Client Health',         icon: 'heart-pulse' },
  { name: 'Coverages',             icon: 'shield-check' },
  { name: 'Placement Strategy',    icon: 'target' },
  { name: 'Carrier Intelligence',  icon: 'building-2' },
  { name: 'Recommendations',       icon: 'lightbulb' },
  { name: 'Communications',        icon: 'messages-square' },
  { name: 'Market Pulse',          icon: 'trending-up-down' },
  { name: 'Risk Aggregation',      icon: 'network' },
  { name: 'Book Health',           icon: 'chart-pie' },
];

// Carrier portal nav — SUBMISSIONS_CHILDREN + drill-down placeholders
const CARRIER_NAV = [
  { name: 'Referral Pipeline',     icon: 'user-star' },
  { name: 'Full Pipeline',         icon: 'rows-4' },
  { name: 'Performance Metrics',   icon: 'bot' },
  { name: 'World Engine',          icon: 'orbit' },
];

// Admin nav — mirrors ADMIN_CHILDREN from navConfig.ts
const ADMIN_NAV = [
  { name: 'System Health',  icon: 'activity' },
  { name: 'Users & Roles',  icon: 'users' },
  { name: 'Configs',        icon: 'file-stack' },
  { name: 'Audit Log',      icon: 'history' },
  { name: 'Loss Register',  icon: 'file-x' },
  { name: 'Recalibration',  icon: 'trending-up-down' },
];

function SidebarFaithful({ active }) {
  return (
    <aside className="sidebar">
      <div className="sb-icon"><Icon name="panel-right-close" /></div>
      <div className="sb-icon" style={{ marginTop: 8, marginBottom: 16 }}>
        <Icon name="user" />
      </div>
      {CLIENT_NAV.map((n) => (
        <div key={n.name} className={`sb-icon ${active === n.name ? 'active' : ''}`} title={n.name}>
          <Icon name={n.icon} />
        </div>
      ))}
      <div className="sb-spacer" />
      <div className="sb-bottom">
        <Icon name="bug" />
        <Icon name="lightbulb" />
      </div>
    </aside>
  );
}

function TitleBarFaithful({ menu, right }) {
  return (
    <div className="titlebar">
      <h1>
        <span className="crumb-sep">/</span>
        <span>Client Portal</span>
        {menu && (<>
          <span className="crumb-sep">/</span>
          <span className="crumb-active">{menu}</span>
        </>)}
      </h1>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        {right}
      </div>
    </div>
  );
}

function FrameFaithful({ menu, isDark, children, titleRight }) {
  return (
    <div className={`ds-faithful ${isDark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <SidebarFaithful active={menu} />
        <div className="main">
          <TitleBarFaithful menu={menu} right={titleRight} />
          <div className="viewcanvas">{children}</div>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * FAITHFUL primitives — mirror frontend/src/components/base
 * ────────────────────────────────────────────────────────────── */

// Color from "decision" — drives header card accent.
function decisionAccent(decision) {
  // Lifted from keytermPalette logic — we use only what we need.
  if (decision === 'approve')  return 'var(--good)';
  if (decision === 'refer')    return 'var(--maybe)';
  if (decision === 'decline')  return 'var(--bad)';
  return 'var(--outline)';
}
function decisionIcon(decision) {
  if (decision === 'approve') return 'shield-check';
  if (decision === 'refer')   return 'circle-dot';
  if (decision === 'decline') return 'shield-x';
  return 'shield';
}

function SubmissionHeaderCard({
  title, subtitle, decision = 'approve', icon, children, headerRight,
}) {
  const accent = decisionAccent(decision);
  const I = icon || decisionIcon(decision);
  return (
    <div className="header-card" style={{ '--accent': accent }}>
      <div className="hc-inner">
        <div className="hc-top">
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <Icon name={I} size={32} color="var(--accent)" />
            <div>
              <div className="hc-title">{title}</div>
              {subtitle && <div className="hc-subtitle">{subtitle}</div>}
            </div>
          </div>
          {headerRight && <div style={{ color: 'var(--placeholder)' }}>{headerRight}</div>}
        </div>
        {children && <div style={{ paddingLeft: 16, paddingRight: 16, paddingTop: 8 }}>{children}</div>}
      </div>
    </div>
  );
}

function StandardCard({ title, icon, headerRight, children, style = {} }) {
  return (
    <div className="stdcard" style={style}>
      <div className="stdcard-header">
        {icon && <Icon name={icon} />}
        <span style={{ flex: 1 }}>{title}</span>
        {headerRight}
      </div>
      <div className="stdcard-body">{children}</div>
    </div>
  );
}

function StatsGrid({ columns }) {
  const cols = columns.map((c) => c.width || '1fr').join(' ');
  return (
    <div className="statsgrid" style={{ gridTemplateColumns: cols }}>
      {columns.map((c, i) => (
        <div key={`h-${i}`} className="sg-h">{c.label}</div>
      ))}
      {columns.map((c, i) => (
        <div key={`v-${i}`} className="sg-v">{c.value}</div>
      ))}
    </div>
  );
}

function KpiTile({ label, value, sub, icon, emphasis }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, marginBottom: 4 }}>
        {icon && <Icon name={icon} size={14} />}
        <span>{label}</span>
      </div>
      <div style={{
        fontSize: emphasis ? 22 : 18, fontWeight: 700,
        color: emphasis ? 'var(--text)' : 'var(--placeholder)',
      }}>{value}</div>
      {sub && <div style={{ fontSize: 11 }}>{sub}</div>}
    </div>
  );
}

function ScoreBar({ value, max = 100, thresholds = [] }) {
  const pct = Math.min(100, Math.max(2, (value / max) * 100));
  // Pick color from thresholds: first whose `at >= value`
  let color = thresholds[thresholds.length - 1]?.color || 'var(--good)';
  for (const t of thresholds) { if (value <= t.at) { color = t.color; break; } }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        flex: 1, height: 6,
        background: 'var(--bg-light)', borderRadius: 999, overflow: 'hidden',
      }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 999 }} />
      </div>
      <span style={{ fontSize: 10, fontWeight: 700, width: 32, textAlign: 'right' }}>
        {value}
      </span>
    </div>
  );
}

function CompareRow({ label, sublabel, original, scenario, changed }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 100px 24px 130px',
      padding: '6px 4px', borderBottom: '1px solid var(--outline)',
      background: changed ? 'var(--input-light)' : 'transparent',
    }}>
      <div>
        <div style={{ fontSize: 12 }}>{label}</div>
        {sublabel && <div style={{ fontSize: 10, color: 'var(--placeholder)' }}>{sublabel}</div>}
      </div>
      <span style={{ textAlign: 'right', fontSize: 12 }}>{original}</span>
      <span style={{ textAlign: 'center', fontSize: 12 }}>→</span>
      <span style={{
        textAlign: 'right', fontSize: 12, fontWeight: 700,
        color: changed ? 'var(--text)' : 'inherit',
      }}>{scenario}</span>
    </div>
  );
}

function LabelValueList({ rows }) {
  return (
    <div>
      {rows.map((r, i) => (
        <div key={i} style={{
          display: 'flex', justifyContent: 'space-between',
          fontSize: 13, padding: '3px 0',
        }}>
          <span>{r.label}</span>
          <span style={{ fontWeight: 700 }}>{r.value}</span>
        </div>
      ))}
    </div>
  );
}

function InfoPanel({ label, aside, children }) {
  return (
    <div className="infopanel">
      {(label || aside) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          {label && <span className="ip-h">{label}</span>}
          {aside && <span style={{ fontSize: 10, opacity: 0.4 }}>{aside}</span>}
        </div>
      )}
      {children}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * REIMAGINED chrome — modern but built FROM the same palette family
 * ────────────────────────────────────────────────────────────── */

function SidebarReimag({ active, nav = CLIENT_NAV, expanded, onToggle, account }) {
  return (
    <React.Fragment>
      {/* Collapsed rail — always present, 5% of the frame. */}
      <aside className="sidebar">
        <button className="sb-btn" title="Expand menu" onClick={onToggle} aria-label="Expand menu">
          <Icon name="panel-left-open" size={20} />
        </button>
        <div className="sb-rule" />
        {nav.map((n) => (
          <div key={n.name} className={`sb-icon ${active === n.name ? 'active' : ''}`} title={n.name}>
            <Icon name={n.icon} size={20} />
          </div>
        ))}
        <div style={{ flex: 1 }} />
        {/* Quick log-out — settings is intentionally NOT here (only in the
            expanded panel, so it can't be reached from the collapsed rail). */}
        <button className="sb-btn" title="Log out" aria-label="Log out">
          <Icon name="log-out" size={20} />
        </button>
      </aside>

      {/* Expanded overlay — 50% of the frame, floats over the page. */}
      {expanded && (
        <React.Fragment>
          <div className="sb-scrim" onClick={onToggle} />
          <aside className="sb-overlay">
            <div className="sbx-head">
              <button className="sb-btn" title="Close menu" onClick={onToggle} aria-label="Close menu">
                <Icon name="panel-left-close" size={20} />
              </button>
            </div>

            {/* Account — only visible while the sidebar is expanded. */}
            <div className="sbx-account">
              <div className="sbx-avatar">{account.initials}</div>
              <div style={{ minWidth: 0 }}>
                <div className="sbx-name">{account.name}</div>
                <div className="sbx-email">{account.email}</div>
              </div>
            </div>

            <nav className="sbx-nav">
              {nav.map((n) => (
                <div key={n.name} className={`sbx-item ${active === n.name ? 'active' : ''}`}>
                  <Icon name={n.icon} size={18} />
                  <span>{n.name}</span>
                </div>
              ))}
            </nav>

            <div style={{ flex: 1 }} />
            <div className="sbx-foot">
              <div className="sbx-item">
                <Icon name="settings" size={18} />
                <span>Settings</span>
              </div>
              <div className="sbx-item">
                <Icon name="log-out" size={18} />
                <span>Log out</span>
              </div>
            </div>
          </aside>
        </React.Fragment>
      )}
    </React.Fragment>
  );
}

function FrameReimag({ menu, children, titleRight, entity, isDark, persona = 'client' }) {
  const [expanded, setExpanded] = React.useState(false);
  const [dark, setDark] = React.useState(!!isDark);

  const navMap = { client: CLIENT_NAV, broker: BROKER_NAV, carrier: CARRIER_NAV, admin: ADMIN_NAV };
  const nav = navMap[persona] || CLIENT_NAV;

  // Account identity by persona — surfaced in the expanded sidebar.
  const accountMap = {
    client:  { initials: 'EK', name: 'Eli Kovacic',   email: 'eli.kovacic@eastwardrobotics.com' },
    broker:  { initials: 'SA', name: 'Sasha Alvarez',  email: 'sasha.alvarez@marsh.com' },
    carrier: { initials: 'JR', name: 'Jordan Reyes',   email: 'jordan.reyes@hartfordmutual.com' },
    admin:   { initials: 'MA', name: 'Morgan Avery',   email: 'morgan.avery@dsi.io' },
  };
  const account = accountMap[persona] || accountMap.client;
  const badgeIcon = persona === 'broker' ? 'briefcase'
                   : persona === 'carrier' ? 'building-2'
                   : persona === 'admin' ? 'shield-check'
                   : 'building-2';
  return (
    <div className={`ds-reimag ${dark ? 'is-dark' : ''}`} style={{ width: '100%', height: '100%' }}>
      <div className="frame">
        <SidebarReimag
          active={menu}
          nav={nav}
          expanded={expanded}
          onToggle={() => setExpanded((e) => !e)}
          account={account}
        />
        <div className="main">
          <div className="topbar">
            <div className="crumbs">
              <span className="sep">/</span>
              <span className="active">{menu}</span>
            </div>
            <div className="actions">
              {titleRight}
              {/* Entity badge always shows the user's OWN org, which they already
                  know. Only the admin console (which spans many orgs) keeps it. */}
              {entity && persona === 'admin' && (
                <div className="badge">
                  <Icon name={badgeIcon} size={13} /> {entity}
                </div>
              )}
              {/* Light / dark toggle — always the furthest-right token. */}
              <button
                className="theme-toggle"
                title={dark ? 'Switch to light mode' : 'Switch to dark mode'}
                aria-label="Toggle light or dark mode"
                onClick={() => setDark((d) => !d)}
              >
                <Icon name={dark ? 'sun' : 'moon'} size={16} />
              </button>
            </div>
          </div>
          <div className="work">{children}</div>
        </div>
      </div>
    </div>
  );
}

// Expose
Object.assign(window, {
  Icon, toneVar, tierColor, decisionTone, Kpi,
  WorkbenchShell, WorkbenchSidebar, CtxStat,
  CLIENT_NAV, BROKER_NAV, CARRIER_NAV, ADMIN_NAV,
  SidebarFaithful, TitleBarFaithful, FrameFaithful,
  SubmissionHeaderCard, StandardCard, StatsGrid, KpiTile,
  ScoreBar, CompareRow, LabelValueList, InfoPanel,
  decisionAccent, decisionIcon,
  SidebarReimag, FrameReimag,
});
