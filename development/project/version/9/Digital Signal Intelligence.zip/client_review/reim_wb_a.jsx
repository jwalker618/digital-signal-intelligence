/* global React, WorkbenchFrame, WbCard, WbKpi, WbRow, WB, Icon */

/* ============================================================
 * Workbench tabs — eight representative tabs covering the four
 * tab categories (Summary, Technical, Commercial, Risk Terms).
 * Each tab returns a complete artboard via WorkbenchFrame.
 * ============================================================ */

/* ─── 01 Summary ─────────────────────────────────────────────── */
function WbSummary({ isDark }) {
  return (
    <WorkbenchFrame active="Summary" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>
        {/* decision banner */}
        <div className="card-spot" style={{ padding: 20, display: 'grid', gridTemplateColumns: '1fr auto', gap: 18, alignItems: 'center' }}>
          <div>
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Decision</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginTop: 4 }}>
              <span style={{ font: '700 28px IBM Plex Sans', textTransform: 'capitalize', color: 'var(--spot-deep)' }}>Refer</span>
              <span className="caption">awaiting underwriter audit · 3 flagged signals</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 24 }}>
            <WbKpi label="Score" value={WB.score} tone="info" />
            <WbKpi label="Tier" value={`T${WB.tier} · ${WB.tierLabel}`} />
            <WbKpi label="Premium" value={`$${(WB.premium / 1000).toFixed(0)}k`} />
            <WbKpi label="Limit"   value={`$${(WB.limit / 1_000_000).toFixed(0)}M`} />
            <WbKpi label="Confidence" value="86%" tone="pos" />
            <WbKpi label="Signal coverage" value="92%" />
          </div>
        </div>

        {/* three-pillar */}
        <WbCard title="Three Pillar Assessment" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {[
              { name: 'Risk',     score: 71, label: 'Acceptable',     tone: 'info',  bullets: ['Cyber score 71/100', 'Above industry median'] },
              { name: 'Loss',     score: 32, label: 'Low propensity', tone: 'pos',  bullets: ['No prior claims (5yr)', 'Frequency trend improving'] },
              { name: 'Exposure', score: 64, label: 'Mid-market',     tone: 'aux',   bullets: ['$118M exposure value', '2 states · diversified'] },
            ].map((p) => (
              <div key={p.name} style={{
                padding: 16, borderRadius: 10,
                background: 'var(--surface-elev)', border: '1px solid var(--rule)',
              }}>
                <div className="eyebrow">{p.name}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 6 }}>
                  <span className="num" style={{ fontSize: 26, color: `var(--${p.tone})`, fontVariantNumeric: 'tabular-nums' }}>{p.score}</span>
                  <span className="caption">{p.label}</span>
                </div>
                <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, marginTop: 8, overflow: 'hidden' }}>
                  <div style={{ width: `${p.score}%`, height: '100%', background: `var(--${p.tone})` }} />
                </div>
                <ul style={{ margin: '10px 0 0', paddingLeft: 16, fontSize: 12, color: 'var(--ink-soft)', lineHeight: 1.5 }}>
                  {p.bullets.map((b) => <li key={b}>{b}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </WbCard>

        {/* who / discovery / commercial / risk terms */}
        <div style={{ display: 'grid', gridTemplateColumns: '0.9fr 1.4fr 1.4fr', gap: 14 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <WbCard title="Who are they?" icon="user" padding={18}>
              <WbRow k="Industry"       v="Industrial Robotics" />
              <WbRow k="NAICS"          v="333999" mono />
              <WbRow k="Revenue band"   v="$50M – $250M" />
              <WbRow k="Country"        v="United States" />
              <WbRow k="Locations"      v="2 states" />
              <WbRow k="Employees"      v="420" />
            </WbCard>
            <WbCard title="Discovery" icon="search" padding={18}>
              <WbRow k="Domain"         v="eastwardrobotics.com" mono />
              <WbRow k="MFA verified"   v="✓ via Okta export" tone="pos" />
              <WbRow k="SOC 2 Type II"  v="Not on file" tone="spot" />
              <WbRow k="EDR coverage"   v="95.6% of endpoints" tone="pos" />
              <WbRow k="Public RDP"     v="1 host detected" tone="neg" />
            </WbCard>
          </div>
          <WbCard title="Commercial Summary" icon="building-2" padding={18}>
            <WbRow k="Technical premium" v="$185,200" mono bold />
            <WbRow k="Brokerage"          v="12.5%" />
            <WbRow k="Net premium"        v="$162,050" mono />
            <WbRow k="Taxes + levies"     v="$8,540" mono />
            <WbRow k="Gross premium"      v="$170,590" mono bold />
            <WbRow k="Offered premium"    v="$170,590" mono bold tone="info" />
            <WbRow k="Discretion"         v="0.0%" />
            <WbRow k="At minimum?"        v="No" />
            <WbRow k="Currency"           v="USD · FX 1.0000" />
          </WbCard>
          <WbCard title="Risk Terms Summary" icon="scale" padding={18}>
            <WbRow k="Deductible"     v="$50,000 · per occurrence" mono />
            <WbRow k="SIR applies"    v="No" />
            <WbRow k="Waiting period" v="8 hours" />
            <WbRow k="Aggregate"      v="$10,000,000" mono />
            <WbRow k="Reinstatements" v="1 · 50% of premium" />
            <WbRow k="Coverage"       v="Claims-made · worldwide ex-OFAC" />
            <WbRow k="Extensions"     v="4" />
            <WbRow k="Exclusions"     v="6" />
            <WbRow k="Sub-limits"     v="Ransomware $2M · Reg fines $1M" mono />
          </WbCard>
        </div>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── 02 Pricing Anatomy ─────────────────────────────────────── */
function WbPricing({ isDark }) {
  const groups = [
    { key: 'categorical', title: 'Categorical', total: -4200, n: 3, items: [
      ['Industry adjustment', '0.98x', -2840],
      ['Region: USA-NE',       '0.99x', -1200],
      ['Revenue band 50-250M', '1.00x',  -160],
    ] },
    { key: 'signal', title: 'Signal-based', total: 18200, n: 4, items: [
      ['MFA on admin accounts',     '0.97x', -5_100],
      ['SOC 2 Type II missing',     '1.10x', 18_200],
      ['Backup encryption verified','0.98x', -3_700],
      ['Public RDP exposed',        '1.04x',  6_200],
    ] },
    { key: 'direct', title: 'Direct queries', total: 4900, n: 2, items: [
      ['IR playbook documented',  '1.03x',  4_900],
      ['Tabletop exercises Q4',   '1.00x',      0],
    ] },
    { key: 'loss', title: 'Loss analysis', total: -8400, n: 1, items: [
      ['No prior cyber claims (5yr)', '0.95x', -8_400],
    ] },
    { key: 'exposure', title: 'Exposure analysis', total: 6300, n: 1, items: [
      ['Mid-market scale',         '1.04x',  6_300],
    ] },
  ];
  const base = 168400;
  let running = base;

  return (
    <WorkbenchFrame active="Pricing Anatomy" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 14, alignContent: 'start' }}>

        <WbCard title="Pricing Anatomy" icon="calculator">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, fontSize: 13 }}>
            <Icon name="arrow-right-to-line" size={14} color="var(--ink-soft)" />
            <span>Tier <strong>{WB.tier}</strong> base premium using</span>
            <code className="chip" style={{ fontSize: 11 }}>EXPOSURE_RATE</code>
            <span>methodology</span>
          </div>

          {/* base premium */}
          <div style={{ padding: '10px 14px', background: 'var(--surface-elev)', borderRadius: 8, marginBottom: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 8, fontSize: 13 }}>
              <span>Basis</span><span style={{ fontFamily: 'ui-monospace, monospace', fontWeight: 600 }}>revenue @ $118,000,000</span>
              <span>Rate</span><span style={{ fontFamily: 'ui-monospace, monospace', fontWeight: 600 }}>0.001427</span>
              <div style={{ gridColumn: '1 / -1', borderTop: '1px solid var(--rule)', marginTop: 4, paddingTop: 8, display: 'flex', justifyContent: 'space-between' }}>
                <strong>Base premium</strong>
                <strong style={{ color: 'var(--info)', fontFamily: 'ui-monospace, monospace' }}>${base.toLocaleString()}</strong>
              </div>
            </div>
          </div>

          {/* modifier groups */}
          {groups.map((g) => {
            const startRunning = running;
            running += g.total;
            return (
              <div key={g.key} style={{ marginBottom: 8, border: '1px solid var(--rule)', borderRadius: 8, overflow: 'hidden' }}>
                <div style={{
                  display: 'grid', gridTemplateColumns: '1fr 100px 110px 110px',
                  padding: '10px 14px', background: 'var(--surface-sunken)',
                  fontSize: 12.5, fontWeight: 600, alignItems: 'center',
                }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Icon name="chevron-down" size={12} /> {g.title} <span className="micro" style={{ marginLeft: 4 }}>({g.n})</span>
                  </span>
                  <span style={{ textAlign: 'center' }} className="micro">—</span>
                  <span style={{ textAlign: 'right', color: g.total > 0 ? 'var(--neg)' : g.total < 0 ? 'var(--pos)' : 'var(--ink-soft)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>
                    {g.total > 0 ? '+' : ''}${g.total.toLocaleString()}
                  </span>
                  <span style={{ textAlign: 'right', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>${running.toLocaleString()}</span>
                </div>
                {g.items.map((it) => (
                  <div key={it[0]} style={{
                    display: 'grid', gridTemplateColumns: '1fr 100px 110px 110px',
                    padding: '8px 14px 8px 32px',
                    fontSize: 12.5,
                    borderTop: '1px solid var(--rule)',
                  }}>
                    <span style={{ color: 'var(--ink-soft)' }}>{it[0]}</span>
                    <span style={{ textAlign: 'center', fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{it[1]}</span>
                    <span style={{ textAlign: 'right', color: it[2] > 0 ? 'var(--neg)' : it[2] < 0 ? 'var(--pos)' : 'var(--ink-soft)', fontVariantNumeric: 'tabular-nums' }}>
                      {it[2] > 0 ? '+' : ''}${Math.abs(it[2]).toLocaleString()}
                    </span>
                    <span className="micro">—</span>
                  </div>
                ))}
              </div>
            );
          })}

          {/* final premium build-up */}
          <div style={{ marginTop: 18, padding: '14px 16px', background: 'var(--info-soft)', border: '1px solid var(--info)', borderRadius: 10 }}>
            <div className="eyebrow" style={{ color: 'var(--info-deep)', marginBottom: 10 }}>Final premium</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 6, fontSize: 13 }}>
              <span>Loaded premium</span><span style={{ fontFamily: 'ui-monospace, monospace' }}>$185,200</span>
              <span>ILF factor (limit $10M)</span><span style={{ fontFamily: 'ui-monospace, monospace' }}>1.000x</span>
              <span>Deductible factor ($50k)</span><span style={{ fontFamily: 'ui-monospace, monospace' }}>1.000x</span>
              <div style={{ gridColumn: '1 / -1', borderTop: '1px solid var(--info)', marginTop: 6, paddingTop: 8, display: 'flex', justifyContent: 'space-between' }}>
                <strong style={{ fontSize: 15 }}>Recommended premium</strong>
                <strong style={{ fontSize: 18, color: 'var(--info-deep)', fontFamily: 'ui-monospace, monospace' }}>$185,200</strong>
              </div>
            </div>
          </div>
        </WbCard>

        <WbCard title="Recommended Quote + Limit Options" icon="circle-ellipsis">
          {[
            { label: 'Upper', limit: 25_000_000, premium: 214_900, rol: 0.0086, rationale: 'Lift to $25M tower — best ROL for cohort. Cyber market loosening.' },
            { label: 'Recommended', limit: 10_000_000, premium: 185_200, rol: 0.0185, rationale: 'Current request. Standard ILF curve, well within carrier appetite.', selected: true },
            { label: 'Lower', limit:  5_000_000, premium: 148_400, rol: 0.0297, rationale: 'Minimum adequate for cohort — would clear approval threshold faster.' },
          ].map((o, i) => (
            <div key={o.label} style={{
              padding: 14,
              marginBottom: 10,
              borderRadius: 10,
              background: o.selected ? 'var(--info-soft)' : 'var(--surface-elev)',
              border: '1px solid ' + (o.selected ? 'var(--info)' : 'var(--rule)'),
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
                <span style={{ fontWeight: 700, fontSize: 13 }}>{o.label}</span>
                {o.selected && <span className="chip chip-info">CURRENT</span>}
              </div>
              <WbRow k="Technical limit"   v={`$${(o.limit / 1_000_000).toFixed(0)}M`} mono />
              <WbRow k="Technical premium" v={`$${o.premium.toLocaleString()}`} mono bold />
              <WbRow k="RoL"               v={`${(o.rol * 100).toFixed(2)}%`} mono />
              <div className="caption" style={{ marginTop: 8, fontSize: 11.5, lineHeight: 1.5 }}>{o.rationale}</div>
              {!o.selected && <button className="btn ghost" style={{ marginTop: 10, width: '100%', justifyContent: 'center', padding: '6px 10px', fontSize: 12 }}>Select</button>}
            </div>
          ))}
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── 03 Risk Assessment ──────────────────────────────────────── */
function WbRisk({ isDark }) {
  const tiers = [
    { id: 1, label: 'Preferred',       min: 800, max: 1000, action: 'approve' },
    { id: 2, label: 'Standard',        min: 700, max: 799,  action: 'approve' },
    { id: 3, label: 'Under review',    min: 600, max: 699,  action: 'refer' },
    { id: 4, label: 'Sub-standard',    min: 500, max: 599,  action: 'refer' },
    { id: 5, label: 'Decline',         min:   0, max: 499,  action: 'decline' },
  ];
  const groups = [
    { id: 'cyber.posture',  score: 71, weight: 0.34, contribution: 24.1, sigs: 12, expected: 12 },
    { id: 'financial',      score: 78, weight: 0.22, contribution: 17.2, sigs: 6, expected: 6 },
    { id: 'claims.history', score: 84, weight: 0.18, contribution: 15.1, sigs: 4, expected: 5 },
    { id: 'identity',       score: 62, weight: 0.12, contribution:  7.4, sigs: 5, expected: 6 },
    { id: 'industry',       score: 58, weight: 0.10, contribution:  5.8, sigs: 3, expected: 4 },
    { id: 'exposure',       score: 64, weight: 0.04, contribution:  2.6, sigs: 2, expected: 3 },
  ];
  return (
    <WorkbenchFrame active="Risk Assessment" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Results" icon="glasses">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 16 }}>
            <WbKpi label="Pure composite" value="724" />
            <WbKpi label="Confidence"      value="86%" tone="pos" />
            <WbKpi label="Signal coverage" value="92%" tone="pos" />
            <WbKpi label="Pure tier"       value="T2" />
            <WbKpi label="Final composite" value="724" tone="info" />
            <WbKpi label="Final tier"      value="T2 · Standard" tone="info" />
          </div>
        </WbCard>

        <WbCard title="Tier Position & Improvement Paths" icon="gauge">
          <div style={{ display: 'grid', gridTemplateColumns: `repeat(${tiers.length}, 1fr)`, gap: 8 }}>
            {tiers.map((t) => {
              const isCurrent = t.id === WB.tier;
              return (
                <div key={t.id}>
                  <div style={{
                    position: 'relative', height: 28, borderRadius: 6,
                    background: 'var(--surface-elev)',
                    border: isCurrent ? '2px solid var(--info)' : '1px solid var(--rule)',
                  }}>
                    {isCurrent && (
                      <>
                        <div style={{ position: 'absolute', left: '24%', top: 0, bottom: 0, width: 2, background: 'var(--info)' }} />
                        <div style={{ position: 'absolute', top: -18, left: '24%', transform: 'translateX(-50%)', fontSize: 10, fontWeight: 700, color: 'var(--info)' }}>724</div>
                      </>
                    )}
                  </div>
                  <div style={{ marginTop: 4, display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--ink-mute)' }}>
                    <span>{t.min}</span>
                    <span style={{ fontWeight: isCurrent ? 700 : 500, color: isCurrent ? 'var(--info)' : 'inherit' }}>T{t.id} · {t.label}</span>
                    <span>{t.max}</span>
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--rule)' }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}><Icon name="arrow-up" size={11} /> Paths to improve</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 8 }}>
              <div style={{ padding: '10px 12px', background: 'var(--surface-elev)', borderRadius: 8, border: '1px solid var(--rule)', display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 14, alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>Tier 1 — Preferred</div>
                  <div className="micro">Key levers: cyber.posture (SOC 2), claims.history</div>
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-soft)' }}>Target range 800–1000</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--pos)' }}>+76 pts</div>
              </div>
            </div>
          </div>
        </WbCard>

        <WbCard title="Group & Signal Breakdown" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 70px 70px 90px 70px 90px', padding: '8px 0', borderBottom: '1px solid var(--rule)' }}>
            {['Group', 'Score', 'Weight', 'Contribution', 'Coverage', 'Status'].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 10.5 }}>{h}</span>
            ))}
          </div>
          {groups.map((g) => (
            <div key={g.id} style={{
              display: 'grid', gridTemplateColumns: '1.6fr 70px 70px 90px 70px 90px',
              padding: '10px 0', borderBottom: '1px solid var(--rule)', alignItems: 'center',
            }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                <Icon name="chevron-right" size={11} color="var(--ink-mute)" />
                <span style={{ fontFamily: 'ui-monospace, monospace', fontWeight: 600 }}>{g.id}</span>
                <span className="micro">({g.sigs})</span>
              </span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{g.score.toFixed(1)}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--ink-soft)' }}>{g.weight.toFixed(2)}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{g.contribution.toFixed(1)}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums', color: g.sigs === g.expected ? 'var(--pos)' : 'var(--warn)' }}>{g.sigs}/{g.expected}</span>
              <span className="chip chip-pos" style={{ justifySelf: 'flex-start' }}>active</span>
            </div>
          ))}
        </WbCard>

        <WbCard title="Active conditions" icon="alert-triangle" headerRight={<span className="micro">3</span>}>
          {[
            ['SOC 2 Type II missing',     'signal_condition', 'modifier · 1.10x',           'spot'],
            ['Public RDP exposed',         'signal_condition', 'referral',                    'spot'],
            ['No prior claims · 5yr',      'signal_condition', 'modifier · 0.95x',           'pos'],
          ].map(([note, type, action, tone], i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 12, alignItems: 'center', padding: '10px 0', borderBottom: i < 2 ? '1px solid var(--rule)' : 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Icon name="shield-alert" size={14} color="var(--ink-soft)" />
                <div>
                  <span style={{ fontSize: 13 }}>{note}</span>
                  <span className="micro" style={{ display: 'block', marginTop: 2 }}>{type}</span>
                </div>
              </div>
              <span className={`chip chip-${tone}`}>{action}</span>
            </div>
          ))}
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

Object.assign(window, { WbSummary, WbPricing, WbRisk });
