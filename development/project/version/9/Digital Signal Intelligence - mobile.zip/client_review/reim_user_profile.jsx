/* global React, FrameReimag, Icon */

/* ============================================================
 * User Profile — account settings + security
 *
 * Layout
 *   row 1 — identity header
 *   row 2 — account facts (2-col)  +  permissions chips (full row of card-tinted pills)
 *   row 3 — three security cards: 2FA / Password / Notifications
 * ============================================================ */

function ReimUserProfile({ isDark }) {
  // Use carrier persona for the chrome (most likely target for a "user profile" page);
  // the page itself is persona-agnostic.
  return (
    <FrameReimag menu="Your Account" entity="Hartford Mutual" persona="carrier" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* identity */}
        <div className="card" style={{ padding: 24, display: 'flex', gap: 18, alignItems: 'center' }}>
          <div style={{
            width: 72, height: 72, borderRadius: '50%',
            background: 'var(--ink)', color: 'var(--canvas)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            font: '600 28px IBM Plex Sans',
            flexShrink: 0,
          }}>JR</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="eyebrow">Your account</div>
            <h2 className="display" style={{ marginTop: 4 }}>Jordan Reyes</h2>
            <div className="caption" style={{ marginTop: 4 }}>
              jordan.reyes@hartfordmutual.com · Senior Underwriter · Cyber + PI
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
              <span className="chip"><Icon name="building-2" size={11} /> Hartford Mutual</span>
              <span className="chip chip-pos"><Icon name="shield-check" size={11} /> MFA enabled</span>
              <span className="chip"><Icon name="calendar" size={11} /> Joined Mar 2024</span>
            </div>
          </div>
        </div>

        {/* details + permissions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Identity</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 14px' }}>Registered details</h3>
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {[
                ['Full name',  'Jordan Reyes'],
                ['Email',      'jordan.reyes@hartfordmutual.com'],
                ['User ID',    'usr_8x42aPq3kJfM'],
                ['Tenant',     'hartford-mutual'],
                ['Role',       'CARRIER_UNDERWRITER'],
                ['Last login', '2026-05-27 14:22 UTC'],
              ].map(([k, v], i, arr) => (
                <div key={k} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
                  padding: '8px 0', borderBottom: i < arr.length - 1 ? '1px solid var(--rule)' : 0,
                }}>
                  <span className="micro">{k}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, fontFamily: k === 'User ID' || k === 'Tenant' ? 'ui-monospace, monospace' : 'inherit' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card" style={{ padding: 22 }}>
            {(() => {
              const PERMS = [
                ['Submission',    ['read', 'assess', 'decide', 'assign']],
                ['Communication', ['read', 'reply', 'escalate']],
                ['World Engine',  ['read', 'simulate', 'configure']],
                ['Recalibration', ['view', 'simulate', 'propose']],
                ['Pricing',       ['read', 'override']],
                ['Portfolio',     ['read', 'analyze']],
                ['Analytics',     ['view', 'export']],
                ['Config',        ['read']],
                ['Losses',        ['read']],
                ['Audit',         ['read']],
              ];
              const total = PERMS.reduce((n, [, a]) => n + a.length, 0);
              return (
                <React.Fragment>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <div>
                      <div className="eyebrow">Permissions</div>
                      <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>What you can do</h3>
                    </div>
                    <span className="chip">{total} across {PERMS.length} resources</span>
                  </div>
                  {/* Grouped by resource — scales cleanly to long permission sets
                      instead of a flat wrap of monospace pills. */}
                  <div style={{ display: 'flex', flexDirection: 'column', marginTop: 12 }}>
                    {PERMS.map(([res, acts], i) => (
                      <div key={res} style={{
                        display: 'flex', alignItems: 'center', gap: 14,
                        padding: '9px 0',
                        borderBottom: i < PERMS.length - 1 ? '1px solid var(--rule)' : 0,
                      }}>
                        <span style={{ flex: '0 0 132px', fontSize: 13, fontWeight: 600 }}>{res}</span>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                          {acts.map((a) => (
                            <span key={a} className="chip" style={{
                              fontFamily: 'ui-monospace, monospace', fontSize: 10.5,
                              padding: '3px 8px',
                            }}>{a}</span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--rule)' }} className="caption">
                    Granted via the <strong>CARRIER_UNDERWRITER</strong> role. To change, contact your admin.
                  </div>
                </React.Fragment>
              );
            })()}
          </div>
        </div>

        {/* security cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          <div className="card-pos" style={{ padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: 'var(--pos-soft)', color: 'var(--pos)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name="shield-check" size={18} />
              </div>
              <div>
                <div className="eyebrow" style={{ color: 'var(--pos)' }}>Two-factor authentication</div>
              </div>
            </div>
            <div style={{ font: '600 20px/1 IBM Plex Sans', color: 'var(--pos)' }}>Enabled</div>
            <div className="caption" style={{ marginTop: 6, lineHeight: 1.5 }}>
              Backup codes generated · last used 2 weeks ago · authenticator app on iPhone.
            </div>
            <button className="btn ghost" style={{ marginTop: 14, width: '100%', justifyContent: 'center' }}>
              Manage devices
            </button>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: 'var(--surface-elev)', color: 'var(--ink)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '1px solid var(--rule)',
              }}>
                <Icon name="key-round" size={18} />
              </div>
              <div>
                <div className="eyebrow">Password</div>
              </div>
            </div>
            <div style={{ font: '600 20px/1 IBM Plex Sans' }}>Last changed</div>
            <div className="caption" style={{ marginTop: 6, lineHeight: 1.5 }}>
              42 days ago · meets length + complexity policy. Reset by sending yourself a one-time link.
            </div>
            <button className="btn" style={{ marginTop: 14, width: '100%', justifyContent: 'center' }}>
              <Icon name="mail" size={13} /> Send reset link
            </button>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8,
                background: 'var(--surface-elev)', color: 'var(--ink)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '1px solid var(--rule)',
              }}>
                <Icon name="bell" size={18} />
              </div>
              <div>
                <div className="eyebrow">Notifications</div>
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
              {[
                ['New referral on my queue',  true],
                ['Drift alert (high severity)', true],
                ['Daily pipeline digest',     false],
                ['Recalibration proposal',    true],
              ].map(([label, on]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 13 }}>{label}</span>
                  <div style={{
                    width: 32, height: 18, borderRadius: 9,
                    background: on ? 'var(--pos)' : 'var(--rule-strong)',
                    position: 'relative', flexShrink: 0,
                  }}>
                    <div style={{
                      position: 'absolute', top: 2, left: on ? 16 : 2,
                      width: 14, height: 14, borderRadius: '50%',
                      background: '#fff',
                    }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

Object.assign(window, { ReimUserProfile });
