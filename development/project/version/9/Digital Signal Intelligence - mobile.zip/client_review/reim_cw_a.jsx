/* global React, Icon, ClientWorkbenchFrame, WbCard, WbKpi, WbRow, CW, tierColor, decisionTone */

/* ============================================================
 * Client Workbench tabs — group A
 *   • Summary          (identity + active coverages + aggregates)
 *   • Coverage List    (one card per coverage)
 *   • Premium Build-up (modifier chain + commercial)
 *   • Risk Terms       (per-coverage terms)
 * ============================================================ */

/* ─── 01 Summary ─────────────────────────────────────────────── */
function CwSummary({ isDark }) {
  const tiers = [1, 2, 3, 4, 5].map(t => ({ t, n: CW.coverages.filter(c => c.tier === t).length }));
  const stateMix = [
    { label: 'Bound',     n: CW.coverages.filter(c => c.status === 'Bound').length,       tone: 'pos' },
    { label: 'Referred',  n: CW.coverages.filter(c => c.decision === 'refer').length,     tone: 'spot' },
    { label: 'Declined',  n: CW.coverages.filter(c => c.decision === 'decline').length,   tone: 'neg' },
  ];

  return (
    <ClientWorkbenchFrame active="Summary" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        {/* identity + KPI strip */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 2.5fr', gap: 14 }}>
          <WbCard title="Client" icon="building-2" padding={18}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
              <div style={{
                width: 52, height: 52, borderRadius: 12, flexShrink: 0,
                background: 'var(--info-soft)', color: 'var(--info-deep)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                font: '700 18px IBM Plex Sans',
              }}>ER</div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 16, fontWeight: 700 }}>{CW.entity}</div>
                <a href={`https://${CW.domain}`} className="micro" style={{ color: 'var(--info)', fontFamily: 'ui-monospace, monospace' }}>{CW.domain}</a>
              </div>
            </div>
            <WbRow k="Industry"     v={CW.industry} />
            <WbRow k="NAICS"        v={CW.naics} mono />
            <WbRow k="Revenue band" v={CW.revenueBand} />
            <WbRow k="Locations"    v={`${CW.country} · ${CW.locations}`} />
            <WbRow k="Employees"    v={CW.employees} />
            <WbRow k="Broker"       v={CW.broker} />
            <WbRow k="Relationship" v={`${CW.firstSeen} → ${CW.lastSeen}`} />
          </WbCard>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              <WbCardKpi label="Total premium" value={`$${(CW.totalPremium / 1000).toFixed(0)}k`} sub="annual, across coverages" tone="info" />
              <WbCardKpi label="Active coverages" value={CW.coverages.length} sub="Cyber · PI · D&O" />
              <WbCardKpi label="Avg signal score" value={CW.avgScore} sub="weighted across lines" />
              <WbCardKpi label="Engagement" value={CW.engagement} sub={CW.engagementLabel} tone="pos" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              <WbCardKpi label="Open queries" value={CW.openQueries} sub="awaiting action" tone="spot" />
              <WbCardKpi label="Avg response" value={`${CW.avgResponseHours}h`} sub="client replies" />
              <WbCardKpi label="Next renewal" value={`${CW.nextRenewalDays}d`} sub="earliest coverage" tone="warn" />
              <WbCardKpi label="Last message" value={CW.lastMessage} sub="most recent thread" />
            </div>
          </div>
        </div>

        {/* active coverages */}
        <WbCard title="Active coverages" icon="shield-check" headerRight={<span className="chip">{CW.coverages.length} in force</span>}>
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1.4fr 80px 70px 90px 110px 130px',
            padding: '0 0 8px', borderBottom: '1px solid var(--rule)',
          }}>
            {['Line', 'Carrier', 'Score', 'Tier', 'Percentile', 'Premium', 'Status'].map(h => (
              <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {CW.coverages.map((c, i) => (
            <div key={c.code} style={{
              display: 'grid', gridTemplateColumns: '1fr 1.4fr 80px 70px 90px 110px 130px',
              alignItems: 'center', padding: '11px 0',
              borderBottom: i < CW.coverages.length - 1 ? '1px solid var(--rule)' : 0, fontSize: 13,
            }}>
              <span style={{ fontWeight: 600 }}>{c.line}</span>
              <span style={{ color: 'var(--ink-soft)' }}>{c.carrier}</span>
              <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{c.score}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 24, height: 24, borderRadius: 6,
                background: tierColor(c.tier) + '22', color: tierColor(c.tier),
                fontWeight: 700, fontSize: 12,
              }}>{c.tier}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{c.percentile}th</span>
              <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(c.premium / 1000).toFixed(0)}k</span>
              <span className={`chip chip-${c.statusTone}`} style={{ justifySelf: 'flex-start' }}>{c.status}</span>
            </div>
          ))}
        </WbCard>

        {/* aggregates */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14 }}>
          <WbCard title="Tier mix" icon="layers" padding={18}>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, height: 92, marginTop: 4 }}>
              {tiers.map(({ t, n }) => (
                <div key={t} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
                  <span className="num-sm" style={{ fontSize: 14, color: tierColor(t), fontVariantNumeric: 'tabular-nums' }}>{n}</span>
                  <div style={{ width: '100%', height: `${(n / 2) * 100}%`, minHeight: 4, background: tierColor(t), borderRadius: '5px 5px 0 0' }} />
                  <span className="micro" style={{ fontSize: 10 }}>T{t}</span>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 12 }}>Two preferred (T2) lines; the D&O placement sits in T4 and is worth a touchpoint.</div>
          </WbCard>

          <WbCard title="Pipeline state" icon="git-branch" padding={18}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 2 }}>
              {stateMix.map(s => (
                <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: `var(--${s.tone})`, flexShrink: 0 }} />
                  <span style={{ fontSize: 13, flex: 1 }}>{s.label}</span>
                  <span style={{ fontSize: 15, fontWeight: 700, color: `var(--${s.tone})`, fontVariantNumeric: 'tabular-nums' }}>{s.n}</span>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 14, paddingTop: 10, borderTop: '1px solid var(--rule)' }}>
              2 referrals open — one awaiting the client, one awaiting you.
            </div>
          </WbCard>

          <WbCard title="Coverage lines" icon="list-checks" padding={18}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 2 }}>
              {CW.coverages.map(c => (
                <div key={c.code} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Icon name="shield-check" size={14} color="var(--info)" />
                  <span style={{ fontSize: 13, fontWeight: 600, flex: 1 }}>{c.line}</span>
                  <span className="micro">{c.carrier}</span>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 14, paddingTop: 10, borderTop: '1px solid var(--rule)' }}>
              Cyber, PI and D&O placed across three carriers.
            </div>
          </WbCard>
        </div>

      </div>
    </ClientWorkbenchFrame>
  );
}

/* small KPI card used on the summary strip — wraps shared <Kpi>. */
function WbCardKpi(props) {
  return <Kpi {...props} surface="card" valueSize={24} />;
}

/* ─── 02 Coverage List ───────────────────────────────────────── */
function CwCoverageList({ isDark }) {
  return (
    <ClientWorkbenchFrame active="Coverage List" isDark={isDark}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {CW.coverages.map((c) => (
          <div key={c.code} className="card" style={{ padding: 18, borderLeft: `4px solid ${tierColor(c.tier)}` }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1.3fr', gap: 20, alignItems: 'center' }}>
              {/* identity */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 16, fontWeight: 700 }}>{c.line}</span>
                  <span className={`chip chip-${decisionTone(c.decision)}`}>{c.decision}</span>
                </div>
                <div className="micro">{c.carrier} · <code style={{ fontFamily: 'ui-monospace, monospace' }}>{c.code}</code></div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, marginTop: 8, color: c.statusTone === 'pos' ? 'var(--pos)' : 'var(--spot)' }}>
                  <Icon name={c.statusTone === 'pos' ? 'check-circle-2' : 'clock'} size={13} />
                  {c.status}
                </div>
              </div>
              {/* score */}
              <div>
                <div className="micro">Signal score</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 2 }}>
                  <span className="num" style={{ fontSize: 26, color: 'var(--info)', fontVariantNumeric: 'tabular-nums' }}>{c.score}</span>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                    minWidth: 22, height: 22, padding: '0 6px', borderRadius: 6,
                    background: tierColor(c.tier) + '22', color: tierColor(c.tier), fontWeight: 700, fontSize: 12,
                  }}>T{c.tier}</span>
                </div>
                <div className="micro" style={{ marginTop: 4 }}>{c.tierLabel} · {c.percentile}th pct · {c.confidence}% conf.</div>
              </div>
              {/* commercial */}
              <div>
                <div className="micro">Premium</div>
                <div className="num" style={{ fontSize: 22, marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>${(c.premium / 1000).toFixed(0)}k</div>
                <div className="micro" style={{ marginTop: 4 }}>limit ${(c.limit / 1_000_000).toFixed(0)}M · ded ${(c.deductible / 1000).toFixed(0)}k</div>
              </div>
              {/* signal coverage */}
              <div>
                <div className="micro">Signal coverage</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
                  <span className="num" style={{ fontSize: 18, fontVariantNumeric: 'tabular-nums' }}>{c.signalCoverage}%</span>
                  <span className="caption">of expected signals</span>
                </div>
                <div style={{ marginTop: 8, height: 5, background: 'var(--rule)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ width: `${c.signalCoverage}%`, height: '100%', background: c.signalCoverage >= 85 ? 'var(--pos)' : 'var(--warn)' }} />
                </div>
                {c.awaiting && (
                  <div className="micro" style={{ marginTop: 8, color: c.awaiting === 'broker' ? 'var(--spot)' : 'var(--info)' }}>
                    {c.awaiting === 'broker' ? 'Awaiting you' : 'Awaiting client'}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 03 Premium Build-up ────────────────────────────────────── */
function CwPremium({ isDark }) {
  // Modifier chain for the featured Cyber coverage.
  const chain = [
    { group: 'Base premium',       factor: null,    delta: null,    running: 168400, kind: 'base' },
    { group: 'Categorical',        factor: '0.98x', delta: -4200,   running: 164200 },
    { group: 'Signal-based',       factor: '1.06x', delta: 9800,    running: 174000 },
    { group: 'Direct queries',     factor: '1.03x', delta: 4900,    running: 178900 },
    { group: 'Loss analysis',      factor: '0.95x', delta: -8400,   running: 170500 },
    { group: 'Exposure analysis',  factor: '1.04x', delta: 6300,    running: 176800 },
  ];
  const technical = 185200;

  return (
    <ClientWorkbenchFrame active="Premium Build-up" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 14, alignContent: 'start' }}>
        <WbCard title="Premium build-up · Cyber" icon="calculator" headerRight={<span className="chip">SUB-26-0118</span>}>
          {chain.map((row) => (
            <div key={row.group} style={{
              display: 'grid', gridTemplateColumns: '1.4fr 70px 110px 120px', gap: 10, alignItems: 'center',
              padding: '10px 0', borderBottom: '1px solid var(--rule)',
            }}>
              <span style={{ fontSize: 13, fontWeight: row.kind === 'base' ? 700 : 500 }}>{row.group}</span>
              <span className="micro" style={{ fontVariantNumeric: 'tabular-nums' }}>{row.factor || ''}</span>
              <span style={{
                fontSize: 13, fontWeight: 600, fontVariantNumeric: 'tabular-nums',
                color: row.delta == null ? 'var(--ink-mute)' : row.delta < 0 ? 'var(--pos)' : 'var(--neg)',
              }}>{row.delta == null ? '—' : `${row.delta < 0 ? '−' : '+'}$${Math.abs(row.delta).toLocaleString()}`}</span>
              <span style={{ fontSize: 13, fontWeight: 700, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>${row.running.toLocaleString()}</span>
            </div>
          ))}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 70px 110px 120px', gap: 10, paddingTop: 12, marginTop: 4 }}>
            <span style={{ fontSize: 14, fontWeight: 700 }}>Technical premium</span>
            <span /><span />
            <span style={{ fontSize: 17, fontWeight: 700, color: 'var(--info-deep)', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>${technical.toLocaleString()}</span>
          </div>
        </WbCard>

        <WbCard title="Commercial" icon="building-2" padding={18}>
          <WbRow k="Technical premium" v="$185,200" mono bold />
          <WbRow k="Brokerage"         v="12.5%" />
          <WbRow k="Net premium"       v="$162,050" mono />
          <WbRow k="Taxes + levies"    v="$8,540" mono />
          <WbRow k="Gross premium"     v="$170,590" mono bold />
          <WbRow k="Offered premium"   v="$170,590" mono bold tone="info" />
          <WbRow k="Total commission"  v="$23,150" mono />
          <WbRow k="Distribution"      v="Subscription · signed 45%" />
          <WbRow k="Role"              v="Lead · 1.00x loading" />
          <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--rule)' }} className="caption">
            Cyber line shown. PI and D&O build-ups follow the same chain with line-specific factors.
          </div>
        </WbCard>
      </div>
    </ClientWorkbenchFrame>
  );
}

/* ─── 04 Risk Terms ──────────────────────────────────────────── */
function CwRiskTerms({ isDark }) {
  const terms = {
    'SUB-26-0118': { ded: '$50,000 · per occurrence', sir: 'No', wait: '8 hours', agg: '$10,000,000', reinst: '1 · 50% of premium', trigger: 'Claims-made · worldwide ex-OFAC', ext: 4, exc: 6, sub: 'Ransomware $2M · Reg fines $1M' },
    'SUB-26-0119': { ded: '$35,000 · per claim',       sir: 'No', wait: '—',       agg: '$5,000,000',  reinst: 'None',              trigger: 'Claims-made · USA + Canada',     ext: 3, exc: 5, sub: 'Cyber-PI overlap $1M' },
    'SUB-26-0120': { ded: '$75,000 · per claim',       sir: '$25,000', wait: '—',  agg: '$10,000,000', reinst: '1 · 100% of premium', trigger: 'Claims-made · worldwide ex-OFAC', ext: 5, exc: 8, sub: 'Side-A DIC $2.5M' },
  };
  return (
    <ClientWorkbenchFrame active="Risk Terms" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, alignContent: 'start' }}>
        {CW.coverages.map((c) => {
          const t = terms[c.code];
          return (
            <WbCard key={c.code} title={`${c.line} · risk terms`} icon="scale" padding={18}
              headerRight={<span className={`chip chip-${decisionTone(c.decision)}`}>{c.decision}</span>}>
              <WbRow k="Deductible"     v={t.ded} mono />
              <WbRow k="SIR"            v={t.sir} tone={t.sir === 'No' ? undefined : 'info'} />
              <WbRow k="Waiting period" v={t.wait} />
              <WbRow k="Aggregate"      v={t.agg} mono />
              <WbRow k="Reinstatements" v={t.reinst} />
              <WbRow k="Trigger"        v={t.trigger} />
              <WbRow k="Extensions"     v={t.ext} />
              <WbRow k="Exclusions"     v={t.exc} />
              <WbRow k="Sub-limits"     v={t.sub} mono />
            </WbCard>
          );
        })}
      </div>
    </ClientWorkbenchFrame>
  );
}

Object.assign(window, { CwSummary, CwCoverageList, CwPremium, CwRiskTerms });
