/* global React, FrameReimag, Icon, BROKER, BROKER_BOOK, BROKER_QUERIES, bookByClient */

/* ============================================================
 * 01. Book of Clients — broker home
 *
 * Layout
 *   row 1 — hero strip: broker identity + book stats (4 KPIs)
 *   row 2 — book roster (filterable table)
 *   row 3 — tier mix bar + open queries snapshot
 * ============================================================ */

function ReimBrokerBook({ isDark }) {
  const policies = BROKER_BOOK;
  const clients  = bookByClient();
  const totalPremium = policies.reduce((s, p) => s + p.premium, 0);
  const avgScore = Math.round(policies.reduce((s, p) => s + p.score, 0) / policies.length);
  const awaitingBroker = BROKER_QUERIES.filter(q => q.awaiting === 'broker').length;
  const tiers = [1, 2, 3, 4, 5].map(t => ({
    t, n: policies.filter(p => p.tier === t).length,
  }));
  const maxTier = Math.max(...tiers.map(b => b.n), 1);
  const tierColor = (t) => t <= 2 ? 'var(--pos)' : t === 3 ? 'var(--info)' : t === 4 ? 'var(--warn)' : 'var(--neg)';

  return (
    <FrameReimag menu="Book of Clients" entity={BROKER.shortName} persona="broker" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 16, height: '100%', alignContent: 'start' }}>

        {/* row 1 — hero stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 24, display: 'flex', alignItems: 'center', gap: 18 }}>
            <div style={{
              width: 64, height: 64, borderRadius: 12,
              background: 'var(--info-soft)', color: 'var(--info-deep)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name="briefcase" size={32} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="eyebrow">Broker book</div>
              <h2 className="display" style={{ marginTop: 4, lineHeight: 1.1 }}>
                Marsh
                <span style={{ display: 'block', fontSize: 18, fontWeight: 400, color: 'var(--ink-soft)', marginTop: 4 }}>
                  Northeast Specialty
                </span>
              </h2>
              <div className="caption" style={{ marginTop: 8 }}>
                {clients.length} clients · {policies.length} policies in force
              </div>
            </div>
          </div>
          <KpiCard label="Aggregate premium" value={`$${(totalPremium / 1_000_000).toFixed(2)}M`} sub="annual" />
          <KpiCard label="Avg signal score" value={avgScore} sub="across the book" tone="info" />
          <KpiCard label="Awaiting you" value={awaitingBroker} sub={`of ${BROKER_QUERIES.length} open queries`} tone="spot" />
        </div>

        {/* row 2 — roster table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 20px', borderBottom: '1px solid var(--rule)',
            background: 'var(--surface-elev)',
          }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <h3 style={{ font: '600 16px/1 IBM Plex Sans', margin: 0 }}>Book roster</h3>
              <span className="chip">{policies.length} policies</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className="micro" style={{ marginRight: 4 }}>Filter:</span>
              <span className="chip" style={{ background: 'var(--ink)', color: 'var(--canvas)', borderColor: 'var(--ink)' }}>All</span>
              <span className="chip">Industrial</span>
              <span className="chip">Healthcare</span>
              <span className="chip">Energy</span>
              <span className="chip">Pharma</span>
              <span className="chip">Transport</span>
            </div>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '2fr 1.4fr 1fr 80px 70px 95px 110px 120px 28px',
            background: 'var(--surface-sunken)',
            padding: '8px 20px',
            borderBottom: '1px solid var(--rule)',
          }}>
            {['Client', 'Coverage', 'Carrier', 'Score', 'Tier', 'Percentile', 'Premium', 'Status', ''].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 10.5, letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>
          {policies.map((p, i) => (
            <div key={p.code} style={{
              display: 'grid',
              gridTemplateColumns: '2fr 1.4fr 1fr 80px 70px 95px 110px 120px 28px',
              gap: 0, alignItems: 'center',
              padding: '10px 20px',
              borderBottom: i < policies.length - 1 ? '1px solid var(--rule)' : 0,
              fontSize: 13,
            }}>
              <span style={{ fontWeight: 600 }}>{p.entity}</span>
              <span style={{ color: 'var(--ink-soft)' }}>{p.line}</span>
              <span style={{ color: 'var(--ink-soft)' }}>{p.carrier}</span>
              <span className="info" style={{ fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{p.score}</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                width: 24, height: 24, borderRadius: 6,
                background: tierColor(p.tier) + '22',
                color: tierColor(p.tier),
                fontWeight: 700, fontSize: 12,
              }}>{p.tier}</span>
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{p.percentile}th</span>
              <span style={{ fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>${(p.premium / 1000).toFixed(0)}k</span>
              <span className={`chip chip-${p.statusTone}`} style={{ alignSelf: 'flex-start', justifySelf: 'flex-start' }}>{p.status}</span>
              <Icon name="chevron-right" size={16} color="var(--ink-mute)" />
            </div>
          ))}
        </div>

        {/* row 3 — tier mix + open queries */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 16 }}>
          <div className="card" style={{ padding: 22 }}>
            <div className="eyebrow">Tier mix</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 12px' }}>Risk quality across the book</h3>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 140, marginTop: 8 }}>
              {tiers.map(({ t, n }) => (
                <div key={t} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                  <span className="num-sm" style={{ fontSize: 16, color: tierColor(t), fontVariantNumeric: 'tabular-nums' }}>{n}</span>
                  <div style={{
                    width: '100%', height: `${(n / maxTier) * 100}%`, minHeight: 4,
                    background: tierColor(t), borderRadius: '6px 6px 0 0',
                  }} />
                  <span className="micro">Tier {t}</span>
                </div>
              ))}
            </div>
            <div className="caption" style={{ marginTop: 14, paddingTop: 10, borderTop: '1px solid var(--rule)' }}>
              Most of the book is mid-tier (3); the two tier-4 outliers (BrightLeaf, TerraWind) are worth a proactive touchpoint.
            </div>
          </div>

          <div className="card" style={{ padding: 22 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div>
                <div className="eyebrow">Open queries</div>
                <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Things waiting on you or your clients</h3>
              </div>
              <span className="chip chip-spot">{awaitingBroker} on you</span>
            </div>
            <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {BROKER_QUERIES.filter(q => q.awaiting !== 'resolved').slice(0, 4).map((q) => (
                <div key={q.refCode} style={{
                  display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 12, alignItems: 'center',
                  padding: '10px 14px',
                  background: 'var(--surface-elev)',
                  border: '1px solid var(--rule)',
                  borderRadius: 8,
                }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{q.entity}</div>
                    <div className="micro" style={{
                      overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      maxWidth: 320, marginTop: 2,
                    }}>{q.ask}</div>
                  </div>
                  <span className={`chip ${q.awaiting === 'broker' ? 'chip-spot' : 'chip-info'}`}>
                    {q.awaiting === 'broker' ? 'on you' : 'on client'}
                  </span>
                  <span className="micro">{q.age}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </FrameReimag>
  );
}

function KpiCard({ label, value, sub, tone }) {
  const color = tone === 'info' ? 'var(--info-deep)' : tone === 'spot' ? 'var(--spot-deep)' : 'var(--ink)';
  const cardCls = tone === 'info' ? 'card-info' : tone === 'spot' ? 'card-spot' : 'card';
  return (
    <div className={cardCls} style={{ padding: 22 }}>
      <div className="eyebrow" style={tone ? { color } : undefined}>{label}</div>
      <div className="num-xl" style={{ marginTop: 6, color, lineHeight: 1 }}>{value}</div>
      <div className="caption" style={{ marginTop: 6 }}>{sub}</div>
    </div>
  );
}

Object.assign(window, { ReimBrokerBook, KpiCard });
