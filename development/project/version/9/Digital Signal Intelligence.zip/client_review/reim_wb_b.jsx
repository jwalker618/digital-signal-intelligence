/* global React, WorkbenchFrame, WbCard, WbKpi, WbRow, WB, Icon */

/* ============================================================
 * Workbench tabs · second batch
 *   • Loss Assessment        (Technical)
 *   • Premium Assembly       (Commercial)
 *   • Coverage Terms         (Risk)
 *   • Referral Actions       (Technical · workflow)
 *   • Model Versions         (Technical · history)
 * ============================================================ */

/* ─── 04 Loss Assessment ──────────────────────────────────────── */
function WbLoss({ isDark }) {
  const W = 560, H = 280;
  const cohort = [
    { x: 28, y: 32, dec: 'approve' }, { x: 45, y: 40, dec: 'approve' }, { x: 35, y: 48, dec: 'approve' },
    { x: 52, y: 36, dec: 'refer'   }, { x: 60, y: 58, dec: 'refer'   }, { x: 48, y: 55, dec: 'refer'   },
    { x: 71, y: 64, dec: 'refer'   }, { x: 78, y: 72, dec: 'decline' }, { x: 82, y: 68, dec: 'decline' },
    { x: 22, y: 25, dec: 'approve' }, { x: 38, y: 30, dec: 'approve' }, { x: 56, y: 50, dec: 'refer'   },
    { x: 40, y: 38, dec: 'approve' }, { x: 30, y: 42, dec: 'approve' }, { x: 50, y: 44, dec: 'refer'   },
  ];
  const color = (d) => d === 'approve' ? 'var(--pos)' : d === 'refer' ? 'var(--warn)' : 'var(--neg)';
  const subject = { x: 32, y: 41 };
  const xToPx = (x) => 40 + (x / 100) * (W - 60);
  const yToPx = (y) => H - 32 - (y / 100) * (H - 64);

  return (
    <WorkbenchFrame active="Loss Assessment" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Active Submission · Loss Profile" icon="target">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 12 }}>
            <WbKpi label="Propensity band"   value="LOW" tone="pos" />
            <WbKpi label="Severity band"     value="MODERATE" />
            <WbKpi label="Combined modifier" value="0.92x" tone="pos" />
            <WbKpi label="Freq multiplier"   value="0.94x" />
            <WbKpi label="Sev multiplier"    value="0.98x" />
            <WbKpi label="Model confidence"  value="84%" />
            <WbKpi label="Cohort"            value="Industrial · Cyber" />
            <WbKpi label="Score velocity"    value="−2.1" tone="pos" sub="improving" />
          </div>
        </WbCard>

        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 14 }}>
          <WbCard title="Frequency vs Severity Matrix" icon="shield-alert">
            <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
              {/* axes */}
              <line x1={40} y1={H - 32} x2={W - 20} y2={H - 32} stroke="var(--rule)" />
              <line x1={40} y1={20}      x2={40}     y2={H - 32} stroke="var(--rule)" />
              {[0, 25, 50, 75, 100].map((v) => (
                <g key={`xg-${v}`}>
                  <line x1={xToPx(v)} y1={H - 32} x2={xToPx(v)} y2={H - 28} stroke="var(--ink-mute)" />
                  <text x={xToPx(v)} y={H - 14} textAnchor="middle" style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{v}</text>
                </g>
              ))}
              {[0, 25, 50, 75, 100].map((v) => (
                <g key={`yg-${v}`}>
                  <line x1={36} y1={yToPx(v)} x2={40} y2={yToPx(v)} stroke="var(--ink-mute)" />
                  <text x={32} y={yToPx(v) + 3} textAnchor="end" style={{ font: '10px IBM Plex Sans', fill: 'var(--ink-mute)' }}>{v}</text>
                </g>
              ))}
              <text x={W/2} y={H - 2} textAnchor="middle" style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-soft)' }}>Loss propensity score →</text>
              <text x={14} y={H/2} textAnchor="middle" transform={`rotate(-90, 14, ${H/2})`} style={{ font: '10.5px IBM Plex Sans', fill: 'var(--ink-soft)' }}>← Severity score</text>

              {/* cohort points */}
              {cohort.map((p, i) => (
                <circle key={i} cx={xToPx(p.x)} cy={yToPx(p.y)} r="4" fill={color(p.dec)} opacity="0.7" />
              ))}
              {/* subject */}
              <circle cx={xToPx(subject.x)} cy={yToPx(subject.y)} r="8" fill="var(--info)" stroke="var(--surface)" strokeWidth="2" />
              <text x={xToPx(subject.x)} y={yToPx(subject.y) - 14} textAnchor="middle" style={{ font: '600 11px IBM Plex Sans', fill: 'var(--info)' }}>YOU · 32/41</text>
            </svg>
            <div style={{ display: 'flex', gap: 12, marginTop: 8, fontSize: 11 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--pos)' }} /> Approved</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--warn)' }} /> Referred</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--neg)' }} /> Declined</span>
            </div>
          </WbCard>

          <WbCard title="Loss Trajectory" icon="trending-up">
            {[
              { label: 'Overall',   trend: 'Improving',   delta: '−2.1', prev: 43.2, cur: 41.1 },
              { label: 'Frequency', trend: 'Improving',   delta: '−1.8', prev: 33.8, cur: 32.0 },
              { label: 'Severity',  trend: 'Stable',      delta: '−0.3', prev: 41.4, cur: 41.1 },
            ].map((t, i) => (
              <div key={i} style={{
                padding: '12px 14px',
                borderRadius: 8,
                background: 'var(--surface-elev)',
                border: '1px solid var(--rule)',
                marginBottom: 8,
              }}>
                <div className="micro" style={{ marginBottom: 4 }}>{t.label}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 14, fontWeight: 700 }}>{t.trend}</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--pos)' }}>{t.delta}</span>
                </div>
                <div className="micro" style={{ marginTop: 4 }}>
                  was {t.prev.toFixed(1)} → now {t.cur.toFixed(1)}
                </div>
              </div>
            ))}
            <div className="caption" style={{ marginTop: 10, fontSize: 11.5 }}>
              Book-wide trend (38 peers): <strong className="pos">12 improving</strong> · <strong>22 stable</strong> · <strong className="neg">4 deteriorating</strong>.
            </div>
          </WbCard>
        </div>

        <WbCard title="Loss Group Scores" icon="layers">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[
              ['cyber.posture',   84, 78, 0.86],
              ['claims.history',  92, 88, 0.91],
              ['industry',        62, 58, 0.74],
              ['exposure',        70, 66, 0.68],
            ].map((g) => (
              <div key={g[0]} style={{ padding: '10px 14px', background: 'var(--surface-elev)', border: '1px solid var(--rule)', borderRadius: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, fontFamily: 'ui-monospace, monospace' }}>{g[0]}</span>
                  <span className="micro">{Math.round(g[3] * 100)}% conf</span>
                </div>
                <div style={{ marginBottom: 4 }}>
                  <div className="micro">Freq</div>
                  <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden', marginTop: 2 }}>
                    <div style={{ width: `${g[1]}%`, height: '100%', background: 'var(--pos)' }} />
                  </div>
                </div>
                <div>
                  <div className="micro">Sev</div>
                  <div style={{ height: 4, background: 'var(--rule)', borderRadius: 2, overflow: 'hidden', marginTop: 2 }}>
                    <div style={{ width: `${g[2]}%`, height: '100%', background: 'var(--info)' }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </WbCard>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── 05 Premium Assembly ─────────────────────────────────────── */
function WbPremium({ isDark }) {
  return (
    <WorkbenchFrame active="Premium Assembly" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto', gap: 14, alignContent: 'start' }}>

        {/* Hero — the answer first, math below */}
        <div className="card-info" style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr auto auto auto', gap: 32, alignItems: 'center' }}>
          <div>
            <div className="eyebrow" style={{ color: 'var(--info-deep)' }}>Offered premium</div>
            <div className="num-xl" style={{ marginTop: 6, color: 'var(--info-deep)', lineHeight: 1 }}>$170,590</div>
            <div className="caption" style={{ marginTop: 8 }}>0% discretion applied · at gross premium</div>
          </div>
          <div>
            <div className="micro">Net premium</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22 }}>$162,050</div>
          </div>
          <div>
            <div className="micro">Gross premium</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22 }}>$170,590</div>
          </div>
          <div>
            <div className="micro">Technical premium</div>
            <div className="num" style={{ marginTop: 4, fontSize: 22, color: 'var(--ink-soft)' }}>$185,200</div>
          </div>
        </div>

        {/* Build-up ledger */}
        <WbCard title="Premium build-up" icon="calculator">
          <Ledger
            opening={{ label: 'Technical premium', value: '$185,200', sub: 'as priced from base × signal modifiers' }}
            sections={[
              { title: 'Deductions',
                items: [
                  ['Brokerage',         '12.5%', -23150],
                  ['Overrider',         '0.0%',       0],
                  ['Profit commission', '0.0%',       0],
                ],
                subtotalLabel: 'Net premium',
                subtotalValue: '$162,050' },
              { title: 'Taxes & levies',
                items: [
                  ['Insurance Premium Tax', '4.5%',  7292],
                  ['Stamp duty',            '0.5%',   810],
                  ['Regulatory levy',       '0.3%',   438],
                ],
                subtotalLabel: 'Gross premium',
                subtotalValue: '$170,590' },
              { title: 'Discretion',
                items: [['Applied',  '0.0%', 0]] },
            ]}
            final={{ label: 'Offered premium', value: '$170,590' }}
          />
        </WbCard>

        {/* Validation footer */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title="Minimum premium check" icon="alert-triangle">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
              <WbKpi label="Minimum gross"   value="$45,000" />
              <WbKpi label="At minimum?"     value="No" />
              <WbKpi label="Max discretion"  value="±10%" />
            </div>
            <div className="caption" style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
              Offered premium clears the carrier's minimum by <strong className="pos">$125,590</strong> — plenty of headroom on a per-risk basis.
            </div>
          </WbCard>
          <WbCard title="Discretion analysis" icon="sliders-horizontal">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <WbKpi label="From gross"  value="0.0%" />
              <WbKpi label="Direction"   value="—" />
              <WbKpi label="Rationale"   value="None recorded" />
              <WbKpi label="Approver"    value="—" />
            </div>
            <div className="caption" style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--rule)' }}>
              No discretionary adjustment applied. Up to <strong>±10%</strong> can be exercised at underwriter judgement before referral.
            </div>
          </WbCard>
        </div>
      </div>
    </WorkbenchFrame>
  );
}

/* Quiet ledger — plain rows, color only on deltas, subtotals carry weight. */
function Ledger({ opening, sections, final }) {
  return (
    <div>
      {opening && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '8px 4px 14px' }}>
          <div>
            <div style={{ fontSize: 13.5, fontWeight: 600 }}>{opening.label}</div>
            {opening.sub && <div className="caption" style={{ marginTop: 2 }}>{opening.sub}</div>}
          </div>
          <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--ink-soft)', fontVariantNumeric: 'tabular-nums' }}>
            {opening.value}
          </span>
        </div>
      )}
      {sections.map((s, i) => (
        <div key={s.title} style={{ marginTop: i === 0 ? 0 : 12 }}>
          <div className="eyebrow" style={{ padding: '8px 4px 6px', borderTop: '1px solid var(--rule)' }}>{s.title}</div>
          {s.items.map(([label, rate, delta], j) => (
            <div key={j} style={{
              display: 'grid', gridTemplateColumns: '1fr 80px 130px',
              padding: '7px 4px', fontSize: 13, color: 'var(--ink-soft)',
            }}>
              <span>{label}</span>
              <span style={{ textAlign: 'right', fontVariantNumeric: 'tabular-nums', color: 'var(--ink-mute)' }}>{rate}</span>
              <span style={{
                textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: 600,
                color: delta < 0 ? 'var(--neg)' : delta > 0 ? 'var(--warn)' : 'var(--ink-mute)',
              }}>
                {delta === 0 ? '—' : `${delta > 0 ? '+' : '−'}$${Math.abs(delta).toLocaleString()}`}
              </span>
            </div>
          ))}
          {s.subtotalLabel && (
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
              padding: '10px 4px 6px', marginTop: 4,
              borderTop: '1px solid var(--ink-soft)',
            }}>
              <span style={{ fontSize: 13.5, fontWeight: 700 }}>{s.subtotalLabel}</span>
              <span style={{ fontSize: 17, fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>{s.subtotalValue}</span>
            </div>
          )}
        </div>
      ))}
      {final && (
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          padding: '14px 4px 4px', marginTop: 10,
          borderTop: '2px solid var(--ink)',
        }}>
          <span style={{ fontSize: 15, fontWeight: 700, letterSpacing: '0.02em', textTransform: 'uppercase' }}>{final.label}</span>
          <span style={{ fontSize: 26, fontWeight: 700, color: 'var(--info-deep)', fontVariantNumeric: 'tabular-nums' }}>{final.value}</span>
        </div>
      )}
    </div>
  );
}

/* ─── 06 Coverage Terms ───────────────────────────────────────── */
function WbCoverage({ isDark }) {
  const extensions = [
    { name: 'Business interruption — 12 mo indemnity period',    desc: 'Standard cyber BI extension' },
    { name: 'Contingent business interruption',                  desc: 'IT outsourcer outage coverage' },
    { name: 'Reputational harm — 90 day window',                 desc: 'Crisis PR + brand restoration costs' },
    { name: 'Cryptocurrency theft',                              desc: 'Sub-limit $2M' },
  ];
  const exclusions = [
    { name: 'War and terrorism — except cyber-terrorism',         desc: 'Standard CL380 exclusion' },
    { name: 'Bodily injury / property damage',                   desc: 'Not a cyber peril' },
    { name: 'Patent infringement',                                desc: 'IP claims excluded' },
    { name: 'Unsolicited communications (TCPA)',                  desc: 'Telemarketing statutory liability' },
    { name: 'Pre-existing breaches before retroactive date',      desc: 'Retro date: 2024-01-01' },
    { name: 'Loss of crypto private keys',                        desc: 'Excluded from theft cover' },
  ];

  return (
    <WorkbenchFrame active="Coverage Terms" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto', gap: 14, alignContent: 'start' }}>

        <WbCard title="Coverage overview" icon="file-check">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            <WbKpi label="Territory"  value="Worldwide ex-OFAC" />
            <WbKpi label="Trigger"    value="Claims-made" />
            <WbKpi label="Extensions" value={extensions.length} />
            <WbKpi label="Exclusions" value={exclusions.length} />
          </div>
        </WbCard>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <WbCard title={`Extensions · ${extensions.length}`} icon="plus-circle">
            <ClauseList items={extensions} tone="pos" icon="check" />
          </WbCard>
          <WbCard title={`Exclusions · ${exclusions.length}`} icon="minus-circle">
            <ClauseList items={exclusions} tone="neg" icon="x" />
          </WbCard>
        </div>
      </div>
    </WorkbenchFrame>
  );
}

/* Quiet clause list — small tinted dot, plain row, hairline divider. */
function ClauseList({ items, tone, icon }) {
  const color = tone === 'pos' ? 'var(--pos)' : 'var(--neg)';
  return (
    <div>
      {items.map((it, i) => (
        <div key={it.name} style={{
          display: 'grid', gridTemplateColumns: '20px 1fr',
          gap: 12, padding: '10px 0',
          borderBottom: i < items.length - 1 ? '1px solid var(--rule)' : 0,
        }}>
          <div style={{
            width: 20, height: 20, borderRadius: '50%',
            background: 'color-mix(in srgb, var(--surface) 84%, ' + color + ' 16%)',
            color: color,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginTop: 1,
          }}>
            <Icon name={icon} size={12} />
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 500 }}>{it.name}</div>
            <div className="caption" style={{ marginTop: 2 }}>{it.desc}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── 07 Referral Actions ─────────────────────────────────────── */
function WbReferral({ isDark }) {
  const signals = [
    { code: 'cyber.soc2_typeii',     score: 35, conf: 0.95, weight: 0.18, contrib: 6.3,  flagged: true,  override: false, value: null, rationale: null,                    absent: false },
    { code: 'cyber.rdp_exposed',     score: 25, conf: 0.92, weight: 0.12, contrib: 3.0,  flagged: true,  override: false, value: null, rationale: null,                    absent: false },
    { code: 'cyber.mfa_admin',       score: 88, conf: 0.97, weight: 0.22, contrib: 19.4, flagged: false, override: false, value: null, rationale: null,                    absent: false },
    { code: 'cyber.backup_enc',      score: 78, conf: 0.81, weight: 0.10, contrib: 7.8,  flagged: true,  override: true,  value: 78,    rationale: 'Reviewed via Okta MFA export — backup is GPG encrypted', absent: false },
    { code: 'claims.5yr_history',    score: 96, conf: 0.99, weight: 0.18, contrib: 17.3, flagged: false, override: false, value: null, rationale: null,                    absent: false },
    { code: 'cyber.ir_playbook',     score: 50, conf: 0.62, weight: 0.08, contrib: 4.0,  flagged: false, override: false, value: null, rationale: null,                    absent: false },
  ];

  return (
    <WorkbenchFrame active="Referral Actions" isDark={isDark}>
      <div style={{ display: 'grid', gridTemplateRows: 'auto auto auto auto', gap: 14, alignContent: 'start' }}>

        {/* referral header */}
        <div className="card-spot" style={{ padding: 20, display: 'grid', gridTemplateColumns: 'auto 1fr auto', gap: 18, alignItems: 'center' }}>
          <Icon name="shield-alert" size={32} color="var(--spot)" />
          <div>
            <div className="eyebrow" style={{ color: 'var(--spot)' }}>Referred — pending underwriter audit</div>
            <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: '6px 0 0' }}>Priority 2 · auto-referred by 2 conditions</h3>
            <div className="caption" style={{ marginTop: 4 }}>
              Triggers: SOC 2 Type II missing · Public RDP exposed. Created Apr 24, assigned to Jordan Reyes.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 14 }}>
            <WbKpi label="Flagged"  value={signals.filter(s => s.flagged && !s.override).length} tone="warn" />
            <WbKpi label="Audited"  value={signals.filter(s => s.override).length} tone="pos" />
            <WbKpi label="Total"    value={signals.length} />
          </div>
        </div>

        <WbCard title="Referral context" icon="shield-alert">
          <div className="eyebrow" style={{ marginBottom: 8 }}>Triggering conditions</div>
          {[
            ['SOC 2 Type II missing — required for tier 2 binding',  'signal_condition · refer'],
            ['Public RDP exposed — outside standard appetite',       'signal_condition · refer'],
          ].map(([note, src]) => (
            <div key={note} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: '1px solid var(--rule)' }}>
              <div>
                <span style={{ fontSize: 13 }}>{note}</span>
                <div className="micro" style={{ marginTop: 2 }}>{src}</div>
              </div>
              <span className="chip chip-spot">refer</span>
            </div>
          ))}
        </WbCard>

        <WbCard title="Signal audit matrix" icon="layers" headerRight={<span className="micro">{signals.length} signals</span>}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1.6fr 70px 70px 70px 90px 90px 1.4fr 60px',
            padding: '6px 0', borderBottom: '1px solid var(--rule)',
          }}>
            {['Signal', 'Score', 'Conf', 'Weight', 'Contrib', 'Audited', 'Rationale', ''].map((h) => (
              <span key={h} className="micro" style={{ fontSize: 10.5 }}>{h}</span>
            ))}
          </div>
          {signals.map((s) => {
            const highImpact = Math.abs(s.contrib) > 10;
            return (
              <div key={s.code} style={{
                display: 'grid',
                gridTemplateColumns: '1.6fr 70px 70px 70px 90px 90px 1.4fr 60px',
                padding: '10px 0',
                borderBottom: '1px solid var(--rule)',
                borderLeft: s.flagged && !s.override ? '3px solid var(--warn)' : s.override ? '3px solid var(--pos)' : '3px solid transparent',
                paddingLeft: 10, marginLeft: -10,
                alignItems: 'center',
                fontSize: 12.5,
              }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  {highImpact && <Icon name="flame" size={12} color="var(--warn)" />}
                  {s.override && <Icon name="check" size={12} color="var(--pos)" />}
                  <span style={{ fontFamily: 'ui-monospace, monospace', fontWeight: highImpact ? 700 : 500 }}>{s.code}</span>
                </span>
                <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: s.override ? 700 : 500, color: s.override ? 'var(--pos)' : 'inherit' }}>{s.score.toFixed(1)}</span>
                <span style={{ fontVariantNumeric: 'tabular-nums', color: s.conf < 0.7 ? 'var(--warn)' : 'var(--ink-soft)', fontWeight: s.conf < 0.7 ? 700 : 500 }}>{Math.round(s.conf * 100)}%</span>
                <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--ink-soft)' }}>{s.weight.toFixed(2)}</span>
                <span style={{ fontVariantNumeric: 'tabular-nums', fontWeight: highImpact ? 700 : 500, color: highImpact ? 'var(--warn)' : 'inherit' }}>{s.contrib.toFixed(1)}</span>
                <span style={{ fontVariantNumeric: 'tabular-nums', color: s.override ? 'var(--pos)' : 'var(--ink-mute)', fontWeight: 600 }}>{s.override ? s.value.toFixed(1) : '—'}</span>
                <span className="micro" style={{ fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.rationale || '—'}</span>
                <Icon name="pen-line" size={14} color="var(--ink-mute)" />
              </div>
            );
          })}
        </WbCard>

        {/* Final decision actions */}
        <div className="card" style={{ padding: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div className="eyebrow">Final decision</div>
            <h3 style={{ font: '600 15px/1.3 IBM Plex Sans', margin: '6px 0 0' }}>
              1 signal audited · 2 flagged signals still pending audit
            </h3>
            <div className="caption" style={{ marginTop: 4 }}>Audit or override the remaining flagged signals before binding.</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn ghost"><Icon name="x" size={13} color="var(--neg)" /> Decline risk</button>
            <button className="btn" style={{ background: 'var(--pos)', color: 'var(--canvas)' }}>
              <Icon name="check" size={13} /> Approve & bind
            </button>
          </div>
        </div>
      </div>
    </WorkbenchFrame>
  );
}

/* ─── 08 Model Versions ───────────────────────────────────────── */
function WbVersions({ isDark }) {
  const versions = [
    { v: 4, type: 'Referral Review', score: 724, prevScore: 712, tier: 2, prevTier: 3, decision: 'refer',   author: 'world_engine_v8.2', date: '2026-04-26 14:08',  latest: true,  conf: 0.86, cov: 0.92, conds: 3, refFlags: 2, notes: 1 },
    { v: 3, type: 'Initial',         score: 712, prevScore: 698, tier: 3, prevTier: 3, decision: 'refer',   author: 'world_engine_v8.2', date: '2026-04-25 09:22',  latest: false, conf: 0.84, cov: 0.91, conds: 4, refFlags: 2, notes: 0 },
    { v: 2, type: 'Amendment',       score: 698, prevScore: 692, tier: 3, prevTier: 3, decision: 'pending', author: 'jordan.reyes',      date: '2026-04-24 17:45',  latest: false, conf: 0.81, cov: 0.88, conds: 5, refFlags: 0, notes: 2 },
    { v: 1, type: 'Initial',         score: 692, prevScore: null, tier: 3, prevTier: null, decision: 'pending', author: 'world_engine_v8.2', date: '2026-04-24 09:08', latest: false, conf: 0.78, cov: 0.83, conds: 6, refFlags: 0, notes: 0 },
  ];

  return (
    <WorkbenchFrame active="Model Versions" isDark={isDark}>
      <WbCard title="Version Lineage" icon="git-branch" headerRight={<span className="chip">{versions.length} versions</span>}>
        <div style={{ position: 'relative', paddingTop: 8, paddingBottom: 8 }}>
          <div style={{
            position: 'absolute', left: 22, top: 30, bottom: 30,
            width: 2, background: 'linear-gradient(180deg, transparent, var(--rule) 20%, var(--rule) 80%, transparent)',
          }} />
          {versions.map((v, i) => {
            const delta = v.prevScore != null ? v.score - v.prevScore : null;
            const tierChanged = v.prevTier != null && v.tier !== v.prevTier;
            const decisionTone = v.decision === 'approve' ? 'pos' : v.decision === 'refer' ? 'spot' : 'mute';

            return (
              <div key={v.v} style={{ display: 'flex', gap: 18, alignItems: 'flex-start', position: 'relative', marginBottom: i < versions.length - 1 ? 18 : 0 }}>
                <div style={{
                  width: 44, height: 44, borderRadius: '50%',
                  background: v.latest ? 'var(--info)' : 'var(--surface-elev)',
                  color: v.latest ? '#fff' : 'var(--ink)',
                  border: '2px solid ' + (v.latest ? 'var(--info)' : 'var(--rule-strong)'),
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0, zIndex: 1,
                }}>
                  <Icon name="git-commit-horizontal" size={20} />
                </div>
                <div style={{
                  flex: 1,
                  padding: 16,
                  borderRadius: 12,
                  background: v.latest ? 'var(--info-soft)' : 'var(--surface-elev)',
                  border: '1px solid ' + (v.latest ? 'var(--info)' : 'var(--rule)'),
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span className="eyebrow">Version {v.v}</span>
                      <span className="chip" style={{ fontSize: 10.5 }}>{v.type}</span>
                    </div>
                    {v.latest && <span className="chip chip-info">ACTIVE</span>}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 16, alignItems: 'flex-end' }}>
                    <div>
                      <div className="micro">Score</div>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                        <span className="num" style={{ fontSize: 22, color: 'var(--info)', fontVariantNumeric: 'tabular-nums' }}>{v.score}</span>
                        {delta != null && (
                          <span style={{ fontSize: 12, fontWeight: 700, color: delta > 0 ? 'var(--pos)' : 'var(--warn)' }}>
                            {delta > 0 ? '+' : ''}{delta}
                          </span>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="micro">Tier</div>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                        <span style={{ fontSize: 15, fontWeight: 700 }}>T{v.tier}</span>
                        {tierChanged && <span style={{ fontSize: 10.5, color: 'var(--warn)', fontWeight: 700 }}>was T{v.prevTier}</span>}
                      </div>
                    </div>
                    <span className={`chip chip-${decisionTone}`} style={{ textTransform: 'capitalize' }}>{v.decision}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 14, marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--rule)', fontSize: 11, color: 'var(--ink-soft)' }}>
                    <span>Confidence {Math.round(v.conf * 100)}%</span>
                    <span>Coverage {Math.round(v.cov * 100)}%</span>
                    {v.conds > 0 && <span style={{ color: 'var(--warn)' }}>{v.conds} condition{v.conds === 1 ? '' : 's'}</span>}
                    {v.refFlags > 0 && <span style={{ color: 'var(--neg)' }}>{v.refFlags} referral flag{v.refFlags === 1 ? '' : 's'}</span>}
                    {v.notes > 0 && <span>{v.notes} note{v.notes === 1 ? '' : 's'}</span>}
                    <span style={{ marginLeft: 'auto' }}>
                      <Icon name={v.author === 'world_engine_v8.2' ? 'bot' : 'user'} size={11} style={{ marginRight: 4 }} />
                      <code style={{ fontSize: 11 }}>{v.author}</code> · {v.date}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </WbCard>
    </WorkbenchFrame>
  );
}

Object.assign(window, { WbLoss, WbPremium, WbCoverage, WbReferral, WbVersions });
