/* global React, ReactDOM, Icon, MOBILE_CSS, Section, SignalHero, AwaitingRail,
   GlanceGrid, ThreadList, SignalFeed, Chip, buildFeed,
   useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor */

/* ============================================================
 * app.jsx — DSI mobile companion.
 *
 * One continuous intelligence feed, no tab bar. The only "navigation"
 * is the persona segment in the glass header; everything else is a
 * single downward scroll, the way a modern phone app feels.
 * ============================================================ */

const { useState, useRef, useEffect } = React;

const PERSONAS = [
  { key: 'broker',  label: 'Broker',  icon: 'briefcase' },
  { key: 'client',  label: 'Client',  icon: 'bot' },
  { key: 'carrier', label: 'Carrier', icon: 'building-2' },
];

const ACCENTS = {
  teal:  { ring: 'info', name: 'Teal' },
  blue:  { ring: 'aux',  name: 'Blue' },
  coral: { ring: 'spot', name: 'Coral' },
};

const SHELL_CSS = `
  .dsi-top{
    position:sticky; top:0; z-index:5;
    padding:54px 20px 13px;
    background:color-mix(in srgb, var(--canvas) 80%, transparent);
    -webkit-backdrop-filter:blur(20px) saturate(180%); backdrop-filter:blur(20px) saturate(180%);
    border-bottom:1px solid color-mix(in srgb, var(--rule) 60%, transparent);
    transition:background .45s ease, border-color .45s ease;
  }
  .dsi-top-row{ display:flex; align-items:center; gap:12px; }
  .dsi-org-av{ width:42px; height:42px; border-radius:13px; display:flex; align-items:center; justify-content:center;
    background:var(--ink); color:var(--canvas); flex-shrink:0; font-weight:700; }
  .dsi-greet{ font-size:12.5px; color:var(--ink-mute); font-weight:600; line-height:1; }
  .dsi-org{ font-size:18px; font-weight:700; letter-spacing:-.02em; line-height:1.1; margin-top:3px; }
  .dsi-iconbtn{ width:38px; height:38px; border-radius:11px; display:flex; align-items:center; justify-content:center;
    background:var(--surface); border:1px solid var(--rule); color:var(--ink-soft); flex-shrink:0; cursor:default;
    box-shadow:0 1px 2px rgba(11,34,55,.04); }
  .dsi-iconbtn:active{ transform:scale(.92); }

  .dsi-seg{ display:flex; gap:4px; margin-top:14px; padding:4px; border-radius:14px;
    background:var(--surface-sunken); border:1px solid var(--rule); }
  .dsi-seg-b{ flex:1; display:flex; align-items:center; justify-content:center; gap:6px; height:34px; border-radius:10px;
    font-size:13px; font-weight:600; color:var(--ink-mute); cursor:default; transition:all .2s ease; letter-spacing:-.01em; }
  .dsi-seg-b.on{ background:var(--surface); color:var(--ink); box-shadow:0 1px 3px rgba(11,34,55,.1); }
  .dsi-app.is-dark .dsi-seg-b.on{ box-shadow:0 1px 4px rgba(0,0,0,.4); }

  /* climate strip */
  .dsi-climate{ display:flex; align-items:center; gap:8px; margin-top:16px; padding:0 2px; white-space:nowrap; }
  .dsi-climate-dot{ width:8px; height:8px; border-radius:50%; }

  /* floating ask pill */
  .dsi-ask{ position:absolute; left:20px; right:20px; bottom:30px; z-index:45; height:54px; border-radius:18px;
    display:flex; align-items:center; gap:11px; padding:0 8px 0 18px;
    background:color-mix(in srgb, var(--ink) 92%, transparent); color:var(--canvas);
    -webkit-backdrop-filter:blur(12px); backdrop-filter:blur(12px);
    box-shadow:0 8px 30px rgba(11,34,55,.28), 0 2px 8px rgba(11,34,55,.2); cursor:default;
    transition:transform .2s cubic-bezier(.3,.7,.4,1); }
  .dsi-ask:active{ transform:scale(.98); }
  .dsi-ask-tx{ flex:1; font-size:15px; font-weight:500; opacity:.8; letter-spacing:-.01em; }
  .dsi-ask-send{ width:38px; height:38px; border-radius:12px; display:flex; align-items:center; justify-content:center;
    background:var(--info); color:#04222a; flex-shrink:0; }
  .dsi-app.is-dark .dsi-ask-send{ color:#04222a; }

  /* bottom sheet */
  .dsi-scrim{ position:absolute; inset:0; z-index:60; background:rgba(8,20,34,.42);
    -webkit-backdrop-filter:blur(2px); backdrop-filter:blur(2px); opacity:0; transition:opacity .3s ease; }
  .dsi-scrim.on{ opacity:1; }
  .dsi-sheet{ position:absolute; left:0; right:0; bottom:0; z-index:61; max-height:86%;
    background:var(--canvas); border-radius:28px 28px 0 0; display:flex; flex-direction:column;
    box-shadow:0 -10px 40px rgba(8,20,34,.3); transform:translateY(101%); transition:transform .36s cubic-bezier(.3,.8,.3,1);
    border-top:1px solid var(--rule); }
  .dsi-sheet.on{ transform:translateY(0); }
  .dsi-grab{ width:38px; height:5px; border-radius:5px; background:var(--rule-strong); margin:10px auto 4px; flex-shrink:0; }
  .dsi-sheet-hd{ padding:6px 22px 14px; border-bottom:1px solid var(--rule); }
  .dsi-sheet-body{ overflow-y:auto; padding:18px 20px 8px; flex:1; scrollbar-width:none; }
  .dsi-sheet-body::-webkit-scrollbar{display:none}

  .dsi-bubble{ max-width:84%; padding:11px 14px; border-radius:17px; font-size:14px; line-height:1.42; }
  .dsi-bubble.them{ background:var(--surface); border:1px solid var(--rule); border-bottom-left-radius:5px; align-self:flex-start; }
  .dsi-bubble.me{ background:var(--info); color:#04222a; border-bottom-right-radius:5px; align-self:flex-end; }
  .dsi-app.is-dark .dsi-bubble.me{ color:#04222a; }
  .dsi-bubble.sys{ align-self:center; background:var(--spot-soft); color:var(--spot-deep); font-size:12.5px; font-weight:600;
    border-radius:12px; max-width:92%; text-align:center; }
  .dsi-msg-who{ font-size:11px; font-weight:700; color:var(--ink-mute); margin:0 0 4px 4px; letter-spacing:.02em; }

  .dsi-prefill{ display:flex; align-items:center; gap:8px; margin:14px 0 4px; padding:12px 14px; border-radius:14px;
    background:var(--info-soft); color:var(--info-deep); font-size:13px; font-weight:600; cursor:default; }
  .dsi-compose{ display:flex; align-items:center; gap:10px; padding:14px 18px calc(14px + env(safe-area-inset-bottom));
    border-top:1px solid var(--rule); flex-shrink:0; }
  .dsi-compose-in{ flex:1; height:44px; border-radius:14px; background:var(--surface-sunken); border:1px solid var(--rule);
    display:flex; align-items:center; padding:0 16px; font-size:14px; color:var(--ink-mute); }
  .dsi-send{ width:44px; height:44px; border-radius:14px; background:var(--info); color:#04222a; display:flex; align-items:center; justify-content:center; flex-shrink:0; }

  /* toast */
  .dsi-toast{ position:absolute; left:50%; bottom:96px; z-index:70; transform:translate(-50%,20px);
    background:var(--ink); color:var(--canvas); padding:11px 18px; border-radius:14px; font-size:13.5px; font-weight:600;
    display:flex; align-items:center; gap:8px; box-shadow:0 10px 30px rgba(8,20,34,.3); opacity:0; pointer-events:none;
    transition:opacity .25s ease, transform .25s ease; white-space:nowrap; }
  .dsi-toast.on{ opacity:1; transform:translate(-50%,0); }

  .dsi-app.text-lg .dsi-brief{ font-size:18.5px; }
  .dsi-app.text-lg .dsi-thread-who{ font-size:16px; }
  .dsi-app.text-lg .dsi-evt-title{ font-size:15px; }
  .dsi-app.text-lg .dsi-evt-text{ font-size:14.5px; }
  .dsi-app.text-lg .dsi-tile-val{ font-size:32px; }

  .dsi-app.dense .dsi-sect{ margin-top:24px; }
  .dsi-app.comfy .dsi-sect{ margin-top:42px; }
`;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "persona": "broker",
  "dark": false,
  "density": "regular",
  "textSize": "standard",
  "accent": "teal",
  "showAwaiting": true,
  "showGlance": true,
  "showThreads": true,
  "showFeed": true
}/*EDITMODE-END*/;

function App({ t, setTweak }) {
  const [persona, setPersona] = useState(t.persona);
  const [sheet, setSheet] = useState(null);     // { kind:'thread'|'await', data }
  const [toast, setToast] = useState('');
  const scrollRef = useRef(null);
  const toastTimer = useRef(null);

  // Tweak panel can drive persona too.
  useEffect(() => { if (t.persona !== persona) setPersona(t.persona); }, [t.persona]);

  const feed = buildFeed(persona);
  const dark = t.dark;
  const accentRing = (ACCENTS[t.accent] || ACCENTS.teal).ring;

  function switchPersona(p) {
    setPersona(p); setTweak('persona', p); setSheet(null);
    if (scrollRef.current) scrollRef.current.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function flash(msg) {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 2200);
  }
  function send() {
    setSheet(null);
    flash('Reply sent · signal attached');
  }

  const rootCls = ['dsi-app', 'ds-reimag', dark ? 'is-dark' : '',
    t.textSize === 'large' ? 'text-lg' : '',
    t.density === 'compact' ? 'dense' : t.density === 'comfy' ? 'comfy' : ''].join(' ');

  const cl = feed.climate;
  const clTone = cl.tone === 'pos' ? 'var(--pos)' : cl.tone === 'neg' ? 'var(--neg)' : 'var(--warn)';

  return (
    <div className={rootCls}>
      <style>{MOBILE_CSS + SHELL_CSS}</style>

      <div className="dsi-scroll" ref={scrollRef}>
        {/* ── glass header ── */}
        <div className="dsi-top">
          <div className="dsi-top-row">
            <div className="dsi-org-av"><Icon name={feed.org.glyph} size={21} /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="dsi-greet">{feed.greeting}</div>
              <div className="dsi-org">{feed.org.name}</div>
            </div>
            <div className="dsi-iconbtn" onClick={() => setTweak('dark', !dark)}>
              <Icon name={dark ? 'sun' : 'moon'} size={18} />
            </div>
          </div>

          <div className="dsi-seg">
            {PERSONAS.map((p) => (
              <div key={p.key} className={'dsi-seg-b' + (persona === p.key ? ' on' : '')} onClick={() => switchPersona(p.key)}>
                <Icon name={p.icon} size={15} />{p.label}
              </div>
            ))}
          </div>
        </div>

        {/* ── feed ── */}
        <div className="dsi-pad" style={{ paddingBottom: 116 }} key={persona}>
          <div className="dsi-climate dsi-rise" style={{ animationDelay: '0ms' }}>
            <span className="dsi-climate-dot" style={{ background: clTone }} />
            <span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--ink-mute)', letterSpacing: '.04em', textTransform: 'uppercase' }}>{cl.label}</span>
            <span style={{ fontSize: 12.5, fontWeight: 700, color: clTone }}>{cl.value}</span>
          </div>

          <div className="dsi-brief dsi-rise" style={{ marginTop: 14, animationDelay: '40ms' }}
            dangerouslySetInnerHTML={{ __html: briefHtml(feed.brief) }} />

          <div className="dsi-rise" style={{ marginTop: 22, animationDelay: '90ms' }}>
            <SignalHero score={{ ...feed.score }} accentRing={accentRing} />
          </div>

          {t.showAwaiting && feed.awaiting.length > 0 && (
            <div className="dsi-rise" style={{ animationDelay: '140ms' }}>
              <Section title="Awaiting you" link={feed.awaiting.length + ' open'} />
              <AwaitingRail items={feed.awaiting} onAct={(it) => setSheet({ kind: 'await', data: it })} />
            </div>
          )}

          {t.showGlance && (
            <div className="dsi-rise" style={{ animationDelay: '180ms' }}>
              <Section title="At a glance" />
              <GlanceGrid tiles={feed.glance} />
            </div>
          )}

          {t.showThreads && (
            <div className="dsi-rise" style={{ animationDelay: '220ms' }}>
              <Section title="Conversations" link="Inbox" onLink={() => {}} />
              <ThreadList threads={feed.threads} onOpen={(th) => setSheet({ kind: 'thread', data: th })} />
            </div>
          )}

          {t.showFeed && (
            <div className="dsi-rise" style={{ animationDelay: '260ms' }}>
              <Section title="Signal feed" />
              <SignalFeed events={feed.feed} />
            </div>
          )}
        </div>
      </div>

      {/* floating ask pill (next-gen assistant entry) */}
      {!sheet && (
        <div className="dsi-ask" onClick={() => flash('Ask DSI — coming to your pocket')}>
          <Icon name="sparkles" size={19} style={{ opacity: 0.85 }} />
          <span className="dsi-ask-tx">Ask anything about your {persona === 'carrier' ? 'pipeline' : 'book'}…</span>
          <div className="dsi-ask-send"><Icon name="arrow-up" size={19} /></div>
        </div>
      )}

      {/* reply / thread sheet */}
      <ReplySheet sheet={sheet} dark={dark} onClose={() => setSheet(null)} onSend={send} />

      <div className={'dsi-toast' + (toast ? ' on' : '')}><Icon name="check" size={16} />{toast}</div>

      <Tweaks t={t} setTweak={setTweak} />
    </div>
  );
}

function briefHtml(s) {
  // bold the leading count + any client names already capitalised mid-sentence
  return s.replace(/^(\d+ things|\d+ requests|\d+ submissions)/, '<b>$1</b>')
          .replace(/(Eastward Robotics|BrightLeaf Pharma|World Engine)/g, '<b>$1</b>');
}

// ── Bottom sheet: thread view + compose ──────────────────────
function ReplySheet({ sheet, dark, onClose, onSend }) {
  const data = sheet && sheet.data;
  const isAwait = sheet && sheet.kind === 'await';
  const msgs = sheet && (sheet.kind === 'thread'
    ? data.messages
    : [{ from: 'them', who: data.carrier, text: data.sub, time: data.age }]);

  return (
    <React.Fragment>
      <div className={'dsi-scrim' + (sheet ? ' on' : '')} style={{ pointerEvents: sheet ? 'auto' : 'none' }} onClick={onClose} />
      <div className={'dsi-sheet' + (sheet ? ' on' : '')}>
        <div className="dsi-grab" />
        {sheet && (
          <React.Fragment>
            <div className="dsi-sheet-hd">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: '-.01em' }}>{isAwait ? data.title : data.who}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-mute)', marginTop: 2 }}>
                    {isAwait ? `${data.line} · ${data.carrier}` : data.sub}
                  </div>
                </div>
                <Chip tone="spot" icon="clock">{data.age}</Chip>
              </div>
            </div>
            <div className="dsi-sheet-body">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {msgs.map((m, i) => (
                  <div key={i} style={{ display: 'flex', flexDirection: 'column', alignSelf: m.from === 'me' ? 'flex-end' : m.from === 'sys' ? 'center' : 'flex-start', maxWidth: '100%' }}>
                    {m.who && m.from === 'them' && <div className="dsi-msg-who">{m.who}</div>}
                    <div className={'dsi-bubble ' + m.from}>{m.text}</div>
                  </div>
                ))}
              </div>
              <div className="dsi-prefill" onClick={onSend}>
                <Icon name="sparkles" size={16} />
                <span style={{ flex: 1 }}>Smart reply ready — signal &amp; latest attestation pre-filled</span>
                <Icon name="arrow-up-right" size={16} />
              </div>
            </div>
            <div className="dsi-compose">
              <div className="dsi-compose-in">Type a reply…</div>
              <div className="dsi-send dsi-press" onClick={onSend}><Icon name="arrow-up" size={20} /></div>
            </div>
          </React.Fragment>
        )}
      </div>
    </React.Fragment>
  );
}

// ── Tweaks ───────────────────────────────────────────────────
function Tweaks({ t, setTweak }) {
  return (
    <TweaksPanel>
      <TweakSection label="Persona" />
      <TweakRadio label="Show" value={t.persona} options={['broker', 'client', 'carrier']}
        onChange={(v) => setTweak('persona', v)} />
      <TweakSection label="Appearance" />
      <TweakToggle label="Dark mode" value={t.dark} onChange={(v) => setTweak('dark', v)} />
      <TweakRadio label="Density" value={t.density} options={['compact', 'regular', 'comfy']}
        onChange={(v) => setTweak('density', v)} />
      <TweakRadio label="Text size" value={t.textSize} options={['standard', 'large']}
        onChange={(v) => setTweak('textSize', v)} />
      <TweakColor label="Signal accent" value={t.accent === 'teal' ? '#0E7C8C' : t.accent === 'blue' ? '#4A60A8' : '#D97757'}
        options={['#0E7C8C', '#4A60A8', '#D97757']}
        onChange={(v) => setTweak('accent', v === '#0E7C8C' ? 'teal' : v === '#4A60A8' ? 'blue' : 'coral')} />
      <TweakSection label="Home sections" />
      <TweakToggle label="Awaiting you" value={t.showAwaiting} onChange={(v) => setTweak('showAwaiting', v)} />
      <TweakToggle label="At a glance" value={t.showGlance} onChange={(v) => setTweak('showGlance', v)} />
      <TweakToggle label="Conversations" value={t.showThreads} onChange={(v) => setTweak('showThreads', v)} />
      <TweakToggle label="Signal feed" value={t.showFeed} onChange={(v) => setTweak('showFeed', v)} />
    </TweaksPanel>
  );
}

// ── Root: owns tweaks + theme, wraps the device frame ────────
function Root() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '28px 0', boxSizing: 'border-box',
      background: t.dark
        ? 'radial-gradient(120% 80% at 50% 0%, #14304b 0%, #0a1c30 55%, #060f1c 100%)'
        : 'radial-gradient(120% 80% at 50% 0%, #fbf8f2 0%, #ece5d7 55%, #ddd4c2 100%)',
      transition: 'background .45s ease' }}>
      <IOSDevice dark={t.dark}>
        <App t={t} setTweak={setTweak} />
      </IOSDevice>
    </div>
  );
}

Object.assign(window, { App, Root });
