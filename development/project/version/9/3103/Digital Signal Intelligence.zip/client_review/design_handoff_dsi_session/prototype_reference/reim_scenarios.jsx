/* global React, FrameReimag, Icon,
   useCoverage, PageHead, OppByLineBar, StatusChip,
   CLIENT_LINES, CLIENT_PORTFOLIO, lineByKey, kMoney */

/* ============================================================
 * Scenarios — what-ifs, per coverage or across the book.
 *
 *   All   → add a new line · where to focus first · rebalance
 *   line  → improve a signal · adjust the limit · restructure tower
 * ============================================================ */

const ENT_S = 'Eastward Robotics';

// rough score points earned per dollar of premium opportunity closed.
const scorePts = (delta) => Math.round(delta / 1650);

function ReimScenarios({ isDark }) {
  const [cov, setCov] = useCoverage('all');
  const line = cov === 'all' ? null : lineByKey(cov);
  const title = cov === 'all' ? 'Explore what would happen — across your book' : `Explore what would happen — ${line.line}`;
  const sub = cov === 'all'
    ? 'Portfolio-level moves and where to put your effort first. Pick a line for limit, tower and signal what-ifs specific to it.'
    : `Heuristic estimates for ${line.line} with ${line.carrier}, to support conversation with your broker.`;

  return (
    <FrameReimag menu="Scenarios" entity={ENT_S} isDark={isDark}>
      <div style={{ display: 'grid', gridAutoRows: 'min-content', gap: 18, height: '100%', alignContent: 'start' }}>
        <PageHead eyebrow="Scenarios" title={title} sub={sub} active={cov} onChange={setCov} />

        {cov === 'all' ? <ScenariosPortfolio onPick={setCov} /> : <ScenariosLine line={line} />}

        {/* footer info */}
        <div style={{ padding: '14px 18px', border: '1px solid var(--rule)', borderRadius: 10, background: 'var(--surface-sunken)', display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <Icon name="info" size={18} color="var(--ink-soft)" style={{ marginTop: 1, flexShrink: 0 }} />
          <div className="caption" style={{ lineHeight: 1.5 }}>
            Scenario estimates assume all other signals stay constant and use each line's current carrier pricing model.
            To turn any of these into a firm quote, send the scenario to your broker from the action menu (...) on the row.
          </div>
        </div>
      </div>
    </FrameReimag>
  );
}

/* ════════════════════════ PORTFOLIO (All) ════════════════════════ */
function ScenariosPortfolio({ onPick }) {
  // rank lines by total opportunity for "where to focus first".
  const focus = [...CLIENT_PORTFOLIO.oppByLine].sort((a, b) => b.amount - a.amount);
  const focusRows = focus.map((f, i) => {
    const l = lineByKey(f.key);
    const moves = l.opportunity.length;
    return {
      label: `${l.line}`,
      sub: `${moves} move${moves === 1 ? '' : 's'} · ${l.percentile}th percentile${i === 0 ? ' · weakest line' : ''}`,
      delta: `−${kMoney(f.amount)}`, deltaTone: 'pos',
      score: `${l.score} → ${l.score + l.opportunity.reduce((s, o) => s + scorePts(o[1]), 0)}`,
    };
  });

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
      {/* where to focus first — the cross-line prioritisation */}
      <ScenarioCard
        kind="signal" title="Where to focus first"
        subtitle="Your three lines, ranked by the premium on the table. Closing the weakest line moves the book most."
        rows={focusRows}
        footer={{ label: 'Close everything identified', delta: `−${kMoney(CLIENT_PORTFOLIO.totalOpp)}`, score: `book ${CLIENT_PORTFOLIO.score} → ${CLIENT_PORTFOLIO.score + 18}` }}
        onRow={(i) => onPick(focus[i].key)}
      />

      {/* add a new coverage line */}
      <ScenarioCard
        kind="add" title="Add a new coverage line"
        subtitle="Indicative ranges based on your industry and revenue band — lines peers your size commonly carry."
        rows={[
          { label: 'Property', sub: '78% of cohort carry it', delta: '$70k – $220k', deltaTone: 'mute' },
          { label: 'General Liability', sub: '65% of cohort carry it', delta: '$130k – $320k', deltaTone: 'mute' },
          { label: 'Product Liability', sub: 'Often added at your scale', delta: '$95k – $250k', deltaTone: 'mute' },
          { label: 'Crime', sub: 'Sometimes added', delta: '$40k – $95k', deltaTone: 'mute' },
        ]}
      />

      {/* rebalance the book */}
      <ScenarioCard
        kind="tower" title="Rebalance the book"
        subtitle="Consolidating lines or layers can unlock multiline credits across the whole programme."
        rows={[
          { label: 'Current — three carriers', sub: 'Hartford · Beazley · Chubb', delta: `$${CLIENT_PORTFOLIO.totalPremium.toLocaleString()}`, deltaTone: 'mute' },
          { label: 'Multiline with two carriers', sub: 'Bundle Cyber + PI', delta: '−$22.0k', score: 'multiline credit' },
          { label: 'Single-programme tower', sub: 'All lines, one lead', delta: '−$31.5k', score: 'best blended rate' },
        ]}
        note="Consolidation trades carrier diversification for price. Worth modelling with your broker before renewal."
      />

      {/* improve across lines */}
      <ScenarioCard
        kind="limit" title="Lift the whole book"
        subtitle="What closing every low-effort win across all three lines would do to your blended signal."
        rows={[
          { label: 'Close all low-effort wins', sub: `${CLIENT_PORTFOLIO.lowEffortWins} quick credits`, delta: '−$24.4k', deltaTone: 'pos', score: `book ${CLIENT_PORTFOLIO.score} → ${CLIENT_PORTFOLIO.score + 11}` },
          { label: 'Close every identified move', sub: `${CLIENT_PORTFOLIO.totalActions} moves total`, delta: `−${kMoney(CLIENT_PORTFOLIO.totalOpp)}`, deltaTone: 'pos', score: `book ${CLIENT_PORTFOLIO.score} → ${CLIENT_PORTFOLIO.score + 18}` },
        ]}
        note="Low-effort wins are typically creditable within a single renewal cycle."
      />
    </div>
  );
}

/* ════════════════════════ SINGLE LINE ════════════════════════ */
function ScenariosLine({ line }) {
  const sumPts = line.opportunity.reduce((s, o) => s + scorePts(o[1]), 0);
  const sumDelta = line.opportunity.reduce((s, o) => s + o[1], 0);
  const improveRows = line.opportunity.map((o) => {
    const pts = scorePts(o[1]);
    return { label: o[0], sub: `+${pts} pts projected`, delta: `−${kMoney(o[1])}`, score: `${line.score} → ${line.score + pts}` };
  });

  const minAdj = Math.round(line.premium * 0.199);
  const bestAdj = Math.round(line.premium * 0.16);
  const split6040 = Math.round(line.premium * 0.07);
  const split5050 = Math.round(line.premium * 0.09);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
      {/* improve a signal */}
      {line.opportunity.length > 0 ? (
        <ScenarioCard
          kind="signal" title="Improve a signal"
          subtitle={`Close one of the ${line.opportunity.length} open ${line.short} signals — see how it moves your score and premium.`}
          rows={improveRows}
          footer={{ label: `Close all ${line.opportunity.length}`, delta: `−${kMoney(sumDelta)}`, score: `${line.score} → ${line.score + sumPts}` }}
        />
      ) : (
        <div className="card-pos" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 12, justifyContent: 'center' }}>
          <span className="chip chip-pos" style={{ alignSelf: 'flex-start' }}><Icon name="badge-check" size={12} /> optimised</span>
          <h3 style={{ font: '600 17px/1.3 IBM Plex Sans', margin: 0 }}>No open signals on {line.short}</h3>
          <div className="caption">This line is already preferred — there are no signal improvements left to model. Focus your effort on the lines with headroom.</div>
        </div>
      )}

      {/* adjust the limit */}
      <ScenarioCard
        kind="limit" title="Adjust your limit"
        subtitle={`${line.line} sits at ${line.limit} today. Two carrier-recommended alternatives:`}
        rows={[
          { label: 'Minimum adequate', sub: 'Drop to the lowest acceptable limit', delta: `−${kMoney(minAdj)}`, deltaTone: 'pos', score: `${kMoney(line.premium)} → ${kMoney(line.premium - minAdj)}` },
          { label: 'Best-value', sub: 'Lift the limit for better cost-per-dollar', delta: `+${kMoney(bestAdj)}`, deltaTone: 'neg', score: `${kMoney(line.premium)} → ${kMoney(line.premium + bestAdj)}` },
        ]}
        note="Best-value gives better cost-per-dollar-of-coverage; minimum adequate is the cheapest your carrier's appetite allows."
      />

      {/* restructure tower */}
      <ScenarioCard
        kind="tower" title="Restructure your tower"
        subtitle={`Splitting ${line.short}'s single-line tower into primary + excess can reduce premium 7–10%.`}
        rows={[
          { label: 'Current — single tower', sub: `${line.limit} with ${line.carrier}`, delta: `$${line.premium.toLocaleString()}`, deltaTone: 'mute' },
          { label: '60 / 40 split', sub: 'Lead carrier + excess', delta: `−${kMoney(split6040)}`, score: `${kMoney(line.premium - split6040)} total` },
          { label: '50 / 50 split', sub: 'Two equal layers', delta: `−${kMoney(split5050)}`, score: `${kMoney(line.premium - split5050)} total` },
        ]}
      />

      {/* line context card */}
      <div className="card" style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--surface-elev)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={line.icon} size={18} color="var(--ink)" />
            </div>
            <div>
              <h3 style={{ font: '600 17px/1.1 IBM Plex Sans', margin: 0 }}>{line.line}</h3>
              <div className="micro">{line.carrier}</div>
            </div>
          </div>
          <StatusChip tone={line.statusTone}>{line.status}</StatusChip>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <Fact label="Current premium" value={`$${line.premium.toLocaleString()}`} />
          <Fact label="Signal score" value={line.score} tone={line.score >= line.median ? 'info' : 'warn'} />
          <Fact label="Open opportunity" value={line.opportunity.length ? `−${kMoney(sumDelta)}` : '—'} tone="spot" />
          <Fact label="Renews" value={line.expires} />
        </div>
        <div className="caption" style={{ marginTop: 'auto' }}>
          {line.note || 'Scenarios above are specific to this line and its carrier.'}
        </div>
      </div>
    </div>
  );
}

function Fact({ label, value, tone }) {
  return (
    <div>
      <div className="micro">{label}</div>
      <div className="num-sm" style={{ fontSize: 16, marginTop: 2, color: tone ? `var(--${tone})` : 'var(--ink)' }}>{value}</div>
    </div>
  );
}

/* ─── shared scenario card / row (unchanged structure) ─────────── */
function ScenarioCard({ kind, title, subtitle, rows, footer, note, onRow }) {
  const icons = { signal: 'list-checks', limit: 'sliders-horizontal', add: 'plus-circle', tower: 'layers' };
  return (
    <div className="card" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 14 }}>
        <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--surface-elev)', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name={icons[kind]} size={18} color="var(--ink)" />
        </div>
        <div style={{ flex: 1 }}>
          <h3 style={{ font: '600 17px/1.2 IBM Plex Sans', margin: 0 }}>{title}</h3>
          <div className="caption" style={{ marginTop: 4 }}>{subtitle}</div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map((r, i) => <ScenarioRow key={i} {...r} onClick={onRow ? () => onRow(i) : undefined} />)}
        {footer && <div style={{ marginTop: 4 }}><ScenarioRow {...footer} deltaTone="pos" emphasised /></div>}
      </div>
      {note && <div className="caption" style={{ marginTop: 12 }}>{note}</div>}
    </div>
  );
}

function ScenarioRow({ label, sub, delta, score, deltaTone, emphasised, onClick }) {
  const tone = deltaTone || (delta?.startsWith('−') ? 'pos' : delta?.startsWith('+') ? 'neg' : 'info');
  const toneClass = tone === 'mute' ? '' : tone;
  return (
    <div onClick={onClick} style={{
      display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'center', padding: '10px 0',
      borderTop: emphasised ? '2px solid var(--ink)' : '1px solid var(--rule)',
      cursor: onClick ? 'pointer' : 'default',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div>
          <div style={{ fontSize: 13.5, fontWeight: emphasised ? 700 : 500 }}>{label}</div>
          {sub && <div className="micro" style={{ marginTop: 2 }}>{sub}</div>}
        </div>
        {onClick && <Icon name="chevron-right" size={15} color="var(--ink-mute)" />}
      </div>
      <div style={{ textAlign: 'right' }}>
        <div className={`num-sm ${toneClass}`} style={{ fontSize: emphasised ? 18 : 15, fontVariantNumeric: 'tabular-nums', color: tone === 'mute' ? 'var(--ink)' : undefined }}>{delta}</div>
        {score && <div className="micro" style={{ marginTop: 2 }}>{score}</div>}
      </div>
    </div>
  );
}

Object.assign(window, { ReimScenarios });
